import type {Question,Option,Interval,Condition} from './question-types';
const interval=(l:number|null,u:number|null,lc=false,uc=false):Interval=>({lower:l,upper:u,lowerClosed:lc,upperClosed:uc});
const sign=(n:number)=>n<0?`-${Math.abs(n)}`:`+${n}`;
const linear=(a:number,b:number)=>`${a===1?'':a===-1?'-':a}x${b?sign(b):''}`;
export function intervalText(s:Interval):string{
 if(s.lower===null)return `$x${s.upperClosed?'\\le':'<'}${s.upper}$`;
 if(s.upper===null)return `$x${s.lowerClosed?'\\ge':'>'}${s.lower}$`;
 return `$${s.lower}${s.lowerClosed?'\\le ':'<'}x${s.upperClosed?'\\le':'<'}${s.upper}$`;
}
const setText=(segments:Interval[])=>segments.length?segments.map(intervalText).join(' 或 '):'無解';
const notation=(s:Interval)=>`$${s.lowerClosed?'[':'('}${s.lower},${s.upper}${s.upperClosed?']':')'}$`;
function choices(id:string,sets:Interval[][],tags:string[],texts?:string[]):Option[]{return sets.map((solution,i)=>({optionId:`${id}-${'ABCD'[i]}`,text:texts?.[i]??setText(solution),misconceptionTag:i?tags[i-1]:null,solution}));}
function make(id:string,difficulty:string,tags:string[],prompt:string,hint:string,options:Option[],explanation:string,conditions:Condition[],logic:'and'|'or'='and'):Question{return {questionId:id,difficulty,topicTags:tags,misconceptionTags:[...new Set(options.flatMap(o=>o.misconceptionTag?[o.misconceptionTag]:[]))],prompt,hint,options,correctOptionId:options[0].optionId,explanation,check:{conditions,logic}};}
export function generateQuestionBank():Question[]{
 const out:Question[]=[];
 for(let l=-4;l<=4;l++)for(let span=2;span<=6;span++){
  const u=l+span;
  for(let mask=0;mask<4;mask++){
   const lc=!!(mask&1),uc=!!(mask&2),s=interval(l,u,lc,uc),id=`G-I-${l}-${u}-${mask}`;
   const sets=[[s],[interval(l,u,!lc,!uc)],[interval(l-1,u,lc,uc)],[interval(l,u+1,lc,uc)]];
   const cs:Condition[]=[{a:1,b:0,sign:lc?'>=':'>',c:l},{a:1,b:0,sign:uc?'<=':'<',c:u}];
   const q=make(id,'基礎',['區間記法','端點'],`不等式 ${intervalText(s)} 可用哪個區間表示？`,`先看左右兩個端點：${lc?'包括':'不包括'}左端點、${uc?'包括':'不包括'}右端點。中括號表示包括，圓括號表示不包括。`,choices(id,[[s],[interval(l,u,!lc,uc)],[interval(l,u,lc,!uc)],[interval(l,u,!lc,!uc)]],['左端點錯誤','右端點錯誤','端點錯誤'],[notation(s),notation(interval(l,u,!lc,uc)),notation(interval(l,u,lc,!uc)),notation(interval(l,u,!lc,!uc))]),`${intervalText(s)} 的左端點${lc?'包括':'不包括'}，右端點${uc?'包括':'不包括'}，所以是 ${notation(s)}。`,cs);out.push(q);
   const did=`G-D-${l}-${u}-${mask}`,d=make(did,'基礎',['數線','端點'],`哪一條數線表示 ${intervalText(s)}？`,`先找數線上的 ${l} 和 ${u}，再用實心點表示包括端點、空心點表示不包括端點。`,choices(did,sets,['端點錯誤','下限錯誤','上限錯誤']),`範圍由 ${l} 至 ${u}；左端點${lc?'用實心點':'用空心點'}，右端點${uc?'用實心點':'用空心點'}。`,cs);
   d.diagram={type:'number-line-options',domain:[l-2,u+2],options:d.options.map((o,i)=>({optionId:o.optionId,segments:sets[i]}))};out.push(d);
  }
  for(let k=2;k<=4;k++){
   const b=3+k,id=`G-N-${l}-${u}-${k}`,s=interval(l,u,false,true),conditions:Condition[]=[{a:-k,b,sign:'>=',c:b-k*u},{a:1,b:2,sign:'>',c:l+2}];
   const options=choices(id,[[s],[interval(u,null,true,false)],[interval(l,u,true,false)],[interval(null,u,false,true),interval(l,null,false,false)]],['忘記反轉不等號','端點錯誤','及或調轉']);
   out.push(make(id,'標準',['及','除以負數'],`解 $${linear(-k,b)}\\ge${b-k*u}$ 及 $x+2>${l+2}$。`,`第一式先減去 ${b}，再除以 $-${k}$；這一步要反轉不等號。第二式兩邊減 2，最後取共同範圍。`,options,`第一式得 $x\\le${u}$；第二式得 $x>${l}$。「及」取交集，所以 ${intervalText(s)}。`,conditions));
   const aid=`G-A-${l}-${u}-${k}`,offset=k+1,s2=interval(l,u,true,false),cs:Condition[]=[{a:-k,b:offset,sign:'<=',c:offset-k*l},{a:k,b:-offset,sign:'<',c:k*u-offset}];
   out.push(make(aid,'進階',['及','分式','除以負數'],`解 $\\frac{${linear(-k,offset)}}{${k}}\\le\\frac{${offset-k*l}}{${k}}$ 及 $\\frac{${linear(k,-offset)}}{${k}}<\\frac{${k*u-offset}}{${k}}$。`,`兩式先乘正數 ${k} 去分母，方向不變。第一式再除以負數 $-${k}$ 時才反號，最後取交集。`,choices(aid,[[s2],[interval(null,l,false,true)],[interval(l,u,false,true)],[interval(null,u,false,false),interval(l,null,true,false)]],['忘記反轉不等號','端點錯誤','及或調轉']),`去分母後，第一式得 $x\\ge${l}$；第二式得 $x<${u}$。共同範圍為 ${intervalText(s2)}。`,cs));
  }
  for(let mask=0;mask<2;mask++){
   const lc=!!mask,uc=!mask,id=`G-O-${l}-${u}-${mask}`,solution=[interval(null,l,false,lc),interval(u,null,uc,false)],cs:Condition[]=[{a:2,b:1,sign:lc?'<=':'<',c:2*l+1},{a:3,b:-2,sign:uc?'>=':'>',c:3*u-2}];
   out.push(make(id,'標準',['或','分離區間'],`解 $2x+1${lc?'\\le':'<'}${2*l+1}$ 或 $3x-2${uc?'\\ge':'>'}${3*u-2}$。`,'先分別整理兩式，留意每式是否包含等號。「或」表示至少符合一式，合併左右兩段範圍。',choices(id,[solution,[],[interval(l,u,lc,uc)],[interval(null,l,false,!lc),interval(u,null,!uc,false)]],['及或調轉','錯取中間範圍','端點錯誤']),`第一式得 ${intervalText(solution[0])}；第二式得 ${intervalText(solution[1])}。用「或」合併兩段，不能取中間範圍。`,cs,'or'));
  }
 }
 for(let lower=1;lower<=5;lower++)for(let span=3;span<=6;span++)for(let price=2;price<=4;price++){
  const upper=lower+span,fixed=5+price,id=`G-W-${lower}-${upper}-${price}`,n=span;
  const options:Option[]=[n,n-1,n+1,n+2].map((v,i)=>({optionId:`${id}-${'ABCD'[i]}`,text:`${v} 個`,numericValue:v,misconceptionTag:i?['漏算整數','端點錯誤','未處理固定費用'][i-1]:null}));
  const q=make(id,'進階',['應用','整數個數'],`活動收固定費 ${fixed} 元，另每張卡 ${price} 元。總費用超過 ${fixed+price*lower} 元但不超過 ${fixed+price*upper} 元。購買卡的張數 $n$ 有多少個可能的整數值？`,`先用「${fixed}+${price}n」表示總費用。「超過」不包括等號，「不超過」包括等號。解出範圍後逐一數正整數。`,options,`由 $${fixed+price*lower}<${fixed}+${price}n\\le${fixed+price*upper}$ 得 $${lower}<n\\le${upper}$。整數由 ${lower+1} 至 ${upper}，共有 ${n} 個。`,[{a:price,b:fixed,sign:'>',c:fixed+price*lower},{a:price,b:fixed,sign:'<=',c:fixed+price*upper}]);q.check!.integerOnly=true;out.push(q);
 }
 return out;
}
