export type TopType='attack'|'balance'|'defense';
export type SpinDirection='left'|'right';
export const TOP_TYPES={
  attack:{name:'攻擊型',damage:4,armor:-1,drain:2.5,description:'攻擊 4 · 每次承傷 +1 · 每秒耗旋 2.5'},
  balance:{name:'平衡型',damage:3,armor:0,drain:2,description:'攻擊 3 · 標準承傷 · 每秒耗旋 2'},
  defense:{name:'防禦型',damage:2,armor:1,drain:1.8,description:'攻擊 2 · 每次承傷 −1 · 每秒耗旋 1.8'}
} as const;
export const TOPS:{name:string;color:string;type:TopType}[]=[
  {name:'霆光',color:'#50e9ef',type:'balance'},
  {name:'霜衡',color:'#88b4ff',type:'balance'},
  {name:'燼鋒',color:'#ff9069',type:'attack'},
  {name:'紫電',color:'#c7a0ff',type:'attack'},
  {name:'森盾',color:'#8be0aa',type:'defense'},
  {name:'金穹',color:'#f2ce73',type:'defense'}
];
export const NPC_LEVELS={
  easy:{name:'練習伙伴',accuracy:.48,minDelay:.52,maxDelay:.85},
  normal:{name:'旋鬥對手',accuracy:.7,minDelay:.35,maxDelay:.7},
  hard:{name:'高手挑戰',accuracy:.88,minDelay:.2,maxDelay:.5}
} as const;
export type NpcLevel=keyof typeof NPC_LEVELS;
export const HINTS={fifty:'50/50',clue:'解題提示',time:'加時 5 秒'} as const;
export type HintKind=keyof typeof HINTS;
// These prompts teach the method without giving the answer or its numerical bounds.
export function learningClue(tags:string[]):string{
  if(tags.includes('三角不等式'))return '第三邊要大於另外兩邊之差的絕對值，並小於兩邊之和；兩端都不能取等號。';
  if(tags.includes('數線'))return '先看陰影範圍，再檢查端點：≤、≥ 用實心點；<、> 用空心點。';
  if(tags.includes('幾何應用'))return '先用長 × 闊寫出面積，再把面積的下限和上限各寫成不等式。';
  if(tags.includes('應用'))return '把固定費用與每件費用相加，按「超過」和「不超過」列出兩個條件，再找整數。';
  if(tags.includes('及或混合'))return '先處理引號內的「及」，取共同範圍；再處理外面的「或」，合併範圍。';
  if(tags.includes('除以負數'))return '乘或除以負數時，不等號方向必須反轉。先分別解兩式，再按「及／或」合併。';
  if(tags.includes('最大負整數')||tags.includes('最小正整數'))return '先確定正數或負數的限制，把分數界限化成小數，再逐個檢查鄰近整數。';
  if(tags.includes('文字轉不等式'))return '「不少於」包含等號；「少於」不包含等號。把兩個條件同時放在數線上。';
  if(tags.includes('整數解')||tags.includes('整數個數'))return '先求完整的解集，檢查端點是否包括，再在指定範圍逐一列出整數，避免漏算。';
  if(tags.includes('連鎖不等式'))return '三部分必須同時做相同運算。乘或除以負數時，兩個不等號都要反轉。';
  if(tags.includes('或'))return '「或」代表至少滿足一個條件，取兩段範圍的聯集。較小範圍可能已包含在較大範圍內。';
  return '「及」代表同時滿足所有條件，取數線的重疊部分。最後檢查每個端點是否包含。';
}
