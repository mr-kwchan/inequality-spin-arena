import type {MatchController} from './core';
import {TOPS,TOP_TYPES,HINTS} from './tops';
const safeText=(value:unknown)=>{const s=String(value??'');return /^[=+@-]/.test(s)?"'"+s:s;};
const cell=(value:unknown)=>`"${safeText(value).replaceAll('"','""')}"`;
export function matchCSV(game:MatchController):string{
 const rows:unknown[][]=[['場次','開始時間','模式','玩家','陀螺','類型','旋向','題序','題號','題目','難度','選擇答案','正確答案','結果','用時（秒）','已用提示','錯誤類型']];
 for(const [i,r]of game.records.entries())if(r.rewardsApplied){const q=r.question;for(const [id,a]of r.answers.entries()){
  const selected=q.options.find(o=>o.optionId===a.optionId),correct=q.options.find(o=>o.optionId===q.correctOptionId)!,p=game.players[id],top=TOPS[p.skin];
  rows.push([game.matchId,game.startedAtISO,game.mode==='solo'?'單人 NPC':'雙人同機',game.isNpc(id)?'NPC':`P${id+1}`,top.name,TOP_TYPES[top.type].name,p.direction==='left'?'左旋':'右旋',i+1,q.questionId,q.prompt,q.difficulty,selected?.text??'',correct.text,{correct:'答對',wrong:'答錯',unanswered:'未作答'}[a.result],a.seconds===null?'':a.seconds.toFixed(2),a.hints.map(h=>HINTS[h]).join('／'),a.result==='unanswered'?'未鎖定答案':selected?.misconceptionTag??'']);
 }}
 return '\uFEFF'+rows.map(row=>row.map(cell).join(',')).join('\r\n')+'\r\n';
}
