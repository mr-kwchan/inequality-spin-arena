import type {Question,Interval} from './question-types';
const escape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
export function numberLineSVG(q:Question,optionId:string):string{
 const d=q.diagram?.options.find(o=>o.optionId===optionId);if(!d||!q.diagram)return '';
 const segments:Interval[]=d.segments??[{lower:d.lower??null,upper:d.upper??null,lowerClosed:!!d.lowerClosed,upperClosed:!!d.upperClosed}];
 let [min,max]=q.diagram.domain;if(!Number.isFinite(min)||!Number.isFinite(max)||min>=max){const bounds=segments.flatMap(s=>[s.lower,s.upper].filter((x):x is number=>x!==null&&Number.isFinite(x)));min=Math.min(-1,...bounds)-2;max=Math.max(1,...bounds)+2;}
 const left=20,right=300,y=30,x=(n:number)=>left+(n-min)/(max-min)*(right-left),labels=new Map<number,number>();
 const lines=segments.map(s=>{
  const a=s.lower===null?left:x(s.lower),b=s.upper===null?right:x(s.upper);
  let svg=`<path class="interval" d="M${a} ${y}H${b}"/>`;
  for(const [v,closed,edge]of [[s.lower,s.lowerClosed,'left'],[s.upper,s.upperClosed,'right']] as const){
   if(v===null){const px=edge==='left'?left:right,dx=edge==='left'?6:-6;svg+=`<path class="interval-arrow" d="M${px+dx} ${y-5}L${px} ${y}L${px+dx} ${y+5}"/>`;}
   else{labels.set(v,x(v));svg+=`<circle class="endpoint ${closed?'closed':''}" data-value="${v}" cx="${x(v)}" cy="${y}" r="5"/>`;}
  }
  return svg;
 }).join('');
 return `<svg class="number-line" viewBox="0 0 320 72" role="img" aria-label="${escape(q.options.find(o=>o.optionId===optionId)?.text??'數線')}"><path class="axis" d="M12 ${y}H308m-6-5 6 5-6 5M18 ${y-5}l-6 5 6 5"/>${lines}${[...labels].map(([v,px])=>`<text x="${px}" y="61">${String(v).replace('-','−')}</text>`).join('')}</svg>`;
}
