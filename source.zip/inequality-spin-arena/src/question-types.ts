export interface Interval {lower:number|null;upper:number|null;lowerClosed:boolean;upperClosed:boolean}
export interface Option {optionId:string;text:string;misconceptionTag:string|null;solution?:Interval[];numericValue?:number}
export interface DiagramOption extends Partial<Interval>{optionId:string;segments?:Interval[]}
export interface Condition {a:number;b:number;sign:'<'|'<='|'>'|'>=';c:number}
export interface Question {
 questionId:string;difficulty:string;topicTags:string[];misconceptionTags:string[];prompt:string;hint:string;
 options:Option[];correctOptionId:string;explanation:string;
 diagram?:{type:string;domain:number[];options:DiagramOption[]};
 check?:{conditions:Condition[];logic:'and'|'or';integerOnly?:boolean};
}
