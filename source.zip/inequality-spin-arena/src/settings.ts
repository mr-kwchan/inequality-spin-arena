/** Shared learning and battle rules. Top modifiers are declared in tops.ts. */
export const BALANCE=Object.freeze({
 maxHP:120,maxSpin:100,spinDrain:2,maxEnergy:3,maxShield:6,
 battleSeconds:10,clashSeconds:[2,4,6,8,10],countdownSeconds:3,
 revealSeconds:8,resumeSeconds:2,skillFreezeSeconds:0.8,
 baseDamage:1,correctAttack:1,speedAttack:1,speedTieSeconds:0.15,
 heal:20,spinReward:20,skillDamage:18,fixedStep:1/60,interruptionSeconds:3
});
export interface Settings{
 difficulty:'mixed'|'basic'|'standard'|'advanced';questionSeconds:10|15|20;questionCount:4|6|8;
 completeAllQuestions:boolean;revealSeconds:0|6|8|12;advancedExtraTime:boolean;
 music:number;effects:number;muted:boolean;reducedEffects:boolean;cameraShake:boolean;vibration:boolean;
}
export const DEFAULT_SETTINGS:Settings={difficulty:'mixed',questionSeconds:15,questionCount:6,completeAllQuestions:true,revealSeconds:0,advancedExtraTime:true,music:.16,effects:.55,muted:false,reducedEffects:false,cameraShake:true,vibration:false};
