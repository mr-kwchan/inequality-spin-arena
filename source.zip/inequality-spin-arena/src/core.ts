import {TOPS,TOP_TYPES,NPC_LEVELS,HINTS,type SpinDirection,type NpcLevel,type HintKind} from './tops';
import {BALANCE as B,DEFAULT_SETTINGS,type Settings} from './settings';
import bank from './questions.json';
export type Phase='TITLE'|'LOBBY'|'COUNTDOWN'|'BATTLE'|'QUESTION_LOADING'|'QUESTION_ACTIVE'|'REVEAL'|'RESULTS'|'REVIEW'|'ERROR';
export interface Option {optionId:string;text:string;misconceptionTag:string|null}
export interface DiagramOption {optionId:string;lower:number;upper:number;lowerClosed:boolean;upperClosed:boolean}
export interface Question {questionId:string;difficulty:string;topicTags:string[];misconceptionTags:string[];prompt:string;options:Option[];correctOptionId:string;explanation:string;diagram?:{type:string;domain:number[];options:DiagramOption[]}}
export const QUESTIONS=bank as Question[];
export interface Player {direction:SpinDirection;hintsUsed:HintKind[];eliminated:string[];clueVisible:boolean;extraSeconds:number;playerId:number;hp:number;spin:number;energy:number;shield:number;attackBonus:number;firstHitBonus:number;pendingSkill:boolean;skillUsed:boolean;selectedOptionId:string|null;lockedOptionId:string|null;lockedAt:number|null;ready:boolean;skin:number}
export interface Answer {optionId:string|null;result:'correct'|'wrong'|'unanswered';seconds:number|null;speed:boolean;hints:HintKind[]}
export interface QuestionRecord {questionId:string;orders:[string[],string[]];startedAt:number|null;answers:Answer[];rewardsApplied:boolean}
export interface Input {matchId:string;questionId:string;playerId:number;optionId:string}
export interface GameEvent {type:string;[key:string]:unknown}
export interface Outcome {winner:number|null;reason:string}
export function seededRandom(seed:number) {let a=seed>>>0;return ()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
export function shuffle<T>(list:T[],rng:()=>number):T[]{const a=[...list];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
export function drawQuestions(s:Settings,rng:()=>number):Question[]{
  const take=(d:string,n:number)=>shuffle(QUESTIONS.filter(q=>q.difficulty===d),rng).slice(0,n);
  if(s.difficulty!=='mixed')return take(s.difficulty==='basic'?'基礎':'標準',s.questionCount);
  const split=s.questionCount===4?[1,2,1]:s.questionCount===8?[3,4,1]:[2,3,1];
  return [...take('基礎',split[0]),...take('標準',split[1]),...take('進階',split[2])];
}
function freshPlayer(id:number,skin=id):Player{return {direction:id===0?'right':'left',hintsUsed:[],eliminated:[],clueVisible:false,extraSeconds:0,playerId:id,hp:B.maxHP,spin:B.maxSpin,energy:0,shield:0,attackBonus:0,firstHitBonus:0,pendingSkill:false,skillUsed:false,selectedOptionId:null,lockedOptionId:null,lockedAt:null,ready:false,skin};}
export function normalDamage(p:Player){return Math.max(1,TOP_TYPES[TOPS[p.skin].type].damage+p.attackBonus+p.firstHitBonus-(p.spin===0?2:p.spin<30?1:0));}
export function stats(records:QuestionRecord[],id:number){
  const answers=records.filter(r=>r.rewardsApplied).map(r=>r.answers[id]);
  const correct=answers.filter(a=>a.result==='correct');
  return {correct:correct.length,wrong:answers.filter(a=>a.result==='wrong').length,unanswered:answers.filter(a=>a.result==='unanswered').length,average:correct.length?correct.reduce((n,a)=>n+a.seconds!,0)/correct.length:null};
}
export class MatchController {
  mode:'duo'|'solo'='duo'; npcLevel:NpcLevel='normal'; private npcRng=seededRandom(2); private hintRng=seededRandom(3); private npcPlan:{at:number;optionId:string}|null=null;
  phase:Phase='TITLE'; phaseTime=0; clock=0; players=[freshPlayer(0),freshPlayer(1)];
  matchId=''; seed=1; settings:Settings={...DEFAULT_SETTINGS}; sequence:Question[]=[]; records:QuestionRecord[]=[];
  battleIndex=0; clashIndex=0; skillFreeze=0; paused=false; pauseReason=''; resumeReady=[false,false];
  outcome:Outcome|null=null; events:GameEvent[]=[]; private rng=seededRandom(1); private handled=new Set<string>();
  get question(){return this.sequence[this.records.length-1];}
  get record(){return this.records.at(-1);}
  get live(){return ['COUNTDOWN','BATTLE','QUESTION_LOADING','QUESTION_ACTIVE','REVEAL'].includes(this.phase);}
  emit(type:string,data:Record<string,unknown>={}){this.events.push({type,...data});}
  drainEvents(){return this.events.splice(0);}
  transition(phase:Phase){this.phase=phase;this.phaseTime=0;this.emit('PHASE',{phase});}
  lobby(seed:number=Date.now()>>>0,fixedIds?:string[]){
    const choices=this.players.map(p=>({skin:p.skin,direction:p.direction})); this.seed=seed;this.rng=seededRandom(seed);this.npcRng=seededRandom(seed^0x1A2B3C4D);this.hintRng=seededRandom(seed^0x5E6F1234);this.npcPlan=null;
    this.matchId=`match-${seed}-${Math.random().toString(36).slice(2,9)}`;
    this.players=choices.map((p,id)=>({...freshPlayer(id,p.skin),direction:p.direction}));if(this.mode==='solo')this.players[1].ready=true;this.clock=0;this.battleIndex=0;this.clashIndex=0;
    this.skillFreeze=0;this.paused=false;this.pauseReason='';this.resumeReady=[false,false];this.outcome=null;this.records=[];this.handled.clear();this.events=[];
    this.sequence=fixedIds?fixedIds.map(id=>{const q=QUESTIONS.find(q=>q.questionId===id);if(!q)throw Error(`Unknown question ${id}`);return q;}):drawQuestions(this.settings,this.rng);
    this.transition('LOBBY');
  }
  home(){this.lobby();this.transition('TITLE');}
  ready(id:number){if(this.phase!=='LOBBY'||this.paused||this.isNpc(id)||!this.players[id])return;this.players[id].ready=!this.players[id].ready;this.emit('READY',{id});if(this.players.every(p=>p.ready))this.transition('COUNTDOWN');}
  isNpc(id:number){return this.mode==='solo'&&id===1;}
  canConfigure(id:number){return !!this.players[id]&&this.phase==='LOBBY'&&(this.isNpc(id)?!this.players[0].ready:!this.players[id].ready);}
  setMode(mode:'duo'|'solo'){if(!['TITLE','LOBBY'].includes(this.phase)||!['duo','solo'].includes(mode))return;this.mode=mode;if(this.phase==='LOBBY')this.lobby(this.seed);}
  setNpcLevel(level:NpcLevel){if(['TITLE','LOBBY'].includes(this.phase)&&level in NPC_LEVELS){this.npcLevel=level;this.emit('CONFIG');}}
  setTop(id:number,index:number){if(this.canConfigure(id)&&Number.isInteger(index)&&TOPS[index]){this.players[id].skin=index;this.emit('SKIN',{id});}}
  skin(id:number){if(this.players[id])this.setTop(id,(this.players[id].skin+1)%TOPS.length);}
  setDirection(id:number,direction:SpinDirection){if(this.canConfigure(id)&&(direction==='left'||direction==='right')){this.players[id].direction=direction;this.emit('SKIN',{id});}}
  deadline(id:number){return this.settings.questionSeconds+this.players[id].extraSeconds;}
  remaining(id:number){return Math.max(0,this.deadline(id)-this.phaseTime);}
  get questionRemaining(){return Math.max(0,...this.players.map(p=>p.lockedOptionId?0:this.remaining(p.playerId)));}
  useHint(id:number,kind:HintKind,matchId=this.matchId,questionId=this.question?.questionId){
    const p=this.players[id];
    if(!p||this.isNpc(id)||this.paused||this.phase!=='QUESTION_ACTIVE'||this.remaining(id)<=1e-7||p.lockedOptionId||!(kind in HINTS)||p.hintsUsed.includes(kind)||matchId!==this.matchId||questionId!==this.question.questionId)return false;
    p.hintsUsed.push(kind);
    if(kind==='fifty'){
      p.eliminated=shuffle(this.record!.orders[id].filter(o=>o!==this.question.correctOptionId),this.hintRng).slice(0,2);
      if(p.selectedOptionId&&p.eliminated.includes(p.selectedOptionId))p.selectedOptionId=null;
    }else if(kind==='clue')p.clueVisible=true;
    else p.extraSeconds=5;
    this.emit('HINT',{id,kind});return true;
  }
  private npcQuestion(){
    if(!this.npcPlan||this.players[1].lockedOptionId||this.phaseTime<this.npcPlan.at)return;
    const optionId=this.npcPlan.optionId;this.npcPlan=null;
    this.selectFor(this.context(1,optionId),true);this.lockFor(this.context(1,optionId),true);
  }
  private allFinished(){return this.players.every(p=>p.lockedOptionId!==null||this.remaining(p.playerId)<=1e-7);}

  pause(reason='賽局已暫停'){if(!this.live||this.paused)return;this.paused=true;this.pauseReason=reason;this.resumeReady=[false,this.mode==='solo'];this.emit('PAUSE');}
  confirmResume(id:number){if(!this.paused)return false;this.resumeReady[id]=true;return this.resumeReady.every(Boolean);}
  resume(){if(!this.paused||!this.resumeReady.every(Boolean))return;this.paused=false;this.resumeReady=[false,false];this.emit('RESUME');}
  activateQuestion(){if(this.phase!=='QUESTION_LOADING'||this.paused)return;this.transition('QUESTION_ACTIVE');this.record!.startedAt=this.clock;if(this.mode==='solo'){const level=NPC_LEVELS[this.npcLevel],q=this.question;const chance=level.accuracy-(q.difficulty==='進階'?.12:q.difficulty==='標準'?.04:0);const correct=this.npcRng()<chance;const wrong=q.options.filter(o=>o.optionId!==q.correctOptionId);this.npcPlan={at:(level.minDelay+this.npcRng()*(level.maxDelay-level.minDelay))*this.settings.questionSeconds,optionId:correct?q.correctOptionId:wrong[Math.floor(this.npcRng()*wrong.length)].optionId};}}
  context(id:number,optionId:string):Input{return {matchId:this.matchId,questionId:this.question?.questionId??'',playerId:id,optionId};}
  private valid(input:Input,npc=false){return (npc||!this.isNpc(input.playerId))&&!this.paused&&this.phase==='QUESTION_ACTIVE'&&(input.playerId===0||input.playerId===1)&&this.remaining(input.playerId)>1e-7&&input.matchId===this.matchId&&input.questionId===this.question.questionId&&(input.playerId===0||input.playerId===1)&&this.record!.orders[input.playerId].includes(input.optionId)&&!this.players[input.playerId].eliminated.includes(input.optionId)&&this.players[input.playerId].lockedOptionId===null;}
  select(input:Input){return this.selectFor(input,false);}
  private selectFor(input:Input,npc:boolean){if(!this.valid(input,npc))return false;this.players[input.playerId].selectedOptionId=input.optionId;this.emit('SELECT',{id:input.playerId});return true;}
  lock(input:Input){return this.lockFor(input,false);}
  private lockFor(input:Input,npc:boolean){if(!this.valid(input,npc)||this.players[input.playerId].selectedOptionId!==input.optionId)return false;const p=this.players[input.playerId];p.lockedOptionId=input.optionId;p.lockedAt=this.phaseTime;this.emit('LOCK',{id:input.playerId});if(this.allFinished())this.resolveQuestion();return true;}
  skill(id:number,matchId=this.matchId,battleIndex=this.battleIndex,npc=false){
    if(this.isNpc(id)&&!npc)return false;const p=this.players[id];if(!p||this.paused||this.phase!=='BATTLE'||this.skillFreeze>0||this.phaseTime>=B.battleSeconds||this.clashIndex>=B.clashSeconds.length||matchId!==this.matchId||battleIndex!==this.battleIndex||p.energy<B.maxEnergy||p.skillUsed)return false;
    p.energy-=B.maxEnergy;p.pendingSkill=true;p.skillUsed=true;this.emit('SKILL_QUEUED',{id});return true;
  }
  advance(seconds:number){if(this.paused||!this.live||seconds<=0)return;let left=seconds;while(left>1e-8&&!this.paused&&this.live){const dt=Math.min(left,B.fixedStep);this.step(dt);left-=dt;}}
  private step(dt:number){
    if(this.phase==='QUESTION_LOADING')return;
    this.clock+=dt;
    if(this.phase==='BATTLE'&&this.skillFreeze>0){this.skillFreeze=Math.max(0,this.skillFreeze-dt);if(this.skillFreeze===0&&this.phaseTime>=B.battleSeconds-1e-7)this.endBattle();return;}
    this.phaseTime+=dt;
    if(this.phase==='COUNTDOWN'&&this.phaseTime>=B.countdownSeconds-1e-7){this.beginBattle();return;}
    if(this.phase==='BATTLE'){
      if(this.mode==='solo'&&this.phaseTime>=1)this.skill(1,this.matchId,this.battleIndex,true);
      const over=Math.max(0,this.phaseTime-B.battleSeconds);const drain=Math.max(0,dt-over)*B.spinDrain;
      for(const p of this.players){p.spin=Math.max(0,p.spin-drain*TOP_TYPES[TOPS[p.skin].type].drain/B.spinDrain);if(p.spin<1e-8)p.spin=0;}
      while(this.clashIndex<B.clashSeconds.length&&this.phaseTime>=B.clashSeconds[this.clashIndex]-1e-7){this.clash();if(this.phase!=='BATTLE')return;}
      if(this.phaseTime>=B.battleSeconds-1e-7&&this.skillFreeze===0)this.endBattle();
    }else if(this.phase==='QUESTION_ACTIVE'){this.npcQuestion();if(this.phase==='QUESTION_ACTIVE'&&this.allFinished())this.resolveQuestion();}
    else if(this.phase==='REVEAL'&&this.phaseTime>=B.revealSeconds-1e-7){this.battleIndex++;this.beginBattle();}
  }
  private beginBattle(){this.clashIndex=0;this.skillFreeze=0;for(const p of this.players){p.skillUsed=false;p.pendingSkill=false;}this.transition('BATTLE');}
  /** Both attack packets are calculated from the same snapshot, then applied together. */
  private clash(){
    const key=`${this.matchId}:clash:${this.battleIndex}:${this.clashIndex}`;this.clashIndex++;if(this.handled.has(key))return;this.handled.add(key);
    const snapshot=this.players.map(p=>({...p}));const outgoing=snapshot.map(p=>normalDamage(p)+(p.pendingSkill?B.skillDamage:0));
    const sameSpin=snapshot[0].direction===snapshot[1].direction;
    const packets=snapshot.map((p,id)=>Math.max(1,outgoing[1-id]+(sameSpin?1:0)-TOP_TYPES[TOPS[p.skin].type].armor));
    const damage=snapshot.map((p,id)=>Math.max(0,packets[id]-p.shield));
    if(!sameSpin){const difference=snapshot[0].spin-snapshot[1].spin,transfer=Math.min(1,Math.abs(difference)/2);this.players[0].spin-=Math.sign(difference)*transfer;this.players[1].spin+=Math.sign(difference)*transfer;}
    this.players.forEach((p,id)=>{p.hp=Math.max(0,snapshot[id].hp-damage[id]);p.shield=Math.max(0,snapshot[id].shield-packets[id]);p.firstHitBonus=0;p.pendingSkill=false;});
    const skills=snapshot.map(p=>p.pendingSkill);this.emit('CLASH',{damage,skills,node:this.clashIndex,battleIndex:this.battleIndex});
    if(this.players.some(p=>p.hp===0)){this.finish();return;}
    if(skills.some(Boolean))this.skillFreeze=B.skillFreezeSeconds;
  }
  private endBattle(){
    for(const p of this.players){p.shield=0;p.attackBonus=0;p.firstHitBonus=0;p.pendingSkill=false;}
    if(this.records.length>=this.sequence.length){this.finish();return;}
    const q=this.sequence[this.records.length];
    this.records.push({questionId:q.questionId,orders:[shuffle(q.options.map(o=>o.optionId),this.rng),shuffle(q.options.map(o=>o.optionId),this.rng)],startedAt:null,answers:[],rewardsApplied:false});
    for(const p of this.players){p.selectedOptionId=null;p.lockedOptionId=null;p.lockedAt=null;p.eliminated=[];p.clueVisible=false;p.extraSeconds=0;}
    this.transition('QUESTION_LOADING');
  }
  private resolveQuestion(){
    const r=this.record!;if(r.rewardsApplied)return;const key=`${this.matchId}:question:${r.questionId}`;if(this.handled.has(key))return;this.handled.add(key);
    r.answers=this.players.map(p=>({optionId:p.lockedOptionId,result:p.lockedOptionId===null?'unanswered':p.lockedOptionId===this.question.correctOptionId?'correct':'wrong',seconds:p.lockedAt,speed:false,hints:[...p.hintsUsed].filter(h=>h==='fifty'?p.eliminated.length>0:h==='clue'?p.clueVisible:p.extraSeconds>0)}));
    if(r.answers.every(a=>a.result==='correct'&&a.hints.length===0)){const diff=r.answers[0].seconds!-r.answers[1].seconds!;if(Math.abs(diff)>B.speedTieSeconds+1e-8)r.answers[diff<0?0:1].speed=true;}
    r.answers.forEach((a,id)=>{if(a.result!=='correct')return;const p=this.players[id];p.hp=Math.min(B.maxHP,p.hp+B.heal);p.spin=Math.min(B.maxSpin,p.spin+B.spinReward);p.shield=B.maxShield;p.attackBonus=B.correctAttack;p.firstHitBonus=a.speed?B.speedAttack:0;p.energy=Math.min(B.maxEnergy,p.energy+1);});
    r.rewardsApplied=true;this.transition('REVEAL');this.emit('QUESTION_RESOLVED',{answers:r.answers});
  }
  private finish(){
    const [a,b]=this.players;const sa=stats(this.records,0),sb=stats(this.records,1);let winner:number|null=null,reason='雙方表現相同，今場平手';
    if(a.hp===0&&b.hp===0)reason='雙方在同一碰撞節點耗盡 HP';
    else if(a.hp===0||b.hp===0){winner=a.hp>0?0:1;reason='對手的 HP 已耗盡';}
    else if(a.hp!==b.hp){winner=a.hp>b.hp?0:1;reason='剩餘 HP 較高';}
    else if(sa.correct!==sb.correct){winner=sa.correct>sb.correct?0:1;reason='HP 相同，答對題數較多';}
    else if(sa.average!==null&&sb.average!==null&&Math.abs(sa.average-sb.average)>B.speedTieSeconds+1e-8){winner=sa.average<sb.average?0:1;reason='HP 及答對題數相同，正確答案平均用時較短';}
    this.outcome={winner,reason};this.transition('RESULTS');
  }
}

/** Only foreground monotonic time is admitted. A long frame asks both players to resume. */
export class GameClock {
  previous:number|null=null;
  sample(now:number){if(this.previous===null){this.previous=now;return {delta:0,interrupted:false};}const delta=Math.max(0,(now-this.previous)/1000);this.previous=now;return {delta,interrupted:delta>B.interruptionSeconds};}
  reset(now:number){this.previous=now;}
}
