# 不等式旋鬥場 v1.2 — 開發與規則

## 建置與遊玩

```sh
npm ci
npm run check
npm run build
npm test
python -m http.server 8080 --directory dist
```

開啟 http://localhost:8080/。支援 WebGL 2 的桌面瀏覽器也可直接開啟自包含的 `dist/PLAY.html`。iPad 使用已發佈網址；檔案 App 的預覽不等同 Safari。

`npm run build:pages` 會產生獨立 `pages/` 平面資料夾。所有 JS／CSS 以內容雜湊命名；KaTeX 使用同站 WOFF2 字體，無外部 CDN。`scripts/export-pages.mjs` 可接受自訂輸出路徑。更新既有 GitHub Pages 根目錄時，須連同 index.html、雜湊檔案及字體一起發佈。

## 學習規則

每段戰鬥 10 秒，第 2／4／6／8／10 秒碰撞。答對回復 20 HP、20 旋轉值、6 護盾、下一段攻擊 +1 與 1 格能量。雙方均未用提示且均答對時，超過 0.15 秒的速度差帶來下一段首次碰撞 +1。能量滿 3 格可預約技能，下一個碰撞額外造成 18 傷害。所有傷害以同一快照同步結算。

預設「完成所有題目」開啟，HP 0 不會中止賽局，後續答對仍可補血。最後一題後仍有一段戰鬥；依答對題數、HP、正確作答平均時間判勝。若關閉該設定，HP 0 可提早完場，先依 HP 再依答對題數與時間判勝。

預設每題 15 秒，進階自動加 5 秒（可關閉）。提示加時另為個人加 5 秒。預設解說手動繼續，單人自己確認，雙人各自確認；可改為 6／8／12 秒，自動倒數亦容許提前確認。

每位真人玩家每局各有一次 50/50、針對題目的解題提示與加時。NPC 使用獨立亂數流，不讀取玩家答案或提示，自動答題和發動技能。六款陀螺及左右旋配置見 README。

## 資料與檔案

| 檔案 | 用途 |
| --- | --- |
| `src/settings.ts` | 預設設定與 HP／時間／技能等共同數值 |
| `src/tops.ts` | 六款陀螺、攻防數值、旋向、NPC 難度與提示 |
| `src/question-types.ts` | 題目、區間與數線型別 |
| `src/questions.json` | 36 條固定題、穩定 optionId、提示、解說、錯誤標籤 |
| `src/generator.ts` | 780 條穩定 ID 生成題與針對性干擾項 |
| `src/diagrams.ts` | 依 domain／端點／開閉圓點繪製 SVG，支援多段及無限界 |
| `src/core.ts` | 唯一賽局狀態、抽題、判分、同步碰撞、NPC 與題目快照 |
| `src/app.ts` | 持久選答按鈕、滑鼠／多指／鍵盤、教師設定、揭曉與重溫 |
| `src/export.ts` | CSV 序列化與下載 |
| `src/arena.ts` | 真正 Three.js 場景、旋轉、碰撞與特效 |
| `tests/` | 核心、數學、DOM、CSV 與場景資料驗證 |

固定題及生成題共 816 條；生成題包括數線 180、區間記法 180、負係數交集 135、分數進階交集 135、或題 90、整數應用 60。同場題號不重複，依最近 96 題減少跨場重複，並避免同一難度只抽到同類題。混合模式保留最後一條進階題；全進階每題均為進階。

新增題目須維持唯一正解和四個不等價選項，為錯誤選項填寫 misconceptionTag，並附有針對性 hint。`correctOptionId` 指向固定 optionId，畫面 A–D 只是亂序位置。數線的 `domain` 決定座標，端點 `null` 表示無限，不可在 JSON 寫 Infinity。修改題目須更新獨立數學核對。

本場作答與題目快照只留在記憶體。CSV 在離開前下載，包含 NPC 資料以辨識對戰。教師設定與最近題號保存在 localStorage；沒有學生登入、答案上傳、資料庫、AI API、Service Worker 或排行榜。

## 打包與驗收

```sh
python scripts/package.py /absolute/path/source.zip
```

先完成 check、build、test，再打包。工具僅收錄允許的原始碼、dist、文件、測試及授權，不含 node_modules、Git 歷史、主機設定或憑證。真實瀏覽器介面 QA 的測試頁由 `node tests/ui-preview.mjs` 產生，明確標示 3D 替身；完成後必須重新 build 清除。正式發佈維持真正 WebGL 場景。

完整證據與實機限制見 ACCEPTANCE.md。唯讀 `window.arenaDiagnostics` 可檢查階段、題號、幀率及 GPU 計數，不暴露可改寫的賽局控制器或正解。
