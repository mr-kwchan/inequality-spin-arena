"""Export game and editable source without host identity, credentials or dependencies."""
from pathlib import Path
import sys
import zipfile
root=Path(__file__).resolve().parent.parent
target=Path(sys.argv[1]).resolve()
target.parent.mkdir(parents=True,exist_ok=True)
allowed=['src','dist','scripts','tests','docs','licenses','.github','index.html','.nojekyll','.gitignore','README.md','CHANGELOG.md','THIRD_PARTY_LICENSES.txt','package.json','package-lock.json','tsconfig.json']
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name in allowed:
  item=root/name
  for file in sorted(item.rglob('*')) if item.is_dir() else [item]:
   if file.is_file() and file.suffix!='.map' and '__pycache__' not in file.parts:
    archive.write(file,'inequality-spin-arena/'+file.relative_to(root).as_posix())
print(f'{target}: {target.stat().st_size:,} bytes')
