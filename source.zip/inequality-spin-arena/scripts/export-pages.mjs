import {cp,mkdir,readdir,rm} from 'node:fs/promises';
import path from 'node:path';
const output=path.resolve(process.argv[2]??'pages');
if(output===process.cwd()||output===path.resolve('dist'))throw Error('Use a separate GitHub Pages staging directory.');
await rm(output,{recursive:true,force:true});await mkdir(output,{recursive:true});
for(const file of await readdir('dist'))if(file!=='PLAY.html')await cp(`dist/${file}`,path.join(output,file));
console.log(`GitHub Pages files prepared in ${output}`);
