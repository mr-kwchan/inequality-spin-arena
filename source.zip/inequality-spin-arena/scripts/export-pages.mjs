import { copyFile, writeFile } from 'node:fs/promises';

// A single self-contained entry works at any GitHub Pages project subpath.
await copyFile('dist/PLAY.html', 'index.html');
await writeFile('.nojekyll', '');
console.log('Updated root index.html from the verified static build.');
