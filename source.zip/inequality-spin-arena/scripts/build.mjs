import {build} from 'esbuild';
import {cp,mkdir,readFile,writeFile,rm,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex').slice(0,10);
await rm('dist',{recursive:true,force:true});await mkdir('dist',{recursive:true});
const compiled=await build({entryPoints:['src/app.ts'],bundle:true,minify:true,write:false,target:['safari16','chrome110'],format:'esm'});
const js=compiled.outputFiles[0].text,jsName=`arena-${hash(js)}.js`,css=await readFile('src/style.css','utf8'),cssName=`arena-${hash(css)}.css`;
let mathCSS=await readFile('node_modules/katex/dist/katex.min.css','utf8');
// Modern Safari and Chrome need only WOFF2. Fonts load on demand and can be cached.
mathCSS=mathCSS.replace(/src:([^;{}]+)/g,(all,src)=>{const match=src.match(/url\(([^)]+\.woff2)\)\s*format\(["']woff2["']\)/);return match?`src:url(./${match[1].split('/').at(-1)}) format("woff2");font-display:swap`:all;});
const mathName=`katex-${hash(mathCSS)}.css`,fontNames=[...new Set([...mathCSS.matchAll(/url\(\.\/([^)]+\.woff2)\)/g)].map(m=>m[1]))];
for(const name of fontNames)await cp(`node_modules/katex/dist/fonts/${name}`,`dist/${name}`);
await Promise.all([writeFile(`dist/${jsName}`,js),writeFile(`dist/${cssName}`,css),writeFile(`dist/${mathName}`,mathCSS),cp('node_modules/three/LICENSE','dist/THREE-LICENSE.txt'),cp('node_modules/katex/LICENSE','dist/KATEX-LICENSE.txt')]);
const source=await readFile('src/index.html','utf8'),html=source.replace('./assets/katex.min.css',`./${mathName}`).replace('./assets/style.css',`./${cssName}`).replace('./assets/app.js',`./${jsName}`);
await writeFile('dist/index.html',html);await writeFile('dist/.nojekyll','');
await cp('cover.png','dist/cover.png');
let embedded=mathCSS;for(const name of fontNames){const bytes=await readFile(`dist/${name}`);embedded=embedded.replaceAll(`url(./${name})`,`url(data:font/woff2;base64,${bytes.toString('base64')})`);}
const portable=source.replace('<link rel="stylesheet" href="./assets/katex.min.css">',()=>`<style>${embedded}</style>`).replace('<link rel="stylesheet" href="./assets/style.css">',()=>`<style>${css}</style>`).replace('<script type="module" src="./assets/app.js"></script>',()=>`<script type="module">${js.replace(/<\/script/gi,'<\\/script')}</script>`);
await writeFile('dist/PLAY.html',portable);
await build({entryPoints:['src/core.ts'],bundle:true,platform:'node',format:'esm',outfile:'tests/core-built.mjs'});
console.log(`Built v1.2: index.html ${Buffer.byteLength(html)} bytes, ${fontNames.length} external WOFF2 fonts, ${jsName}.`);
