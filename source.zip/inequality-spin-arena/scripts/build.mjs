import {build} from 'esbuild';
import {cp,mkdir,readFile,writeFile} from 'node:fs/promises';
await mkdir('dist/assets',{recursive:true});
await build({entryPoints:['src/app.ts'],bundle:true,minify:true,sourcemap:true,target:['safari16','chrome110'],format:'esm',outfile:'dist/assets/app.js'});
await cp('src/style.css','dist/assets/style.css');
await cp('src/index.html','dist/index.html');
await cp('node_modules/katex/dist/katex.min.css','dist/assets/katex.min.css');
await cp('node_modules/katex/dist/fonts','dist/assets/fonts',{recursive:true});
await cp('node_modules/three/LICENSE','dist/assets/THREE-LICENSE.txt');
await cp('node_modules/katex/LICENSE','dist/assets/KATEX-LICENSE.txt');
// Inline the already bundled app and fonts for a genuinely self-contained desktop file.
let portable=await readFile('src/index.html','utf8');
let mathCSS=await readFile('dist/assets/katex.min.css','utf8');
const fontRefs=[...new Set([...mathCSS.matchAll(/url\((fonts\/[^)]+)\)/g)].map(m=>m[1]))];
for(const font of fontRefs){const bytes=await readFile('dist/assets/'+font);const type=font.endsWith('woff2')?'font/woff2':font.endsWith('woff')?'font/woff':'font/ttf';mathCSS=mathCSS.split('url('+font+')').join('url(data:'+type+';base64,'+bytes.toString('base64')+')');}
const css=await readFile('src/style.css','utf8');
portable=portable.replace('<link rel="stylesheet" href="./assets/katex.min.css">',()=>'<style>'+mathCSS+'</style>').replace('<link rel="stylesheet" href="./assets/style.css">',()=>'<style>'+css+'</style>');
const js=(await readFile('dist/assets/app.js','utf8')).replace(/\/\/# sourceMappingURL=.*$/m,'');portable=portable.replace('<script type="module" src="./assets/app.js"></script>',()=>'<script type="module">'+js.replace(/<\/script/gi,'<\\/script')+'</script>');
await writeFile('dist/PLAY.html',portable);
await build({entryPoints:['src/core.ts'],bundle:true,platform:'node',format:'esm',outfile:'tests/core-built.mjs'});
console.log('Built self-contained Three.js arena; no CDN or remote assets.');
