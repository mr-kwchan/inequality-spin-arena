import test from 'node:test';
import assert from 'node:assert/strict';
import katex from 'katex';
import {QUESTIONS} from './core-built.mjs';
// Independent mathematical oracle using the original inequalities, not the supplied answer key.
const predicates={
 Q01:x=>x>2&&x<=6,Q02:x=>x<-1||x>=3,Q03:x=>x>=-3&&x>1,Q04:x=>x<=4||x<=-2,
 Q05:x=>x<0&&x>=0,Q06:x=>x<=2||x>2,Q07:x=>x>=5&&x<=5,Q08:x=>x<4||x>4,
 Q12:x=>x>=2&&x<7,Q13:x=>2*x+1>5&&3*x-2<=10,Q14:x=>7-2*x>=1&&x+4>3,
 Q15:x=>-3*x<9||2*x+1<=-7,Q16:x=>2*(x-1)<=6&&5-x<4,Q17:x=>-2<3*x+1&&3*x+1<=7,
 Q18:x=>4*x-3>=9||2*x+5<1,Q19:x=>3*x+6<=0||x-5<0,Q20:x=>5-x>2&&2*x-4>=4,
 Q24:x=>(x-1)/2>=-1&&(3-x)/2>0,Q26:x=>5+9>x&&5+x>9&&9+x>5,
 Q27:x=>(2*x-1)/3<x+1&&4-x<=2*x+7,Q28:x=>(x>-3&&x<=1)||x>=4,
 Q29:x=>6*(x+1)>24&&6*(x+1)<=42
};
function rangePredicate(text){text=text.replaceAll('$','').replaceAll('\\le','<=').replaceAll('\\ge','>=').replaceAll(' ','');if(text==='所有實數')return ()=>true;if(text==='無解')return ()=>false;
 const pieces=text.split('或').map(piece=>{const tokens=piece.match(/-?\d+(?:\.\d+)?|x|<=|>=|<|>|=/g);assert.equal(tokens.join(''),piece);return x=>{const val=t=>t==='x'?x:Number(t);for(let i=1;i<tokens.length;i+=2){const a=val(tokens[i-1]),b=val(tokens[i+1]);if(!({'<':a<b,'>':a>b,'<=':a<=b,'>=':a>=b,'=':a===b}[tokens[i]]))return false;}return true;};});return x=>pieces.some(f=>f(x));}
const samples=[-100,100];for(let i=-80;i<=80;i++)samples.push(i/4);
const integers=Array.from({length:201},(_,i)=>i-100);
const scalarAnswers={Q10:0,Q21:integers.filter(x=>-3<=2*x+1&&2*x+1<7).length,Q22:Math.max(...integers.filter(x=>x<0&&(x<-7/3||x>=4))),Q23:Math.min(...integers.filter(x=>x>0&&x>5/2&&x<=6)),Q25:integers.filter(n=>n>=0&&28<12+4*n&&12+4*n<=44).length,Q30:integers.filter(x=>x>=-2&&x<=2&&(4-3*x<=1||2*x+5<3)).length};
test('A19: all 30 questions have four distinct stable options and valid TeX',()=>{assert.equal(QUESTIONS.length,30);const ids=new Set();for(const q of QUESTIONS){assert.ok(!ids.has(q.questionId));ids.add(q.questionId);assert.equal(q.options.length,4);assert.equal(new Set(q.options.map(o=>o.optionId)).size,4);assert.equal(q.options.filter(o=>o.optionId===q.correctOptionId).length,1);for(const text of [q.prompt,q.explanation,...q.options.map(o=>o.text)])for(const tex of text.matchAll(/\$([^$]+)\$/g))assert.doesNotThrow(()=>katex.renderToString(tex[1],{throwOnError:true}));assert.ok(q.options.filter(o=>o.optionId!==q.correctOptionId).every(o=>o.misconceptionTag));}});
for(const q of QUESTIONS)test(`A19 ${q.questionId}: unique mathematical answer, including exact endpoints`,()=>{
 let matches=[];
 if(predicates[q.questionId]){const expect=samples.map(predicates[q.questionId]).join(',');const signatures=q.options.map(o=>samples.map(rangePredicate(o.text)).join(','));assert.equal(new Set(signatures).size,4,'Distractors must describe inequivalent sets');matches=q.options.filter((o,i)=>signatures[i]===expect);}
 else if(q.questionId==='Q09'){assert.equal(q.diagram.options.length,4);assert.equal(new Set(q.diagram.options.map(d=>`${d.lowerClosed}/${d.upperClosed}`)).size,4);matches=q.options.filter(o=>{const d=q.diagram.options.find(d=>d.optionId===o.optionId);return d.lower===-2&&d.upper===3&&d.lowerClosed&&!d.upperClosed;});}
 else if(q.questionId==='Q11'){matches=q.options.filter(o=>o.text==='兩個條件都須成立');assert.equal(new Set(q.options.map(o=>o.text)).size,4);}
 else {const expected=scalarAnswers[q.questionId];assert.notEqual(expected,undefined);matches=q.options.filter(o=>Number(o.text.replace(/[$個\s]/g,''))===expected);assert.equal(new Set(q.options.map(o=>o.text)).size,4);}
 assert.equal(matches.length,1);assert.equal(matches[0].optionId,q.correctOptionId);
});
