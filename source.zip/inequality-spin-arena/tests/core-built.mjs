// src/tops.ts
var TOP_TYPES = {
  attack: { name: "\u653B\u64CA\u578B", damage: 4, armor: -1, drain: 2.5, description: "\u653B\u64CA 4 \xB7 \u6BCF\u6B21\u627F\u50B7 +1 \xB7 \u6BCF\u79D2\u8017\u65CB 2.5" },
  balance: { name: "\u5E73\u8861\u578B", damage: 3, armor: 0, drain: 2, description: "\u653B\u64CA 3 \xB7 \u6A19\u6E96\u627F\u50B7 \xB7 \u6BCF\u79D2\u8017\u65CB 2" },
  defense: { name: "\u9632\u79A6\u578B", damage: 2, armor: 1, drain: 1.8, description: "\u653B\u64CA 2 \xB7 \u6BCF\u6B21\u627F\u50B7 \u22121 \xB7 \u6BCF\u79D2\u8017\u65CB 1.8" }
};
var TOPS = [
  { name: "\u9706\u5149", color: "#50e9ef", type: "balance" },
  { name: "\u971C\u8861", color: "#88b4ff", type: "balance" },
  { name: "\u71FC\u92D2", color: "#ff9069", type: "attack" },
  { name: "\u7D2B\u96FB", color: "#c7a0ff", type: "attack" },
  { name: "\u68EE\u76FE", color: "#8be0aa", type: "defense" },
  { name: "\u91D1\u7A79", color: "#f2ce73", type: "defense" }
];
var NPC_LEVELS = {
  easy: { name: "\u7DF4\u7FD2\u4F19\u4F34", accuracy: 0.48, minDelay: 0.52, maxDelay: 0.85 },
  normal: { name: "\u65CB\u9B25\u5C0D\u624B", accuracy: 0.7, minDelay: 0.35, maxDelay: 0.7 },
  hard: { name: "\u9AD8\u624B\u6311\u6230", accuracy: 0.88, minDelay: 0.2, maxDelay: 0.5 }
};
var HINTS = { fifty: "50/50", clue: "\u89E3\u984C\u63D0\u793A", time: "\u52A0\u6642 5 \u79D2" };

// src/settings.ts
var BALANCE = Object.freeze({
  maxHP: 120,
  maxSpin: 100,
  spinDrain: 2,
  maxEnergy: 3,
  maxShield: 6,
  battleSeconds: 10,
  clashSeconds: [2, 4, 6, 8, 10],
  countdownSeconds: 3,
  revealSeconds: 2,
  resumeSeconds: 2,
  skillFreezeSeconds: 0.8,
  baseDamage: 3,
  correctAttack: 1,
  speedAttack: 1,
  speedTieSeconds: 0.15,
  heal: 8,
  spinReward: 20,
  skillDamage: 18,
  fixedStep: 1 / 60,
  interruptionSeconds: 0.25
});
var DEFAULT_SETTINGS = { difficulty: "mixed", questionSeconds: 10, questionCount: 6, music: 0.16, effects: 0.55, muted: false, reducedEffects: false, cameraShake: true, vibration: false };

// src/questions.json
var questions_default = [
  {
    questionId: "Q01",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u89E3 $x>2$ \u53CA $x\\le6$\u3002",
    options: [
      {
        optionId: "q01_o1",
        text: "$2<x\\le6$",
        misconceptionTag: null
      },
      {
        optionId: "q01_o2",
        text: "$2\\le x<6$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q01_o3",
        text: "$x>2$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      },
      {
        optionId: "q01_o4",
        text: "$x\\le6$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      }
    ],
    correctOptionId: "q01_o1",
    explanation: "\u5169\u500B\u689D\u4EF6\u9808\u540C\u6642\u6210\u7ACB\uFF0C\u56E0\u6B64\u53D6\u91CD\u758A\u90E8\u5206\u30022 \u4E0D\u5305\u62EC\uFF0C6 \u5305\u62EC\u3002",
    misconceptionTags: [
      "\u6F0F\u53D6\u4EA4\u96C6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q02",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u5206\u96E2\u5340\u9593"
    ],
    prompt: "\u89E3 $x<-1$ \u6216 $x\\ge3$\u3002",
    options: [
      {
        optionId: "q02_o1",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u8AA4\u5224\u6240\u6709\u5BE6\u6578"
      },
      {
        optionId: "q02_o2",
        text: "$x<-1$ \u6216 $x\\ge3$",
        misconceptionTag: null
      },
      {
        optionId: "q02_o3",
        text: "$-1<x<3$",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q02_o4",
        text: "$-1\\le x\\le3$",
        misconceptionTag: "\u5167\u5916\u5340\u9593\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q02_o2",
    explanation: "\u7B26\u5408\u5DE6\u5074\u6216\u53F3\u5074\u4EFB\u4E00\u689D\u4EF6\u5373\u53EF\uFF1B\u4E2D\u9593\u7684 $-1\\le x<3$ \u4E0D\u5305\u62EC\u3002",
    misconceptionTags: [
      "\u5167\u5916\u5340\u9593\u6DF7\u6DC6",
      "\u628A\u6216\u7576\u53CA",
      "\u8AA4\u5224\u6240\u6709\u5BE6\u6578"
    ]
  },
  {
    questionId: "Q03",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u540C\u5411\u7BC4\u570D"
    ],
    prompt: "\u89E3 $x\\ge-3$ \u53CA $x>1$\u3002",
    options: [
      {
        optionId: "q03_o1",
        text: "$-3\\le x\\le1$",
        misconceptionTag: "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6"
      },
      {
        optionId: "q03_o2",
        text: "$x\\ge1$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q03_o3",
        text: "$x>1$",
        misconceptionTag: null
      },
      {
        optionId: "q03_o4",
        text: "$x\\ge-3$",
        misconceptionTag: "\u9078\u53D6\u8F03\u5BEC\u7BC4\u570D"
      }
    ],
    correctOptionId: "q03_o3",
    explanation: "\u6240\u6709\u5927\u65BC 1 \u7684\u6578\u5DF2\u540C\u6642\u6EFF\u8DB3\u4E0D\u5C11\u65BC \u22123\uFF0C\u56E0\u6B64\u53D6\u8F03\u7A84\u7684\u7BC4\u570D $x>1$\u3002",
    misconceptionTags: [
      "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u9078\u53D6\u8F03\u5BEC\u7BC4\u570D"
    ]
  },
  {
    questionId: "Q04",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u540C\u5411\u7BC4\u570D"
    ],
    prompt: "\u89E3 $x\\le4$ \u6216 $x\\le-2$\u3002",
    options: [
      {
        optionId: "q04_o1",
        text: "$x\\le-2$",
        misconceptionTag: "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
      },
      {
        optionId: "q04_o2",
        text: "$-2\\le x\\le4$",
        misconceptionTag: "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D"
      },
      {
        optionId: "q04_o3",
        text: "$x<4$",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      },
      {
        optionId: "q04_o4",
        text: "$x\\le4$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q04_o4",
    explanation: "$x\\le-2$ \u7684\u7BC4\u570D\u5DF2\u5305\u62EC\u5728 $x\\le4$ \u4E4B\u5167\uFF0C\u53D6\u806F\u96C6\u5F8C\u70BA $x\\le4$\u3002",
    misconceptionTags: [
      "\u6F0F\u7AEF\u9EDE",
      "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D",
      "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
    ]
  },
  {
    questionId: "Q05",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u7121\u89E3"
    ],
    prompt: "\u89E3 $x<0$ \u53CA $x\\ge0$\u3002",
    options: [
      {
        optionId: "q05_o1",
        text: "\u7121\u89E3",
        misconceptionTag: null
      },
      {
        optionId: "q05_o2",
        text: "$x=0$",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q05_o3",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      },
      {
        optionId: "q05_o4",
        text: "$x<0$",
        misconceptionTag: "\u5FFD\u7565\u7B2C\u4E8C\u689D\u4EF6"
      }
    ],
    correctOptionId: "q05_o1",
    explanation: "\u6C92\u6709\u5BE6\u6578\u80FD\u540C\u6642\u5C0F\u65BC 0 \u53CA\u4E0D\u5C11\u65BC 0\uFF0C\u56E0\u6B64\u7121\u89E3\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u7B2C\u4E8C\u689D\u4EF6",
      "\u628A\u53CA\u7576\u6216",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ]
  },
  {
    questionId: "Q06",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u6240\u6709\u5BE6\u6578"
    ],
    prompt: "\u89E3 $x\\le2$ \u6216 $x>2$\u3002",
    options: [
      {
        optionId: "q06_o1",
        text: "$x=2$",
        misconceptionTag: "\u8AA4\u53D6\u7AEF\u9EDE"
      },
      {
        optionId: "q06_o2",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: null
      },
      {
        optionId: "q06_o3",
        text: "\u7121\u89E3",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q06_o4",
        text: "$x<2$ \u6216 $x>2$",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      }
    ],
    correctOptionId: "q06_o2",
    explanation: "2 \u53CA\u6240\u6709\u5C0F\u65BC 2 \u7684\u6578\u7B26\u5408\u7B2C\u4E00\u689D\u4EF6\uFF0C\u5927\u65BC 2 \u7684\u6578\u7B26\u5408\u7B2C\u4E8C\u689D\u4EF6\uFF0C\u5408\u8D77\u4F86\u5305\u542B\u6240\u6709\u5BE6\u6578\u3002",
    misconceptionTags: [
      "\u628A\u6216\u7576\u53CA",
      "\u6F0F\u7AEF\u9EDE",
      "\u8AA4\u53D6\u7AEF\u9EDE"
    ]
  },
  {
    questionId: "Q07",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u55AE\u9EDE\u89E3"
    ],
    prompt: "\u89E3 $x\\ge5$ \u53CA $x\\le5$\u3002",
    options: [
      {
        optionId: "q07_o1",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      },
      {
        optionId: "q07_o2",
        text: "$x>5$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q07_o3",
        text: "$x=5$",
        misconceptionTag: null
      },
      {
        optionId: "q07_o4",
        text: "\u7121\u89E3",
        misconceptionTag: "\u5FFD\u7565\u76F8\u7B49"
      }
    ],
    correctOptionId: "q07_o3",
    explanation: "\u5169\u689D\u4EF6\u5171\u540C\u5305\u542B\u7684\u552F\u4E00\u6578\u503C\u662F 5\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u76F8\u7B49",
      "\u628A\u53CA\u7576\u6216",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q08",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u6392\u9664\u55AE\u9EDE"
    ],
    prompt: "\u89E3 $x<4$ \u6216 $x>4$\u3002",
    options: [
      {
        optionId: "q08_o1",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q08_o2",
        text: "$x=4$",
        misconceptionTag: "\u5167\u5916\u7BC4\u570D\u6DF7\u6DC6"
      },
      {
        optionId: "q08_o3",
        text: "\u7121\u89E3",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q08_o4",
        text: "$x<4$ \u6216 $x>4$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q08_o4",
    explanation: "\u6240\u6709\u5C0F\u65BC\u6216\u5927\u65BC 4 \u7684\u6578\u5747\u7B26\u5408\uFF0C\u4F46 4 \u4E0D\u7B26\u5408\u4EFB\u4F55\u4E00\u500B\u689D\u4EF6\u3002",
    misconceptionTags: [
      "\u5167\u5916\u7BC4\u570D\u6DF7\u6DC6",
      "\u628A\u6216\u7576\u53CA",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ]
  },
  {
    questionId: "Q09",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6578\u7DDA",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u54EA\u4E00\u689D\u6578\u7DDA\u8868\u793A $-2\\le x<3$\uFF1F",
    options: [
      {
        optionId: "q09_o1",
        text: "\u22122 \u70BA\u5BE6\u5FC3\u9EDE\uFF0C3 \u70BA\u7A7A\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: null
      },
      {
        optionId: "q09_o2",
        text: "\u22122 \u70BA\u7A7A\u5FC3\u9EDE\uFF0C3 \u70BA\u5BE6\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q09_o3",
        text: "\u5169\u9EDE\u5747\u70BA\u5BE6\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q09_o4",
        text: "\u5169\u9EDE\u5747\u70BA\u7A7A\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      }
    ],
    correctOptionId: "q09_o1",
    explanation: "\u4E0D\u5C11\u65BC \u22122\uFF0C\u6240\u4EE5 \u22122 \u7528\u5BE6\u5FC3\u9EDE\uFF1B\u5C0F\u65BC 3\uFF0C\u6240\u4EE5 3 \u7528\u7A7A\u5FC3\u9EDE\uFF0C\u7BC4\u570D\u70BA\u5169\u9EDE\u4E4B\u9593\u3002",
    misconceptionTags: [
      "\u6F0F\u7AEF\u9EDE",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ],
    diagram: {
      type: "numberLineOptions",
      domain: [
        -4,
        5
      ],
      options: [
        {
          optionId: "q09_o1",
          lower: -2,
          upper: 3,
          lowerClosed: true,
          upperClosed: false
        },
        {
          optionId: "q09_o2",
          lower: -2,
          upper: 3,
          lowerClosed: false,
          upperClosed: true
        },
        {
          optionId: "q09_o3",
          lower: -2,
          upper: 3,
          lowerClosed: true,
          upperClosed: true
        },
        {
          optionId: "q09_o4",
          lower: -2,
          upper: 3,
          lowerClosed: false,
          upperClosed: false
        }
      ]
    }
  },
  {
    questionId: "Q10",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6574\u6578\u89E3",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u4E0B\u5217\u54EA\u4E00\u500B\u6574\u6578\u6EFF\u8DB3 $-1<x\\le2$\uFF1F",
    options: [
      {
        optionId: "q10_o1",
        text: "$-2$",
        misconceptionTag: "\u8D85\u51FA\u4E0B\u754C"
      },
      {
        optionId: "q10_o2",
        text: "$0$",
        misconceptionTag: null
      },
      {
        optionId: "q10_o3",
        text: "$-1$",
        misconceptionTag: "\u6F0F\u6AA2\u67E5\u958B\u7AEF\u9EDE"
      },
      {
        optionId: "q10_o4",
        text: "$3$",
        misconceptionTag: "\u8D85\u51FA\u4E0A\u754C"
      }
    ],
    correctOptionId: "q10_o2",
    explanation: "\u4EE3\u5165\u56DB\u500B\u9078\u9805\uFF0C\u53EA\u6709 0 \u5927\u65BC \u22121 \u800C\u4E0D\u5927\u65BC 2\u3002",
    misconceptionTags: [
      "\u6F0F\u6AA2\u67E5\u958B\u7AEF\u9EDE",
      "\u8D85\u51FA\u4E0A\u754C",
      "\u8D85\u51FA\u4E0B\u754C"
    ]
  },
  {
    questionId: "Q11",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u689D\u4EF6\u7406\u89E3"
    ],
    prompt: "\u300C\u689D\u4EF6\u4E00\u53CA\u689D\u4EF6\u4E8C\u300D\u7684\u610F\u601D\u662F\u751A\u9EBC\uFF1F",
    options: [
      {
        optionId: "q11_o1",
        text: "\u6070\u597D\u4E00\u500B\u689D\u4EF6\u6210\u7ACB",
        misconceptionTag: "\u8AA4\u89E3\u908F\u8F2F\u9023\u63A5"
      },
      {
        optionId: "q11_o2",
        text: "\u5169\u500B\u689D\u4EF6\u90FD\u4E0D\u6210\u7ACB",
        misconceptionTag: "\u8AA4\u89E3\u908F\u8F2F\u9023\u63A5"
      },
      {
        optionId: "q11_o3",
        text: "\u5169\u500B\u689D\u4EF6\u90FD\u9808\u6210\u7ACB",
        misconceptionTag: null
      },
      {
        optionId: "q11_o4",
        text: "\u81F3\u5C11\u4E00\u500B\u689D\u4EF6\u6210\u7ACB",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      }
    ],
    correctOptionId: "q11_o3",
    explanation: "\u300C\u53CA\u300D\u8981\u6C42\u540C\u6642\u6EFF\u8DB3\u5169\u500B\u689D\u4EF6\uFF1B\u300C\u6216\u300D\u624D\u662F\u81F3\u5C11\u6EFF\u8DB3\u4E00\u500B\u3002",
    misconceptionTags: [
      "\u628A\u53CA\u7576\u6216",
      "\u8AA4\u89E3\u908F\u8F2F\u9023\u63A5"
    ]
  },
  {
    questionId: "Q12",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6587\u5B57\u8F49\u4E0D\u7B49\u5F0F",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u6578\u503C $x$ \u4E0D\u5C11\u65BC 2\uFF0C\u4F46\u5C11\u65BC 7\u3002\u54EA\u500B\u4E0D\u7B49\u5F0F\u6B63\u78BA\uFF1F",
    options: [
      {
        optionId: "q12_o1",
        text: "$2<x\\le7$",
        misconceptionTag: "\u908A\u754C\u8A5E\u8A9E\u6DF7\u6DC6"
      },
      {
        optionId: "q12_o2",
        text: "$2<x<7$",
        misconceptionTag: "\u6F0F\u4E0B\u754C\u7AEF\u9EDE"
      },
      {
        optionId: "q12_o3",
        text: "$2\\le x\\le7$",
        misconceptionTag: "\u8AA4\u52A0\u4E0A\u754C\u7AEF\u9EDE"
      },
      {
        optionId: "q12_o4",
        text: "$2\\le x<7$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q12_o4",
    explanation: "\u4E0D\u5C11\u65BC 2 \u5305\u62EC 2\uFF0C\u5C11\u65BC 7 \u4E0D\u5305\u62EC 7\u3002",
    misconceptionTags: [
      "\u6F0F\u4E0B\u754C\u7AEF\u9EDE",
      "\u8AA4\u52A0\u4E0A\u754C\u7AEF\u9EDE",
      "\u908A\u754C\u8A5E\u8A9E\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q13",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u4EE3\u6578\u6C42\u89E3"
    ],
    prompt: "\u89E3 $2x+1>5$ \u53CA $3x-2\\le10$\u3002",
    options: [
      {
        optionId: "q13_o1",
        text: "$2<x\\le4$",
        misconceptionTag: null
      },
      {
        optionId: "q13_o2",
        text: "$2\\le x<4$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q13_o3",
        text: "$x>2$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      },
      {
        optionId: "q13_o4",
        text: "$x\\le4$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      }
    ],
    correctOptionId: "q13_o1",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $x>2$\uFF0C\u7B2C\u4E8C\u5F0F\u5F97 $x\\le4$\uFF0C\u53D6\u4EA4\u96C6\u70BA $2<x\\le4$\u3002",
    misconceptionTags: [
      "\u6F0F\u53D6\u4EA4\u96C6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q14",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u9664\u4EE5\u8CA0\u6578"
    ],
    prompt: "\u89E3 $7-2x\\ge1$ \u53CA $x+4>3$\u3002",
    options: [
      {
        optionId: "q14_o1",
        text: "$x>3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q14_o2",
        text: "$-1<x\\le3$",
        misconceptionTag: null
      },
      {
        optionId: "q14_o3",
        text: "$x\\ge3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q14_o4",
        text: "$-1\\le x<3$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q14_o2",
    explanation: "\u7B2C\u4E00\u5F0F\u70BA $-2x\\ge-6$\uFF0C\u9664\u4EE5 \u22122 \u6642\u53CD\u8F49\u4E0D\u7B49\u865F\uFF0C\u5F97 $x\\le3$\u3002\u7B2C\u4E8C\u5F0F\u5F97 $x>-1$\uFF0C\u6240\u4EE5 $-1<x\\le3$\u3002",
    misconceptionTags: [
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ]
  },
  {
    questionId: "Q15",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6216",
      "\u9664\u4EE5\u8CA0\u6578"
    ],
    prompt: "\u89E3 $-3x<9$ \u6216 $2x+1\\le-7$\u3002",
    options: [
      {
        optionId: "q15_o1",
        text: "$x<-3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q15_o2",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u5FFD\u7565\u5340\u9593\u7F3A\u53E3"
      },
      {
        optionId: "q15_o3",
        text: "$x\\le-4$ \u6216 $x>-3$",
        misconceptionTag: null
      },
      {
        optionId: "q15_o4",
        text: "$-4\\le x<-3$",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      }
    ],
    correctOptionId: "q15_o3",
    explanation: "\u5206\u5225\u5F97\u5230 $x>-3$ \u53CA $x\\le-4$\uFF0C\u5169\u6BB5\u4E4B\u9593\u7684 $-4<x\\le-3$ \u4E0D\u7B26\u5408\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u5340\u9593\u7F3A\u53E3",
      "\u628A\u6216\u7576\u53CA",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ]
  },
  {
    questionId: "Q16",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u62EC\u865F"
    ],
    prompt: "\u89E3 $2(x-1)\\le6$ \u53CA $5-x<4$\u3002",
    options: [
      {
        optionId: "q16_o1",
        text: "$x\\le1$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q16_o2",
        text: "$1\\le x<4$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q16_o3",
        text: "$x>1$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      },
      {
        optionId: "q16_o4",
        text: "$1<x\\le4$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q16_o4",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $x\\le4$\uFF1B\u7B2C\u4E8C\u5F0F\u70BA $-x<-1$\uFF0C\u5F97 $x>1$\u3002\u6240\u4EE5 $1<x\\le4$\u3002",
    misconceptionTags: [
      "\u6F0F\u53D6\u4EA4\u96C6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ]
  },
  {
    questionId: "Q17",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u9023\u9396\u4E0D\u7B49\u5F0F"
    ],
    prompt: "\u89E3 $-2<3x+1\\le7$\u3002",
    options: [
      {
        optionId: "q17_o1",
        text: "$-1<x\\le2$",
        misconceptionTag: null
      },
      {
        optionId: "q17_o2",
        text: "$-1\\le x<2$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q17_o3",
        text: "$-3<x\\le6$",
        misconceptionTag: "\u6F0F\u9664\u4FC2\u6578"
      },
      {
        optionId: "q17_o4",
        text: "$x<-1$ \u6216 $x\\ge2$",
        misconceptionTag: "\u5167\u5916\u5340\u9593\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q17_o1",
    explanation: "\u4E09\u90E8\u5206\u540C\u6E1B 1\uFF0C\u5F97 $-3<3x\\le6$\uFF0C\u518D\u540C\u9664\u4EE5 3\uFF0C\u5F97 $-1<x\\le2$\u3002",
    misconceptionTags: [
      "\u5167\u5916\u5340\u9593\u6DF7\u6DC6",
      "\u6F0F\u9664\u4FC2\u6578",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q18",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6216",
      "\u4EE3\u6578\u6C42\u89E3"
    ],
    prompt: "\u89E3 $4x-3\\ge9$ \u6216 $2x+5<1$\u3002",
    options: [
      {
        optionId: "q18_o1",
        text: "\u7121\u89E3",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q18_o2",
        text: "$x<-2$ \u6216 $x\\ge3$",
        misconceptionTag: null
      },
      {
        optionId: "q18_o3",
        text: "$-2<x<3$",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q18_o4",
        text: "$x\\le-2$ \u6216 $x>3$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q18_o2",
    explanation: "\u5206\u5225\u5F97\u5230 $x\\ge3$ \u53CA $x<-2$\uFF0C\u7528\u6216\u9023\u63A5\u5169\u6BB5\u89E3\u3002",
    misconceptionTags: [
      "\u628A\u6216\u7576\u53CA",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q19",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6216",
      "\u5305\u542B\u95DC\u4FC2"
    ],
    prompt: "\u89E3 $3x+6\\le0$ \u6216 $x-5<0$\u3002",
    options: [
      {
        optionId: "q19_o1",
        text: "$-2\\le x<5$",
        misconceptionTag: "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D"
      },
      {
        optionId: "q19_o2",
        text: "$x\\le5$",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q19_o3",
        text: "$x<5$",
        misconceptionTag: null
      },
      {
        optionId: "q19_o4",
        text: "$x\\le-2$",
        misconceptionTag: "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
      }
    ],
    correctOptionId: "q19_o3",
    explanation: "\u5206\u5225\u5F97\u5230 $x\\le-2$ \u53CA $x<5$\u3002\u524D\u8005\u5DF2\u5305\u542B\u5728\u5F8C\u8005\uFF0C\u806F\u96C6\u70BA $x<5$\u3002",
    misconceptionTags: [
      "\u8AA4\u52A0\u7AEF\u9EDE",
      "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D",
      "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
    ]
  },
  {
    questionId: "Q20",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u7121\u89E3"
    ],
    prompt: "\u89E3 $5-x>2$ \u53CA $2x-4\\ge4$\u3002",
    options: [
      {
        optionId: "q20_o1",
        text: "$3<x<4$",
        misconceptionTag: "\u932F\u53D6\u4E2D\u9593\u5340\u9593"
      },
      {
        optionId: "q20_o2",
        text: "$x<3$ \u6216 $x\\ge4$",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      },
      {
        optionId: "q20_o3",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u5FFD\u7565\u4E0D\u76F8\u5BB9\u689D\u4EF6"
      },
      {
        optionId: "q20_o4",
        text: "\u7121\u89E3",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q20_o4",
    explanation: "\u5206\u5225\u5F97\u5230 $x<3$ \u53CA $x\\ge4$\uFF0C\u6C92\u6709\u5171\u540C\u7BC4\u570D\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u4E0D\u76F8\u5BB9\u689D\u4EF6",
      "\u628A\u53CA\u7576\u6216",
      "\u932F\u53D6\u4E2D\u9593\u5340\u9593"
    ]
  },
  {
    questionId: "Q21",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6574\u6578\u89E3",
      "\u9023\u9396\u4E0D\u7B49\u5F0F"
    ],
    prompt: "\u6709\u591A\u5C11\u500B\u6574\u6578\u6EFF\u8DB3 $-3\\le2x+1<7$\uFF1F",
    options: [
      {
        optionId: "q21_o1",
        text: "5 \u500B",
        misconceptionTag: null
      },
      {
        optionId: "q21_o2",
        text: "4 \u500B",
        misconceptionTag: "\u6F0F\u7B97\u7AEF\u9EDE"
      },
      {
        optionId: "q21_o3",
        text: "6 \u500B",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q21_o4",
        text: "7 \u500B",
        misconceptionTag: "\u672A\u89E3\u4E0D\u7B49\u5F0F\u4FBF\u8A08\u6578"
      }
    ],
    correctOptionId: "q21_o1",
    explanation: "\u5316\u7C21\u5F97 $-2\\le x<3$\u3002\u6574\u6578\u70BA \u22122\u3001\u22121\u30010\u30011\u30012\uFF0C\u5171 5 \u500B\u3002",
    misconceptionTags: [
      "\u672A\u89E3\u4E0D\u7B49\u5F0F\u4FBF\u8A08\u6578",
      "\u6F0F\u7B97\u7AEF\u9EDE",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ]
  },
  {
    questionId: "Q22",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6700\u5927\u8CA0\u6574\u6578",
      "\u5206\u6578\u754C\u9650"
    ],
    prompt: "\u6EFF\u8DB3 $x<-\\frac{7}{3}$ \u6216 $x\\ge4$ \u7684\u6700\u5927\u8CA0\u6574\u6578\u662F\u751A\u9EBC\uFF1F",
    options: [
      {
        optionId: "q22_o1",
        text: "$4$",
        misconceptionTag: "\u5FFD\u7565\u8CA0\u6574\u6578\u689D\u4EF6"
      },
      {
        optionId: "q22_o2",
        text: "$-3$",
        misconceptionTag: null
      },
      {
        optionId: "q22_o3",
        text: "$-2$",
        misconceptionTag: "\u8CA0\u6578\u5927\u5C0F\u6DF7\u6DC6"
      },
      {
        optionId: "q22_o4",
        text: "$-4$",
        misconceptionTag: "\u672A\u9078\u6700\u5927"
      }
    ],
    correctOptionId: "q22_o2",
    explanation: "\u8CA0\u6574\u6578\u53EA\u80FD\u4F86\u81EA $x<-\\frac{7}{3}$\u3002\u56E0\u70BA $-3<-\\frac{7}{3}<-2$\uFF0C\u6700\u5927\u8CA0\u6574\u6578\u662F \u22123\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u8CA0\u6574\u6578\u689D\u4EF6",
      "\u672A\u9078\u6700\u5927",
      "\u8CA0\u6578\u5927\u5C0F\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q23",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6700\u5C0F\u6B63\u6574\u6578",
      "\u5206\u6578\u754C\u9650"
    ],
    prompt: "\u6EFF\u8DB3 $x>\\frac{5}{2}$ \u53CA $x\\le6$ \u7684\u6700\u5C0F\u6B63\u6574\u6578\u662F\u751A\u9EBC\uFF1F",
    options: [
      {
        optionId: "q23_o1",
        text: "$4$",
        misconceptionTag: "\u672A\u9078\u6700\u5C0F"
      },
      {
        optionId: "q23_o2",
        text: "$6$",
        misconceptionTag: "\u6DF7\u6DC6\u6700\u5C0F\u8207\u6700\u5927"
      },
      {
        optionId: "q23_o3",
        text: "$3$",
        misconceptionTag: null
      },
      {
        optionId: "q23_o4",
        text: "$2$",
        misconceptionTag: "\u672A\u8D85\u904E\u5206\u6578\u754C\u9650"
      }
    ],
    correctOptionId: "q23_o3",
    explanation: "$\\frac{5}{2}=2.5$\uFF0C\u5927\u65BC 2.5 \u800C\u4E0D\u5927\u65BC 6 \u7684\u6574\u6578\u70BA 3\u30014\u30015\u30016\uFF0C\u6700\u5C0F\u662F 3\u3002",
    misconceptionTags: [
      "\u672A\u8D85\u904E\u5206\u6578\u754C\u9650",
      "\u672A\u9078\u6700\u5C0F",
      "\u6DF7\u6DC6\u6700\u5C0F\u8207\u6700\u5927"
    ]
  },
  {
    questionId: "Q24",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u5206\u5F0F"
    ],
    prompt: "\u89E3 $\\frac{x-1}{2}\\ge-1$ \u53CA $\\frac{3-x}{2}>0$\u3002",
    options: [
      {
        optionId: "q24_o1",
        text: "$-1<x\\le3$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q24_o2",
        text: "$x>3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q24_o3",
        text: "$-1\\le x\\le3$",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q24_o4",
        text: "$-1\\le x<3$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q24_o4",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $x-1\\ge-2$\uFF0C\u5373 $x\\ge-1$\uFF1B\u7B2C\u4E8C\u5F0F\u5F97 $x<3$\uFF0C\u6240\u4EE5 $-1\\le x<3$\u3002",
    misconceptionTags: [
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8AA4\u52A0\u7AEF\u9EDE",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ]
  },
  {
    questionId: "Q25",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u61C9\u7528",
      "\u6574\u6578\u500B\u6578"
    ],
    prompt: "\u6D3B\u52D5\u6536\u8CBB\u70BA 12 \u5143\u52A0\u6BCF\u5F35\u5361 4 \u5143\u3002\u5B78\u751F\u8CFC\u8CB7 $n$ \u5F35\u5361\uFF0C\u7E3D\u8CBB\u7528\u8D85\u904E 28 \u5143\u4F46\u4E0D\u8D85\u904E 44 \u5143\u3002$n$ \u6709\u591A\u5C11\u500B\u53EF\u80FD\u7684\u6574\u6578\u503C\uFF1F",
    options: [
      {
        optionId: "q25_o1",
        text: "4 \u500B",
        misconceptionTag: null
      },
      {
        optionId: "q25_o2",
        text: "3 \u500B",
        misconceptionTag: "\u6F0F\u7B97\u7AEF\u9EDE"
      },
      {
        optionId: "q25_o3",
        text: "5 \u500B",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q25_o4",
        text: "8 \u500B",
        misconceptionTag: "\u628A\u4E0A\u9650\u7576\u500B\u6578"
      }
    ],
    correctOptionId: "q25_o1",
    explanation: "$28<12+4n\\le44$\uFF0C\u5F97 $4<n\\le8$\uFF0C\u6240\u4EE5 $n=5,6,7,8$\uFF0C\u5171 4 \u500B\u3002",
    misconceptionTags: [
      "\u628A\u4E0A\u9650\u7576\u500B\u6578",
      "\u6F0F\u7B97\u7AEF\u9EDE",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ]
  },
  {
    questionId: "Q26",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u4E09\u89D2\u4E0D\u7B49\u5F0F"
    ],
    prompt: "\u4E09\u89D2\u5F62\u7684\u4E09\u908A\u9577\u70BA 5 cm\u30019 cm \u53CA $x$ cm\u3002\u6C42 $x$ \u7684\u7BC4\u570D\u3002",
    options: [
      {
        optionId: "q26_o1",
        text: "$x>4$",
        misconceptionTag: "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u548C"
      },
      {
        optionId: "q26_o2",
        text: "$4<x<14$",
        misconceptionTag: null
      },
      {
        optionId: "q26_o3",
        text: "$4\\le x\\le14$",
        misconceptionTag: "\u5FFD\u7565\u56B4\u683C\u4E09\u89D2\u4E0D\u7B49\u5F0F"
      },
      {
        optionId: "q26_o4",
        text: "$0<x<14$",
        misconceptionTag: "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u5DEE"
      }
    ],
    correctOptionId: "q26_o2",
    explanation: "\u7531\u4E09\u89D2\u4E0D\u7B49\u5F0F\uFF0C$9-5<x<9+5$\uFF0C\u6240\u4EE5 $4<x<14$\uFF1B\u5169\u7AEF\u5747\u4E0D\u80FD\u53D6\u7B49\u865F\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u56B4\u683C\u4E09\u89D2\u4E0D\u7B49\u5F0F",
      "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u548C",
      "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u5DEE"
    ]
  },
  {
    questionId: "Q27",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u53CA",
      "\u5206\u5F0F",
      "\u5169\u908A\u542B\u672A\u77E5\u6578"
    ],
    prompt: "\u89E3 $\\frac{2x-1}{3}<x+1$ \u53CA $4-x\\le2x+7$\u3002",
    options: [
      {
        optionId: "q27_o1",
        text: "$-4<x\\le-1$",
        misconceptionTag: "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6"
      },
      {
        optionId: "q27_o2",
        text: "$x>-1$",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      },
      {
        optionId: "q27_o3",
        text: "$x\\ge-1$",
        misconceptionTag: null
      },
      {
        optionId: "q27_o4",
        text: "$x>-4$",
        misconceptionTag: "\u6F0F\u53D6\u8F03\u7A84\u7BC4\u570D"
      }
    ],
    correctOptionId: "q27_o3",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $2x-1<3x+3$\uFF0C\u5373 $x>-4$\uFF1B\u7B2C\u4E8C\u5F0F\u5F97 $-3x\\le3$\uFF0C\u5373 $x\\ge-1$\u3002\u53D6\u4EA4\u96C6\u70BA $x\\ge-1$\u3002",
    misconceptionTags: [
      "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6",
      "\u6F0F\u53D6\u8F03\u7A84\u7BC4\u570D",
      "\u6F0F\u7AEF\u9EDE"
    ]
  },
  {
    questionId: "Q28",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u53CA\u6216\u6DF7\u5408"
    ],
    prompt: "\u89E3\u300C$x>-3$ \u53CA $x\\le1$\u300D\uFF0C\u6216 $x\\ge4$\u3002",
    options: [
      {
        optionId: "q28_o1",
        text: "$-3<x\\le4$",
        misconceptionTag: "\u8AA4\u5408\u4F75\u5340\u9593\u7F3A\u53E3"
      },
      {
        optionId: "q28_o2",
        text: "$x>-3$",
        misconceptionTag: "\u5FFD\u7565\u4E2D\u9593\u7F3A\u53E3"
      },
      {
        optionId: "q28_o3",
        text: "\u7121\u89E3",
        misconceptionTag: "\u628A\u6240\u6709\u689D\u4EF6\u7576\u53CA"
      },
      {
        optionId: "q28_o4",
        text: "$-3<x\\le1$ \u6216 $x\\ge4$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q28_o4",
    explanation: "\u5148\u89E3\u5F15\u865F\u5167\u7684\u53CA\uFF0C\u5F97 $-3<x\\le1$\uFF0C\u518D\u8207 $x\\ge4$ \u5408\u4F75\u3002$1<x<4$ \u4ECD\u4E0D\u5728\u89E3\u4E2D\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u4E2D\u9593\u7F3A\u53E3",
      "\u628A\u6240\u6709\u689D\u4EF6\u7576\u53CA",
      "\u8AA4\u5408\u4F75\u5340\u9593\u7F3A\u53E3"
    ]
  },
  {
    questionId: "Q29",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u5E7E\u4F55\u61C9\u7528",
      "\u53CA"
    ],
    prompt: "\u9577\u65B9\u5F62\u9577\u70BA 6 cm\uFF0C\u95CA\u70BA $(x+1)$ cm\u3002\u9762\u7A4D\u5927\u65BC 24 cm\xB2 \u4F46\u4E0D\u8D85\u904E 42 cm\xB2\u3002\u6C42 $x$ \u7684\u7BC4\u570D\u3002",
    options: [
      {
        optionId: "q29_o1",
        text: "$3<x\\le6$",
        misconceptionTag: null
      },
      {
        optionId: "q29_o2",
        text: "$4<x\\le7$",
        misconceptionTag: "\u5FFD\u7565\u95CA\u7684\u5E38\u6578\u9805"
      },
      {
        optionId: "q29_o3",
        text: "$3\\le x<6$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q29_o4",
        text: "$x>3$",
        misconceptionTag: "\u6F0F\u53D6\u4E0A\u754C"
      }
    ],
    correctOptionId: "q29_o1",
    explanation: "$24<6(x+1)\\le42$\uFF0C\u9664\u4EE5 6 \u5F97 $4<x+1\\le7$\uFF0C\u6240\u4EE5 $3<x\\le6$\u3002\u6B64\u7BC4\u570D\u4EA6\u4FDD\u8B49\u95CA\u70BA\u6B63\u6578\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u95CA\u7684\u5E38\u6578\u9805",
      "\u6F0F\u53D6\u4E0A\u754C",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ]
  },
  {
    questionId: "Q30",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u6216",
      "\u6574\u6578\u89E3",
      "\u6307\u5B9A\u7BC4\u570D"
    ],
    prompt: "\u5DF2\u77E5 $x$ \u70BA\u6574\u6578\u4E14 $-2\\le x\\le2$\u3002\u6709\u591A\u5C11\u500B $x$ \u6EFF\u8DB3 $4-3x\\le1$ \u6216 $2x+5<3$\uFF1F",
    options: [
      {
        optionId: "q30_o1",
        text: "5 \u500B",
        misconceptionTag: "\u628A\u6216\u8AA4\u5224\u6240\u6709\u5BE6\u6578"
      },
      {
        optionId: "q30_o2",
        text: "3 \u500B",
        misconceptionTag: null
      },
      {
        optionId: "q30_o3",
        text: "2 \u500B",
        misconceptionTag: "\u6F0F\u7B97\u4E00\u6BB5\u89E3"
      },
      {
        optionId: "q30_o4",
        text: "4 \u500B",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      }
    ],
    correctOptionId: "q30_o2",
    explanation: "\u5169\u5F0F\u5206\u5225\u5F97 $x\\ge1$ \u6216 $x<-1$\u3002\u5728\u6307\u5B9A\u7BC4\u570D\u5167\u7B26\u5408\u7684\u6574\u6578\u662F \u22122\u30011\u30012\uFF0C\u5171 3 \u500B\u3002",
    misconceptionTags: [
      "\u628A\u6216\u8AA4\u5224\u6240\u6709\u5BE6\u6578",
      "\u6F0F\u7B97\u4E00\u6BB5\u89E3",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ]
  }
];

// src/core.ts
var QUESTIONS = questions_default;
function seededRandom(seed) {
  let a = seed >>> 0;
  return () => {
    a += 1831565813;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function shuffle(list, rng) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function drawQuestions(s, rng) {
  const take = (d, n) => shuffle(QUESTIONS.filter((q) => q.difficulty === d), rng).slice(0, n);
  if (s.difficulty !== "mixed") return take(s.difficulty === "basic" ? "\u57FA\u790E" : "\u6A19\u6E96", s.questionCount);
  const split = s.questionCount === 4 ? [1, 2, 1] : s.questionCount === 8 ? [3, 4, 1] : [2, 3, 1];
  return [...take("\u57FA\u790E", split[0]), ...take("\u6A19\u6E96", split[1]), ...take("\u9032\u968E", split[2])];
}
function freshPlayer(id, skin = id) {
  return { direction: id === 0 ? "right" : "left", hintsUsed: [], eliminated: [], clueVisible: false, extraSeconds: 0, playerId: id, hp: BALANCE.maxHP, spin: BALANCE.maxSpin, energy: 0, shield: 0, attackBonus: 0, firstHitBonus: 0, pendingSkill: false, skillUsed: false, selectedOptionId: null, lockedOptionId: null, lockedAt: null, ready: false, skin };
}
function normalDamage(p) {
  return Math.max(1, TOP_TYPES[TOPS[p.skin].type].damage + p.attackBonus + p.firstHitBonus - (p.spin === 0 ? 2 : p.spin < 30 ? 1 : 0));
}
function stats(records, id) {
  const answers = records.filter((r) => r.rewardsApplied).map((r) => r.answers[id]);
  const correct = answers.filter((a) => a.result === "correct");
  return { correct: correct.length, wrong: answers.filter((a) => a.result === "wrong").length, unanswered: answers.filter((a) => a.result === "unanswered").length, average: correct.length ? correct.reduce((n, a) => n + a.seconds, 0) / correct.length : null };
}
var MatchController = class {
  mode = "duo";
  npcLevel = "normal";
  npcRng = seededRandom(2);
  hintRng = seededRandom(3);
  npcPlan = null;
  phase = "TITLE";
  phaseTime = 0;
  clock = 0;
  players = [freshPlayer(0), freshPlayer(1)];
  matchId = "";
  seed = 1;
  settings = { ...DEFAULT_SETTINGS };
  sequence = [];
  records = [];
  battleIndex = 0;
  clashIndex = 0;
  skillFreeze = 0;
  paused = false;
  pauseReason = "";
  resumeReady = [false, false];
  outcome = null;
  events = [];
  rng = seededRandom(1);
  handled = /* @__PURE__ */ new Set();
  get question() {
    return this.sequence[this.records.length - 1];
  }
  get record() {
    return this.records.at(-1);
  }
  get live() {
    return ["COUNTDOWN", "BATTLE", "QUESTION_LOADING", "QUESTION_ACTIVE", "REVEAL"].includes(this.phase);
  }
  emit(type, data = {}) {
    this.events.push({ type, ...data });
  }
  drainEvents() {
    return this.events.splice(0);
  }
  transition(phase) {
    this.phase = phase;
    this.phaseTime = 0;
    this.emit("PHASE", { phase });
  }
  lobby(seed = Date.now() >>> 0, fixedIds) {
    const choices = this.players.map((p) => ({ skin: p.skin, direction: p.direction }));
    this.seed = seed;
    this.rng = seededRandom(seed);
    this.npcRng = seededRandom(seed ^ 439041101);
    this.hintRng = seededRandom(seed ^ 1584337460);
    this.npcPlan = null;
    this.matchId = `match-${seed}-${Math.random().toString(36).slice(2, 9)}`;
    this.players = choices.map((p, id) => ({ ...freshPlayer(id, p.skin), direction: p.direction }));
    if (this.mode === "solo") this.players[1].ready = true;
    this.clock = 0;
    this.battleIndex = 0;
    this.clashIndex = 0;
    this.skillFreeze = 0;
    this.paused = false;
    this.pauseReason = "";
    this.resumeReady = [false, false];
    this.outcome = null;
    this.records = [];
    this.handled.clear();
    this.events = [];
    this.sequence = fixedIds ? fixedIds.map((id) => {
      const q = QUESTIONS.find((q2) => q2.questionId === id);
      if (!q) throw Error(`Unknown question ${id}`);
      return q;
    }) : drawQuestions(this.settings, this.rng);
    this.transition("LOBBY");
  }
  home() {
    this.lobby();
    this.transition("TITLE");
  }
  ready(id) {
    if (this.phase !== "LOBBY" || this.paused || this.isNpc(id) || !this.players[id]) return;
    this.players[id].ready = !this.players[id].ready;
    this.emit("READY", { id });
    if (this.players.every((p) => p.ready)) this.transition("COUNTDOWN");
  }
  isNpc(id) {
    return this.mode === "solo" && id === 1;
  }
  canConfigure(id) {
    return !!this.players[id] && this.phase === "LOBBY" && (this.isNpc(id) ? !this.players[0].ready : !this.players[id].ready);
  }
  setMode(mode) {
    if (!["TITLE", "LOBBY"].includes(this.phase) || !["duo", "solo"].includes(mode)) return;
    this.mode = mode;
    if (this.phase === "LOBBY") this.lobby(this.seed);
  }
  setNpcLevel(level) {
    if (["TITLE", "LOBBY"].includes(this.phase) && level in NPC_LEVELS) {
      this.npcLevel = level;
      this.emit("CONFIG");
    }
  }
  setTop(id, index) {
    if (this.canConfigure(id) && Number.isInteger(index) && TOPS[index]) {
      this.players[id].skin = index;
      this.emit("SKIN", { id });
    }
  }
  skin(id) {
    if (this.players[id]) this.setTop(id, (this.players[id].skin + 1) % TOPS.length);
  }
  setDirection(id, direction) {
    if (this.canConfigure(id) && (direction === "left" || direction === "right")) {
      this.players[id].direction = direction;
      this.emit("SKIN", { id });
    }
  }
  deadline(id) {
    return this.settings.questionSeconds + this.players[id].extraSeconds;
  }
  remaining(id) {
    return Math.max(0, this.deadline(id) - this.phaseTime);
  }
  get questionRemaining() {
    return Math.max(0, ...this.players.map((p) => p.lockedOptionId ? 0 : this.remaining(p.playerId)));
  }
  useHint(id, kind, matchId = this.matchId, questionId = this.question?.questionId) {
    const p = this.players[id];
    if (!p || this.isNpc(id) || this.paused || this.phase !== "QUESTION_ACTIVE" || this.remaining(id) <= 1e-7 || p.lockedOptionId || !(kind in HINTS) || p.hintsUsed.includes(kind) || matchId !== this.matchId || questionId !== this.question.questionId) return false;
    p.hintsUsed.push(kind);
    if (kind === "fifty") {
      p.eliminated = shuffle(this.record.orders[id].filter((o) => o !== this.question.correctOptionId), this.hintRng).slice(0, 2);
      if (p.selectedOptionId && p.eliminated.includes(p.selectedOptionId)) p.selectedOptionId = null;
    } else if (kind === "clue") p.clueVisible = true;
    else p.extraSeconds = 5;
    this.emit("HINT", { id, kind });
    return true;
  }
  npcQuestion() {
    if (!this.npcPlan || this.players[1].lockedOptionId || this.phaseTime < this.npcPlan.at) return;
    const optionId = this.npcPlan.optionId;
    this.npcPlan = null;
    this.selectFor(this.context(1, optionId), true);
    this.lockFor(this.context(1, optionId), true);
  }
  allFinished() {
    return this.players.every((p) => p.lockedOptionId !== null || this.remaining(p.playerId) <= 1e-7);
  }
  pause(reason = "\u8CFD\u5C40\u5DF2\u66AB\u505C") {
    if (!this.live || this.paused) return;
    this.paused = true;
    this.pauseReason = reason;
    this.resumeReady = [false, this.mode === "solo"];
    this.emit("PAUSE");
  }
  confirmResume(id) {
    if (!this.paused) return false;
    this.resumeReady[id] = true;
    return this.resumeReady.every(Boolean);
  }
  resume() {
    if (!this.paused || !this.resumeReady.every(Boolean)) return;
    this.paused = false;
    this.resumeReady = [false, false];
    this.emit("RESUME");
  }
  activateQuestion() {
    if (this.phase !== "QUESTION_LOADING" || this.paused) return;
    this.transition("QUESTION_ACTIVE");
    this.record.startedAt = this.clock;
    if (this.mode === "solo") {
      const level = NPC_LEVELS[this.npcLevel], q = this.question;
      const chance = level.accuracy - (q.difficulty === "\u9032\u968E" ? 0.12 : q.difficulty === "\u6A19\u6E96" ? 0.04 : 0);
      const correct = this.npcRng() < chance;
      const wrong = q.options.filter((o) => o.optionId !== q.correctOptionId);
      this.npcPlan = { at: (level.minDelay + this.npcRng() * (level.maxDelay - level.minDelay)) * this.settings.questionSeconds, optionId: correct ? q.correctOptionId : wrong[Math.floor(this.npcRng() * wrong.length)].optionId };
    }
  }
  context(id, optionId) {
    return { matchId: this.matchId, questionId: this.question?.questionId ?? "", playerId: id, optionId };
  }
  valid(input, npc = false) {
    return (npc || !this.isNpc(input.playerId)) && !this.paused && this.phase === "QUESTION_ACTIVE" && (input.playerId === 0 || input.playerId === 1) && this.remaining(input.playerId) > 1e-7 && input.matchId === this.matchId && input.questionId === this.question.questionId && (input.playerId === 0 || input.playerId === 1) && this.record.orders[input.playerId].includes(input.optionId) && !this.players[input.playerId].eliminated.includes(input.optionId) && this.players[input.playerId].lockedOptionId === null;
  }
  select(input) {
    return this.selectFor(input, false);
  }
  selectFor(input, npc) {
    if (!this.valid(input, npc)) return false;
    this.players[input.playerId].selectedOptionId = input.optionId;
    this.emit("SELECT", { id: input.playerId });
    return true;
  }
  lock(input) {
    return this.lockFor(input, false);
  }
  lockFor(input, npc) {
    if (!this.valid(input, npc) || this.players[input.playerId].selectedOptionId !== input.optionId) return false;
    const p = this.players[input.playerId];
    p.lockedOptionId = input.optionId;
    p.lockedAt = this.phaseTime;
    this.emit("LOCK", { id: input.playerId });
    if (this.allFinished()) this.resolveQuestion();
    return true;
  }
  skill(id, matchId = this.matchId, battleIndex = this.battleIndex, npc = false) {
    if (this.isNpc(id) && !npc) return false;
    const p = this.players[id];
    if (!p || this.paused || this.phase !== "BATTLE" || this.skillFreeze > 0 || this.phaseTime >= BALANCE.battleSeconds || this.clashIndex >= BALANCE.clashSeconds.length || matchId !== this.matchId || battleIndex !== this.battleIndex || p.energy < BALANCE.maxEnergy || p.skillUsed) return false;
    p.energy -= BALANCE.maxEnergy;
    p.pendingSkill = true;
    p.skillUsed = true;
    this.emit("SKILL_QUEUED", { id });
    return true;
  }
  advance(seconds) {
    if (this.paused || !this.live || seconds <= 0) return;
    let left = seconds;
    while (left > 1e-8 && !this.paused && this.live) {
      const dt = Math.min(left, BALANCE.fixedStep);
      this.step(dt);
      left -= dt;
    }
  }
  step(dt) {
    if (this.phase === "QUESTION_LOADING") return;
    this.clock += dt;
    if (this.phase === "BATTLE" && this.skillFreeze > 0) {
      this.skillFreeze = Math.max(0, this.skillFreeze - dt);
      if (this.skillFreeze === 0 && this.phaseTime >= BALANCE.battleSeconds - 1e-7) this.endBattle();
      return;
    }
    this.phaseTime += dt;
    if (this.phase === "COUNTDOWN" && this.phaseTime >= BALANCE.countdownSeconds - 1e-7) {
      this.beginBattle();
      return;
    }
    if (this.phase === "BATTLE") {
      if (this.mode === "solo" && this.phaseTime >= 1) this.skill(1, this.matchId, this.battleIndex, true);
      const over = Math.max(0, this.phaseTime - BALANCE.battleSeconds);
      const drain = Math.max(0, dt - over) * BALANCE.spinDrain;
      for (const p of this.players) {
        p.spin = Math.max(0, p.spin - drain * TOP_TYPES[TOPS[p.skin].type].drain / BALANCE.spinDrain);
        if (p.spin < 1e-8) p.spin = 0;
      }
      while (this.clashIndex < BALANCE.clashSeconds.length && this.phaseTime >= BALANCE.clashSeconds[this.clashIndex] - 1e-7) {
        this.clash();
        if (this.phase !== "BATTLE") return;
      }
      if (this.phaseTime >= BALANCE.battleSeconds - 1e-7 && this.skillFreeze === 0) this.endBattle();
    } else if (this.phase === "QUESTION_ACTIVE") {
      this.npcQuestion();
      if (this.phase === "QUESTION_ACTIVE" && this.allFinished()) this.resolveQuestion();
    } else if (this.phase === "REVEAL" && this.phaseTime >= BALANCE.revealSeconds - 1e-7) {
      this.battleIndex++;
      this.beginBattle();
    }
  }
  beginBattle() {
    this.clashIndex = 0;
    this.skillFreeze = 0;
    for (const p of this.players) {
      p.skillUsed = false;
      p.pendingSkill = false;
    }
    this.transition("BATTLE");
  }
  /** Both attack packets are calculated from the same snapshot, then applied together. */
  clash() {
    const key = `${this.matchId}:clash:${this.battleIndex}:${this.clashIndex}`;
    this.clashIndex++;
    if (this.handled.has(key)) return;
    this.handled.add(key);
    const snapshot = this.players.map((p) => ({ ...p }));
    const outgoing = snapshot.map((p) => normalDamage(p) + (p.pendingSkill ? BALANCE.skillDamage : 0));
    const sameSpin = snapshot[0].direction === snapshot[1].direction;
    const packets = snapshot.map((p, id) => Math.max(1, outgoing[1 - id] + (sameSpin ? 1 : 0) - TOP_TYPES[TOPS[p.skin].type].armor));
    const damage = snapshot.map((p, id) => Math.max(0, packets[id] - p.shield));
    if (!sameSpin) {
      const difference = snapshot[0].spin - snapshot[1].spin, transfer = Math.min(1, Math.abs(difference) / 2);
      this.players[0].spin -= Math.sign(difference) * transfer;
      this.players[1].spin += Math.sign(difference) * transfer;
    }
    this.players.forEach((p, id) => {
      p.hp = Math.max(0, snapshot[id].hp - damage[id]);
      p.shield = Math.max(0, snapshot[id].shield - packets[id]);
      p.firstHitBonus = 0;
      p.pendingSkill = false;
    });
    const skills = snapshot.map((p) => p.pendingSkill);
    this.emit("CLASH", { damage, skills, node: this.clashIndex, battleIndex: this.battleIndex });
    if (this.players.some((p) => p.hp === 0)) {
      this.finish();
      return;
    }
    if (skills.some(Boolean)) this.skillFreeze = BALANCE.skillFreezeSeconds;
  }
  endBattle() {
    for (const p of this.players) {
      p.shield = 0;
      p.attackBonus = 0;
      p.firstHitBonus = 0;
      p.pendingSkill = false;
    }
    if (this.records.length >= this.sequence.length) {
      this.finish();
      return;
    }
    const q = this.sequence[this.records.length];
    this.records.push({ questionId: q.questionId, orders: [shuffle(q.options.map((o) => o.optionId), this.rng), shuffle(q.options.map((o) => o.optionId), this.rng)], startedAt: null, answers: [], rewardsApplied: false });
    for (const p of this.players) {
      p.selectedOptionId = null;
      p.lockedOptionId = null;
      p.lockedAt = null;
      p.eliminated = [];
      p.clueVisible = false;
      p.extraSeconds = 0;
    }
    this.transition("QUESTION_LOADING");
  }
  resolveQuestion() {
    const r = this.record;
    if (r.rewardsApplied) return;
    const key = `${this.matchId}:question:${r.questionId}`;
    if (this.handled.has(key)) return;
    this.handled.add(key);
    r.answers = this.players.map((p) => ({ optionId: p.lockedOptionId, result: p.lockedOptionId === null ? "unanswered" : p.lockedOptionId === this.question.correctOptionId ? "correct" : "wrong", seconds: p.lockedAt, speed: false, hints: [...p.hintsUsed].filter((h) => h === "fifty" ? p.eliminated.length > 0 : h === "clue" ? p.clueVisible : p.extraSeconds > 0) }));
    if (r.answers.every((a) => a.result === "correct" && a.hints.length === 0)) {
      const diff = r.answers[0].seconds - r.answers[1].seconds;
      if (Math.abs(diff) > BALANCE.speedTieSeconds + 1e-8) r.answers[diff < 0 ? 0 : 1].speed = true;
    }
    r.answers.forEach((a, id) => {
      if (a.result !== "correct") return;
      const p = this.players[id];
      p.hp = Math.min(BALANCE.maxHP, p.hp + BALANCE.heal);
      p.spin = Math.min(BALANCE.maxSpin, p.spin + BALANCE.spinReward);
      p.shield = BALANCE.maxShield;
      p.attackBonus = BALANCE.correctAttack;
      p.firstHitBonus = a.speed ? BALANCE.speedAttack : 0;
      p.energy = Math.min(BALANCE.maxEnergy, p.energy + 1);
    });
    r.rewardsApplied = true;
    this.transition("REVEAL");
    this.emit("QUESTION_RESOLVED", { answers: r.answers });
  }
  finish() {
    const [a, b] = this.players;
    const sa = stats(this.records, 0), sb = stats(this.records, 1);
    let winner = null, reason = "\u96D9\u65B9\u8868\u73FE\u76F8\u540C\uFF0C\u4ECA\u5834\u5E73\u624B";
    if (a.hp === 0 && b.hp === 0) reason = "\u96D9\u65B9\u5728\u540C\u4E00\u78B0\u649E\u7BC0\u9EDE\u8017\u76E1 HP";
    else if (a.hp === 0 || b.hp === 0) {
      winner = a.hp > 0 ? 0 : 1;
      reason = "\u5C0D\u624B\u7684 HP \u5DF2\u8017\u76E1";
    } else if (a.hp !== b.hp) {
      winner = a.hp > b.hp ? 0 : 1;
      reason = "\u5269\u9918 HP \u8F03\u9AD8";
    } else if (sa.correct !== sb.correct) {
      winner = sa.correct > sb.correct ? 0 : 1;
      reason = "HP \u76F8\u540C\uFF0C\u7B54\u5C0D\u984C\u6578\u8F03\u591A";
    } else if (sa.average !== null && sb.average !== null && Math.abs(sa.average - sb.average) > BALANCE.speedTieSeconds + 1e-8) {
      winner = sa.average < sb.average ? 0 : 1;
      reason = "HP \u53CA\u7B54\u5C0D\u984C\u6578\u76F8\u540C\uFF0C\u6B63\u78BA\u7B54\u6848\u5E73\u5747\u7528\u6642\u8F03\u77ED";
    }
    this.outcome = { winner, reason };
    this.transition("RESULTS");
  }
};
var GameClock = class {
  previous = null;
  sample(now) {
    if (this.previous === null) {
      this.previous = now;
      return { delta: 0, interrupted: false };
    }
    const delta = Math.max(0, (now - this.previous) / 1e3);
    this.previous = now;
    return { delta, interrupted: delta > BALANCE.interruptionSeconds };
  }
  reset(now) {
    this.previous = now;
  }
};
export {
  GameClock,
  MatchController,
  QUESTIONS,
  drawQuestions,
  normalDamage,
  seededRandom,
  shuffle,
  stats
};
