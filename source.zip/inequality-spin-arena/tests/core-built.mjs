// src/tops.ts
var TOP_TYPES = {
  attack: { name: "\u653B\u64CA\u578B", damage: 2, armor: -1, drain: 2.5, description: "\u653B\u64CA 2 \xB7 \u6BCF\u6B21\u627F\u50B7 +1 \xB7 \u6BCF\u79D2\u8017\u65CB 2.5" },
  balance: { name: "\u5E73\u8861\u578B", damage: 1, armor: 0, drain: 2, description: "\u653B\u64CA 1 \xB7 \u6A19\u6E96\u627F\u50B7 \xB7 \u6BCF\u79D2\u8017\u65CB 2" },
  defense: { name: "\u9632\u79A6\u578B", damage: 1, armor: 1, drain: 1.8, description: "\u653B\u64CA 1 \xB7 \u6BCF\u6B21\u627F\u50B7 \u22121 \xB7 \u6BCF\u79D2\u8017\u65CB 1.8" }
};
var TOPS = [
  { name: "\u9706\u5149", color: "#50e9ef", type: "balance" },
  { name: "\u971C\u8861", color: "#88b4ff", type: "balance" },
  { name: "\u71FC\u92D2", color: "#ff9069", type: "attack" },
  { name: "\u7D2B\u96FB", color: "#c7a0ff", type: "attack" },
  { name: "\u68EE\u76FE", color: "#8be0aa", type: "defense" },
  { name: "\u91D1\u7A79", color: "#f2ce73", type: "defense" }
];
var NPC_LEVELS = {
  easy: { name: "\u7DF4\u7FD2\u4F19\u4F34", accuracy: 0.48, minDelay: 0.52, maxDelay: 0.85 },
  normal: { name: "\u65CB\u9B25\u5C0D\u624B", accuracy: 0.7, minDelay: 0.35, maxDelay: 0.7 },
  hard: { name: "\u9AD8\u624B\u6311\u6230", accuracy: 0.88, minDelay: 0.2, maxDelay: 0.5 }
};
var HINTS = { fifty: "50/50", clue: "\u89E3\u984C\u63D0\u793A", time: "\u52A0\u6642 5 \u79D2" };

// src/settings.ts
var BALANCE = Object.freeze({
  maxHP: 120,
  maxSpin: 100,
  spinDrain: 2,
  maxEnergy: 3,
  maxShield: 6,
  battleSeconds: 10,
  clashSeconds: [2, 4, 6, 8, 10],
  countdownSeconds: 3,
  revealSeconds: 8,
  resumeSeconds: 2,
  skillFreezeSeconds: 0.8,
  baseDamage: 1,
  correctAttack: 1,
  speedAttack: 1,
  speedTieSeconds: 0.15,
  heal: 20,
  spinReward: 20,
  skillDamage: 18,
  fixedStep: 1 / 60,
  interruptionSeconds: 3
});
var DEFAULT_SETTINGS = { difficulty: "mixed", questionSeconds: 15, questionCount: 6, completeAllQuestions: true, revealSeconds: 0, advancedExtraTime: true, music: 0.16, effects: 0.55, muted: false, reducedEffects: false, cameraShake: true, vibration: false };

// src/questions.json
var questions_default = [
  {
    questionId: "Q01",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u89E3 $x>2$ \u53CA $x\\le6$\u3002",
    options: [
      {
        optionId: "q01_o1",
        text: "$2<x\\le6$",
        misconceptionTag: null
      },
      {
        optionId: "q01_o2",
        text: "$2\\le x<6$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q01_o3",
        text: "$x>2$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      },
      {
        optionId: "q01_o4",
        text: "$x\\le6$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      }
    ],
    correctOptionId: "q01_o1",
    explanation: "\u5169\u500B\u689D\u4EF6\u9808\u540C\u6642\u6210\u7ACB\uFF0C\u56E0\u6B64\u53D6\u91CD\u758A\u90E8\u5206\u30022 \u4E0D\u5305\u62EC\uFF0C6 \u5305\u62EC\u3002",
    misconceptionTags: [
      "\u6F0F\u53D6\u4EA4\u96C6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ],
    hint: "\u628A\u5169\u500B\u689D\u4EF6\u756B\u5728\u540C\u4E00\u689D\u6578\u7DDA\u4E0A\uFF0C\u4FDD\u7559\u5171\u540C\u7BC4\u570D\uFF1B\u5DE6\u7AEF\u56B4\u683C\u5927\u65BC\uFF0C\u53F3\u7AEF\u5305\u62EC\u7B49\u865F\u3002"
  },
  {
    questionId: "Q02",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u5206\u96E2\u5340\u9593"
    ],
    prompt: "\u89E3 $x<-1$ \u6216 $x\\ge3$\u3002",
    options: [
      {
        optionId: "q02_o1",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u8AA4\u5224\u6240\u6709\u5BE6\u6578"
      },
      {
        optionId: "q02_o2",
        text: "$x<-1$ \u6216 $x\\ge3$",
        misconceptionTag: null
      },
      {
        optionId: "q02_o3",
        text: "$-1<x<3$",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q02_o4",
        text: "$-1\\le x\\le3$",
        misconceptionTag: "\u5167\u5916\u5340\u9593\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q02_o2",
    explanation: "\u7B26\u5408\u5DE6\u5074\u6216\u53F3\u5074\u4EFB\u4E00\u689D\u4EF6\u5373\u53EF\uFF1B\u4E2D\u9593\u7684 $-1\\le x<3$ \u4E0D\u5305\u62EC\u3002",
    misconceptionTags: [
      "\u5167\u5916\u5340\u9593\u6DF7\u6DC6",
      "\u628A\u6216\u7576\u53CA",
      "\u8AA4\u5224\u6240\u6709\u5BE6\u6578"
    ],
    hint: "\u5148\u6A19\u793A\u5DE6\u3001\u53F3\u5169\u6BB5\uFF0C\u518D\u5408\u4F75\uFF1B\u5169\u6BB5\u4E4B\u9593\u53EF\u80FD\u4ECD\u6709\u4E0D\u7B26\u5408\u689D\u4EF6\u7684\u6578\u3002"
  },
  {
    questionId: "Q03",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u540C\u5411\u7BC4\u570D"
    ],
    prompt: "\u89E3 $x\\ge-3$ \u53CA $x>1$\u3002",
    options: [
      {
        optionId: "q03_o1",
        text: "$-3\\le x\\le1$",
        misconceptionTag: "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6"
      },
      {
        optionId: "q03_o2",
        text: "$x\\ge1$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q03_o3",
        text: "$x>1$",
        misconceptionTag: null
      },
      {
        optionId: "q03_o4",
        text: "$x\\ge-3$",
        misconceptionTag: "\u9078\u53D6\u8F03\u5BEC\u7BC4\u570D"
      }
    ],
    correctOptionId: "q03_o3",
    explanation: "\u6240\u6709\u5927\u65BC 1 \u7684\u6578\u5DF2\u540C\u6642\u6EFF\u8DB3\u4E0D\u5C11\u65BC \u22123\uFF0C\u56E0\u6B64\u53D6\u8F03\u7A84\u7684\u7BC4\u570D $x>1$\u3002",
    misconceptionTags: [
      "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u9078\u53D6\u8F03\u5BEC\u7BC4\u570D"
    ],
    hint: "\u5169\u500B\u689D\u4EF6\u90FD\u662F\u4E0B\u9650\u3002\u300C\u53CA\u300D\u8981\u6C42\u540C\u6642\u7B26\u5408\uFF0C\u61C9\u9078\u8F03\u56B4\u683C\u7684\u4E0B\u9650\u3002"
  },
  {
    questionId: "Q04",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u540C\u5411\u7BC4\u570D"
    ],
    prompt: "\u89E3 $x\\le4$ \u6216 $x\\le-2$\u3002",
    options: [
      {
        optionId: "q04_o1",
        text: "$x\\le-2$",
        misconceptionTag: "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
      },
      {
        optionId: "q04_o2",
        text: "$-2\\le x\\le4$",
        misconceptionTag: "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D"
      },
      {
        optionId: "q04_o3",
        text: "$x<4$",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      },
      {
        optionId: "q04_o4",
        text: "$x\\le4$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q04_o4",
    explanation: "$x\\le-2$ \u7684\u7BC4\u570D\u5DF2\u5305\u62EC\u5728 $x\\le4$ \u4E4B\u5167\uFF0C\u53D6\u806F\u96C6\u5F8C\u70BA $x\\le4$\u3002",
    misconceptionTags: [
      "\u6F0F\u7AEF\u9EDE",
      "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D",
      "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
    ],
    hint: "\u5169\u500B\u689D\u4EF6\u90FD\u662F\u4E0A\u9650\u3002\u300C\u6216\u300D\u53EA\u8981\u7B26\u5408\u5176\u4E2D\u4E4B\u4E00\uFF0C\u60F3\u60F3\u54EA\u6BB5\u5DF2\u5305\u542B\u53E6\u4E00\u6BB5\u3002"
  },
  {
    questionId: "Q05",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u7121\u89E3"
    ],
    prompt: "\u89E3 $x<0$ \u53CA $x\\ge0$\u3002",
    options: [
      {
        optionId: "q05_o1",
        text: "\u7121\u89E3",
        misconceptionTag: null
      },
      {
        optionId: "q05_o2",
        text: "$x=0$",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q05_o3",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      },
      {
        optionId: "q05_o4",
        text: "$x<0$",
        misconceptionTag: "\u5FFD\u7565\u7B2C\u4E8C\u689D\u4EF6"
      }
    ],
    correctOptionId: "q05_o1",
    explanation: "\u6C92\u6709\u5BE6\u6578\u80FD\u540C\u6642\u5C0F\u65BC 0 \u53CA\u4E0D\u5C11\u65BC 0\uFF0C\u56E0\u6B64\u7121\u89E3\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u7B2C\u4E8C\u689D\u4EF6",
      "\u628A\u53CA\u7576\u6216",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ],
    hint: "\u8A66\u627E\u80FD\u540C\u6642\u5728 0 \u5DE6\u5074\u3001\u53C8\u4E0D\u5C11\u65BC 0 \u7684\u6578\uFF1B\u5169\u6BB5\u662F\u5426\u6709\u91CD\u758A\uFF1F"
  },
  {
    questionId: "Q06",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u6240\u6709\u5BE6\u6578"
    ],
    prompt: "\u89E3 $x\\le2$ \u6216 $x>2$\u3002",
    options: [
      {
        optionId: "q06_o1",
        text: "$x=2$",
        misconceptionTag: "\u8AA4\u53D6\u7AEF\u9EDE"
      },
      {
        optionId: "q06_o2",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: null
      },
      {
        optionId: "q06_o3",
        text: "\u7121\u89E3",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q06_o4",
        text: "$x<2$ \u6216 $x>2$",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      }
    ],
    correctOptionId: "q06_o2",
    explanation: "2 \u53CA\u6240\u6709\u5C0F\u65BC 2 \u7684\u6578\u7B26\u5408\u7B2C\u4E00\u689D\u4EF6\uFF0C\u5927\u65BC 2 \u7684\u6578\u7B26\u5408\u7B2C\u4E8C\u689D\u4EF6\uFF0C\u5408\u8D77\u4F86\u5305\u542B\u6240\u6709\u5BE6\u6578\u3002",
    misconceptionTags: [
      "\u628A\u6216\u7576\u53CA",
      "\u6F0F\u7AEF\u9EDE",
      "\u8AA4\u53D6\u7AEF\u9EDE"
    ],
    hint: "\u6AA2\u67E5\u7AEF\u9EDE 2\uFF0C\u4EE5\u53CA\u5B83\u5DE6\u53F3\u5169\u5074\u7684\u6578\uFF0C\u6709\u6C92\u6709\u6578\u88AB\u907A\u6F0F\uFF1F"
  },
  {
    questionId: "Q07",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u55AE\u9EDE\u89E3"
    ],
    prompt: "\u89E3 $x\\ge5$ \u53CA $x\\le5$\u3002",
    options: [
      {
        optionId: "q07_o1",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      },
      {
        optionId: "q07_o2",
        text: "$x>5$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q07_o3",
        text: "$x=5$",
        misconceptionTag: null
      },
      {
        optionId: "q07_o4",
        text: "\u7121\u89E3",
        misconceptionTag: "\u5FFD\u7565\u76F8\u7B49"
      }
    ],
    correctOptionId: "q07_o3",
    explanation: "\u5169\u689D\u4EF6\u5171\u540C\u5305\u542B\u7684\u552F\u4E00\u6578\u503C\u662F 5\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u76F8\u7B49",
      "\u628A\u53CA\u7576\u6216",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ],
    hint: "\u540C\u6642\u4E0D\u5C11\u65BC\u3001\u53C8\u4E0D\u5927\u65BC\u540C\u4E00\u500B\u6578\uFF0C\u80FD\u7559\u4E0B\u591A\u5C11\u500B\u6578\u503C\uFF1F"
  },
  {
    questionId: "Q08",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6216",
      "\u6392\u9664\u55AE\u9EDE"
    ],
    prompt: "\u5DF2\u77E5 $x<4$ \u6216 $x>4$\u3002$x$ \u4E0D\u80FD\u7B49\u65BC\u4E0B\u5217\u54EA\u500B\u6578\uFF1F",
    options: [
      {
        optionId: "q08_o1",
        text: "4",
        misconceptionTag: null
      },
      {
        optionId: "q08_o2",
        text: "\u22124",
        misconceptionTag: "\u8AA4\u6392\u5176\u4ED6\u6578\u503C"
      },
      {
        optionId: "q08_o3",
        text: "0",
        misconceptionTag: "\u8AA4\u6392\u5176\u4ED6\u6578\u503C"
      },
      {
        optionId: "q08_o4",
        text: "5",
        misconceptionTag: "\u8AA4\u6392\u5176\u4ED6\u6578\u503C"
      }
    ],
    correctOptionId: "q08_o1",
    explanation: "\u5C0F\u65BC 4 \u6216\u5927\u65BC 4 \u5305\u542B 4 \u4EE5\u5916\u7684\u6240\u6709\u5BE6\u6578\uFF0C\u56E0\u6B64 x \u4E0D\u80FD\u7B49\u65BC 4\u3002",
    misconceptionTags: [
      "\u5167\u5916\u7BC4\u570D\u6DF7\u6DC6",
      "\u628A\u6216\u7576\u53CA",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ],
    hint: "\u5C0F\u65BC\u548C\u5927\u65BC\u90FD\u6C92\u6709\u7B49\u865F\u3002\u6AA2\u67E5\u5169\u6BB5\u4E4B\u9593\u7684\u5206\u754C\u503C\u662F\u5426\u7B26\u5408\u4EFB\u4F55\u4E00\u5F0F\u3002"
  },
  {
    questionId: "Q09",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6578\u7DDA",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u54EA\u4E00\u689D\u6578\u7DDA\u8868\u793A $-2\\le x<3$\uFF1F",
    options: [
      {
        optionId: "q09_o1",
        text: "\u22122 \u70BA\u5BE6\u5FC3\u9EDE\uFF0C3 \u70BA\u7A7A\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: null
      },
      {
        optionId: "q09_o2",
        text: "\u22122 \u70BA\u7A7A\u5FC3\u9EDE\uFF0C3 \u70BA\u5BE6\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q09_o3",
        text: "\u5169\u9EDE\u5747\u70BA\u5BE6\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q09_o4",
        text: "\u5169\u9EDE\u5747\u70BA\u7A7A\u5FC3\u9EDE\uFF0C\u9023\u63A5\u5169\u9EDE\u4E4B\u9593",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      }
    ],
    correctOptionId: "q09_o1",
    explanation: "\u4E0D\u5C11\u65BC \u22122\uFF0C\u6240\u4EE5 \u22122 \u7528\u5BE6\u5FC3\u9EDE\uFF1B\u5C0F\u65BC 3\uFF0C\u6240\u4EE5 3 \u7528\u7A7A\u5FC3\u9EDE\uFF0C\u7BC4\u570D\u70BA\u5169\u9EDE\u4E4B\u9593\u3002",
    misconceptionTags: [
      "\u6F0F\u7AEF\u9EDE",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ],
    diagram: {
      type: "numberLineOptions",
      domain: [
        -4,
        5
      ],
      options: [
        {
          optionId: "q09_o1",
          lower: -2,
          upper: 3,
          lowerClosed: true,
          upperClosed: false
        },
        {
          optionId: "q09_o2",
          lower: -2,
          upper: 3,
          lowerClosed: false,
          upperClosed: true
        },
        {
          optionId: "q09_o3",
          lower: -2,
          upper: 3,
          lowerClosed: true,
          upperClosed: true
        },
        {
          optionId: "q09_o4",
          lower: -2,
          upper: 3,
          lowerClosed: false,
          upperClosed: false
        }
      ]
    },
    hint: "\u22122 \u662F\u4E0B\u9650\u800C\u4E14\u5305\u62EC\u7B49\u865F\uFF1B3 \u662F\u4E0A\u9650\u4F46\u6C92\u6709\u7B49\u865F\uFF0C\u5206\u5225\u9078\u5BE6\u5FC3\u8207\u7A7A\u5FC3\u7AEF\u9EDE\u3002"
  },
  {
    questionId: "Q10",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6574\u6578\u89E3",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u4E0B\u5217\u54EA\u4E00\u500B\u6574\u6578\u6EFF\u8DB3 $-1<x\\le2$\uFF1F",
    options: [
      {
        optionId: "q10_o1",
        text: "$-2$",
        misconceptionTag: "\u8D85\u51FA\u4E0B\u754C"
      },
      {
        optionId: "q10_o2",
        text: "$0$",
        misconceptionTag: null
      },
      {
        optionId: "q10_o3",
        text: "$-1$",
        misconceptionTag: "\u6F0F\u6AA2\u67E5\u958B\u7AEF\u9EDE"
      },
      {
        optionId: "q10_o4",
        text: "$3$",
        misconceptionTag: "\u8D85\u51FA\u4E0A\u754C"
      }
    ],
    correctOptionId: "q10_o2",
    explanation: "\u4EE3\u5165\u56DB\u500B\u9078\u9805\uFF0C\u53EA\u6709 0 \u5927\u65BC \u22121 \u800C\u4E0D\u5927\u65BC 2\u3002",
    misconceptionTags: [
      "\u6F0F\u6AA2\u67E5\u958B\u7AEF\u9EDE",
      "\u8D85\u51FA\u4E0A\u754C",
      "\u8D85\u51FA\u4E0B\u754C"
    ],
    hint: "\u628A\u56DB\u500B\u6574\u6578\u9010\u4E00\u4EE3\u5165\uFF0C\u5148\u6AA2\u67E5\u56B4\u683C\u4E0B\u9650\uFF0C\u518D\u6AA2\u67E5\u5305\u542B\u7B49\u865F\u7684\u4E0A\u9650\u3002"
  },
  {
    questionId: "Q11",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u53CA",
      "\u689D\u4EF6\u7406\u89E3"
    ],
    prompt: "\u300C\u689D\u4EF6\u4E00\u53CA\u689D\u4EF6\u4E8C\u300D\u7684\u610F\u601D\u662F\u751A\u9EBC\uFF1F",
    options: [
      {
        optionId: "q11_o1",
        text: "\u6070\u597D\u4E00\u500B\u689D\u4EF6\u6210\u7ACB",
        misconceptionTag: "\u8AA4\u89E3\u908F\u8F2F\u9023\u63A5"
      },
      {
        optionId: "q11_o2",
        text: "\u5169\u500B\u689D\u4EF6\u90FD\u4E0D\u6210\u7ACB",
        misconceptionTag: "\u8AA4\u89E3\u908F\u8F2F\u9023\u63A5"
      },
      {
        optionId: "q11_o3",
        text: "\u5169\u500B\u689D\u4EF6\u90FD\u9808\u6210\u7ACB",
        misconceptionTag: null
      },
      {
        optionId: "q11_o4",
        text: "\u81F3\u5C11\u4E00\u500B\u689D\u4EF6\u6210\u7ACB",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      }
    ],
    correctOptionId: "q11_o3",
    explanation: "\u300C\u53CA\u300D\u8981\u6C42\u540C\u6642\u6EFF\u8DB3\u5169\u500B\u689D\u4EF6\uFF1B\u300C\u6216\u300D\u624D\u662F\u81F3\u5C11\u6EFF\u8DB3\u4E00\u500B\u3002",
    misconceptionTags: [
      "\u628A\u53CA\u7576\u6216",
      "\u8AA4\u89E3\u908F\u8F2F\u9023\u63A5"
    ],
    hint: "\u300C\u53CA\u300D\u8981\u6C42\u5169\u500B\u689D\u4EF6\u540C\u6642\u6210\u7ACB\uFF1B\u53EF\u7528\u4E00\u500B\u53EA\u7B26\u5408\u5176\u4E2D\u4E00\u689D\u7684\u4F8B\u5B50\u6AA2\u67E5\u9078\u9805\u3002"
  },
  {
    questionId: "Q12",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6587\u5B57\u8F49\u4E0D\u7B49\u5F0F",
      "\u7AEF\u9EDE"
    ],
    prompt: "\u6578\u503C $x$ \u4E0D\u5C11\u65BC 2\uFF0C\u4F46\u5C11\u65BC 7\u3002\u54EA\u500B\u4E0D\u7B49\u5F0F\u6B63\u78BA\uFF1F",
    options: [
      {
        optionId: "q12_o1",
        text: "$2<x\\le7$",
        misconceptionTag: "\u908A\u754C\u8A5E\u8A9E\u6DF7\u6DC6"
      },
      {
        optionId: "q12_o2",
        text: "$2<x<7$",
        misconceptionTag: "\u6F0F\u4E0B\u754C\u7AEF\u9EDE"
      },
      {
        optionId: "q12_o3",
        text: "$2\\le x\\le7$",
        misconceptionTag: "\u8AA4\u52A0\u4E0A\u754C\u7AEF\u9EDE"
      },
      {
        optionId: "q12_o4",
        text: "$2\\le x<7$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q12_o4",
    explanation: "\u4E0D\u5C11\u65BC 2 \u5305\u62EC 2\uFF0C\u5C11\u65BC 7 \u4E0D\u5305\u62EC 7\u3002",
    misconceptionTags: [
      "\u6F0F\u4E0B\u754C\u7AEF\u9EDE",
      "\u8AA4\u52A0\u4E0A\u754C\u7AEF\u9EDE",
      "\u908A\u754C\u8A5E\u8A9E\u6DF7\u6DC6"
    ],
    hint: "\u300C\u4E0D\u5C11\u65BC\u300D\u5305\u62EC\u7B49\u865F\uFF0C\u300C\u5C11\u65BC\u300D\u4E0D\u5305\u62EC\u7B49\u865F\uFF1B\u5148\u5206\u5225\u7FFB\u8B6F\u5169\u53E5\u3002"
  },
  {
    questionId: "Q13",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u4EE3\u6578\u6C42\u89E3"
    ],
    prompt: "\u89E3 $2x+1>5$ \u53CA $3x-2\\le10$\u3002",
    options: [
      {
        optionId: "q13_o1",
        text: "$2<x\\le4$",
        misconceptionTag: null
      },
      {
        optionId: "q13_o2",
        text: "$2\\le x<4$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q13_o3",
        text: "$x>2$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      },
      {
        optionId: "q13_o4",
        text: "$x\\le4$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      }
    ],
    correctOptionId: "q13_o1",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $x>2$\uFF0C\u7B2C\u4E8C\u5F0F\u5F97 $x\\le4$\uFF0C\u53D6\u4EA4\u96C6\u70BA $2<x\\le4$\u3002",
    misconceptionTags: [
      "\u6F0F\u53D6\u4EA4\u96C6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ],
    hint: "\u7B2C\u4E00\u5F0F\u5148\u6E1B 1 \u518D\u9664 2\uFF1B\u7B2C\u4E8C\u5F0F\u5148\u52A0 2 \u518D\u9664 3\uFF0C\u6700\u5F8C\u53D6\u5171\u540C\u7BC4\u570D\u3002"
  },
  {
    questionId: "Q14",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u9664\u4EE5\u8CA0\u6578"
    ],
    prompt: "\u89E3 $7-2x\\ge1$ \u53CA $x+4>3$\u3002",
    options: [
      {
        optionId: "q14_o1",
        text: "$x>3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q14_o2",
        text: "$-1<x\\le3$",
        misconceptionTag: null
      },
      {
        optionId: "q14_o3",
        text: "$x\\ge3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q14_o4",
        text: "$-1\\le x<3$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q14_o2",
    explanation: "\u7B2C\u4E00\u5F0F\u70BA $-2x\\ge-6$\uFF0C\u9664\u4EE5 \u22122 \u6642\u53CD\u8F49\u4E0D\u7B49\u865F\uFF0C\u5F97 $x\\le3$\u3002\u7B2C\u4E8C\u5F0F\u5F97 $x>-1$\uFF0C\u6240\u4EE5 $-1<x\\le3$\u3002",
    misconceptionTags: [
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ],
    hint: "\u7B2C\u4E00\u5F0F\u6574\u7406\u5F8C\u9808\u9664\u4EE5 \u22122\uFF0C\u8981\u53CD\u8F49\u4E0D\u7B49\u865F\uFF1B\u7B2C\u4E8C\u5F0F\u5169\u908A\u6E1B 4\uFF0C\u518D\u53D6\u4EA4\u96C6\u3002"
  },
  {
    questionId: "Q15",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6216",
      "\u9664\u4EE5\u8CA0\u6578"
    ],
    prompt: "\u89E3 $-3x<9$ \u6216 $2x+1\\le-7$\u3002",
    options: [
      {
        optionId: "q15_o1",
        text: "$x<-3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q15_o2",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u5FFD\u7565\u5340\u9593\u7F3A\u53E3"
      },
      {
        optionId: "q15_o3",
        text: "$x\\le-4$ \u6216 $x>-3$",
        misconceptionTag: null
      },
      {
        optionId: "q15_o4",
        text: "$-4\\le x<-3$",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      }
    ],
    correctOptionId: "q15_o3",
    explanation: "\u7B2C\u4E00\u5F0F\u8207\u7B2C\u4E8C\u5F0F\u7684\u89E3\u5206\u5225\u70BA $x>-3$\uFF1B$x\\le-4$\uFF0C\u5169\u6BB5\u4E4B\u9593\u7684 $-4<x\\le-3$ \u4E0D\u7B26\u5408\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u5340\u9593\u7F3A\u53E3",
      "\u628A\u6216\u7576\u53CA",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ],
    hint: "\u7B2C\u4E00\u5F0F\u9664\u4EE5 \u22123 \u6642\u8981\u53CD\u865F\uFF1B\u7B2C\u4E8C\u5F0F\u5148\u6E1B 1 \u518D\u9664 2\uFF0C\u6700\u5F8C\u7528\u300C\u6216\u300D\u9023\u63A5\u3002"
  },
  {
    questionId: "Q16",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u62EC\u865F"
    ],
    prompt: "\u89E3 $2(x-1)\\le6$ \u53CA $5-x<4$\u3002",
    options: [
      {
        optionId: "q16_o1",
        text: "$x\\le1$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q16_o2",
        text: "$1\\le x<4$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q16_o3",
        text: "$x>1$",
        misconceptionTag: "\u6F0F\u53D6\u4EA4\u96C6"
      },
      {
        optionId: "q16_o4",
        text: "$1<x\\le4$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q16_o4",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $x\\le4$\uFF1B\u7B2C\u4E8C\u5F0F\u70BA $-x<-1$\uFF0C\u5F97 $x>1$\u3002\u6240\u4EE5 $1<x\\le4$\u3002",
    misconceptionTags: [
      "\u6F0F\u53D6\u4EA4\u96C6",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ],
    hint: "\u5148\u5C55\u958B\u7B2C\u4E00\u5F0F\u7684\u62EC\u865F\uFF1B\u7B2C\u4E8C\u5F0F\u6574\u7406\u6210 \u2212x \u7684\u5F62\u5F0F\u5F8C\u8981\u53CD\u865F\uFF0C\u6700\u5F8C\u53D6\u4EA4\u96C6\u3002"
  },
  {
    questionId: "Q17",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u9023\u9396\u4E0D\u7B49\u5F0F"
    ],
    prompt: "\u89E3 $-2<3x+1\\le7$\u3002",
    options: [
      {
        optionId: "q17_o1",
        text: "$-1<x\\le2$",
        misconceptionTag: null
      },
      {
        optionId: "q17_o2",
        text: "$-1\\le x<2$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q17_o3",
        text: "$-3<x\\le6$",
        misconceptionTag: "\u6F0F\u9664\u4FC2\u6578"
      },
      {
        optionId: "q17_o4",
        text: "$x<-1$ \u6216 $x\\ge2$",
        misconceptionTag: "\u5167\u5916\u5340\u9593\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q17_o1",
    explanation: "\u4E09\u90E8\u5206\u540C\u6E1B 1\uFF0C\u5F97 $-3<3x\\le6$\uFF0C\u518D\u540C\u9664\u4EE5 3\uFF0C\u5F97 $-1<x\\le2$\u3002",
    misconceptionTags: [
      "\u5167\u5916\u5340\u9593\u6DF7\u6DC6",
      "\u6F0F\u9664\u4FC2\u6578",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ],
    hint: "\u9023\u9396\u4E0D\u7B49\u5F0F\u7684\u4E09\u90E8\u5206\u5148\u540C\u6E1B 1\uFF0C\u518D\u540C\u9664\u4EE5\u6B63\u6578 3\u3002"
  },
  {
    questionId: "Q18",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6216",
      "\u4EE3\u6578\u6C42\u89E3"
    ],
    prompt: "\u89E3 $4x-3\\ge9$ \u6216 $2x+5<1$\u3002",
    options: [
      {
        optionId: "q18_o1",
        text: "\u7121\u89E3",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q18_o2",
        text: "$x<-2$ \u6216 $x\\ge3$",
        misconceptionTag: null
      },
      {
        optionId: "q18_o3",
        text: "$-2<x<3$",
        misconceptionTag: "\u628A\u6216\u7576\u53CA"
      },
      {
        optionId: "q18_o4",
        text: "$x\\le-2$ \u6216 $x>3$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      }
    ],
    correctOptionId: "q18_o2",
    explanation: "\u7B2C\u4E00\u5F0F\u8207\u7B2C\u4E8C\u5F0F\u7684\u89E3\u5206\u5225\u70BA $x\\ge3$\uFF1B$x<-2$\uFF0C\u7528\u6216\u9023\u63A5\u5169\u6BB5\u89E3\u3002",
    misconceptionTags: [
      "\u628A\u6216\u7576\u53CA",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ],
    hint: "\u7B2C\u4E00\u5F0F\u5148\u52A0 3 \u518D\u9664 4\uFF1B\u7B2C\u4E8C\u5F0F\u5148\u6E1B 5 \u518D\u9664 2\u3002\u5169\u6B65\u90FD\u662F\u9664\u4EE5\u6B63\u6578\uFF0C\u65B9\u5411\u4E0D\u8B8A\uFF0C\u6700\u5F8C\u53D6\u806F\u96C6\u3002"
  },
  {
    questionId: "Q19",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6216",
      "\u5305\u542B\u95DC\u4FC2"
    ],
    prompt: "\u89E3 $3x+6\\le0$ \u6216 $x-5<0$\u3002",
    options: [
      {
        optionId: "q19_o1",
        text: "$-2\\le x<5$",
        misconceptionTag: "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D"
      },
      {
        optionId: "q19_o2",
        text: "$x\\le5$",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q19_o3",
        text: "$x<5$",
        misconceptionTag: null
      },
      {
        optionId: "q19_o4",
        text: "$x\\le-2$",
        misconceptionTag: "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
      }
    ],
    correctOptionId: "q19_o3",
    explanation: "\u7B2C\u4E00\u5F0F\u8207\u7B2C\u4E8C\u5F0F\u7684\u89E3\u5206\u5225\u70BA $x\\le-2$\uFF1B$x<5$\u3002\u524D\u8005\u5DF2\u5305\u542B\u5728\u5F8C\u8005\uFF0C\u806F\u96C6\u70BA $x<5$\u3002",
    misconceptionTags: [
      "\u8AA4\u52A0\u7AEF\u9EDE",
      "\u8AA4\u53D6\u4E2D\u9593\u7BC4\u570D",
      "\u9078\u53D6\u8F03\u7A84\u7BC4\u570D"
    ],
    hint: "\u5169\u5F0F\u5206\u5225\u6574\u7406\u6210 x \u7684\u4E0A\u9650\uFF0C\u518D\u6AA2\u67E5\u54EA\u500B\u7BC4\u570D\u5305\u542B\u53E6\u4E00\u500B\uFF1B\u300C\u6216\u300D\u53D6\u8F03\u5927\u7BC4\u570D\u3002"
  },
  {
    questionId: "Q20",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u7121\u89E3"
    ],
    prompt: "\u89E3 $5-x>2$ \u53CA $2x-4\\ge4$\u3002",
    options: [
      {
        optionId: "q20_o1",
        text: "$3<x<4$",
        misconceptionTag: "\u932F\u53D6\u4E2D\u9593\u5340\u9593"
      },
      {
        optionId: "q20_o2",
        text: "$x<3$ \u6216 $x\\ge4$",
        misconceptionTag: "\u628A\u53CA\u7576\u6216"
      },
      {
        optionId: "q20_o3",
        text: "\u6240\u6709\u5BE6\u6578",
        misconceptionTag: "\u5FFD\u7565\u4E0D\u76F8\u5BB9\u689D\u4EF6"
      },
      {
        optionId: "q20_o4",
        text: "\u7121\u89E3",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q20_o4",
    explanation: "\u5206\u5225\u5F97\u5230 $x<3$ \u53CA $x\\ge4$\uFF0C\u6C92\u6709\u5171\u540C\u7BC4\u570D\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u4E0D\u76F8\u5BB9\u689D\u4EF6",
      "\u628A\u53CA\u7576\u6216",
      "\u932F\u53D6\u4E2D\u9593\u5340\u9593"
    ],
    hint: "\u7B2C\u4E00\u5F0F\u6574\u7406\u6210 \u2212x \u5F8C\u8981\u53CD\u865F\uFF1B\u7B2C\u4E8C\u5F0F\u5148\u52A0 4 \u518D\u9664 2\uFF0C\u6AA2\u67E5\u5169\u500B\u7BC4\u570D\u6709\u6C92\u6709\u4EA4\u96C6\u3002"
  },
  {
    questionId: "Q21",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6574\u6578\u89E3",
      "\u9023\u9396\u4E0D\u7B49\u5F0F"
    ],
    prompt: "\u6709\u591A\u5C11\u500B\u6574\u6578\u6EFF\u8DB3 $-3\\le2x+1<7$\uFF1F",
    options: [
      {
        optionId: "q21_o1",
        text: "5 \u500B",
        misconceptionTag: null
      },
      {
        optionId: "q21_o2",
        text: "4 \u500B",
        misconceptionTag: "\u6F0F\u7B97\u7AEF\u9EDE"
      },
      {
        optionId: "q21_o3",
        text: "6 \u500B",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q21_o4",
        text: "7 \u500B",
        misconceptionTag: "\u672A\u89E3\u4E0D\u7B49\u5F0F\u4FBF\u8A08\u6578"
      }
    ],
    correctOptionId: "q21_o1",
    explanation: "\u5316\u7C21\u5F97 $-2\\le x<3$\u3002\u6574\u6578\u70BA \u22122\u3001\u22121\u30010\u30011\u30012\uFF0C\u5171 5 \u500B\u3002",
    misconceptionTags: [
      "\u672A\u89E3\u4E0D\u7B49\u5F0F\u4FBF\u8A08\u6578",
      "\u6F0F\u7B97\u7AEF\u9EDE",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ],
    hint: "\u4E09\u90E8\u5206\u5148\u540C\u6E1B 1\u3001\u518D\u540C\u9664 2\u3002\u5217\u51FA\u5305\u62EC\u5DE6\u7AEF\u800C\u4E0D\u5305\u62EC\u53F3\u7AEF\u7684\u6240\u6709\u6574\u6578\u3002"
  },
  {
    questionId: "Q22",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6700\u5927\u8CA0\u6574\u6578",
      "\u5206\u6578\u754C\u9650"
    ],
    prompt: "\u6EFF\u8DB3 $x<-\\frac{7}{3}$ \u6216 $x\\ge4$ \u7684\u6700\u5927\u8CA0\u6574\u6578\u662F\u751A\u9EBC\uFF1F",
    options: [
      {
        optionId: "q22_o1",
        text: "$4$",
        misconceptionTag: "\u5FFD\u7565\u8CA0\u6574\u6578\u689D\u4EF6"
      },
      {
        optionId: "q22_o2",
        text: "$-3$",
        misconceptionTag: null
      },
      {
        optionId: "q22_o3",
        text: "$-2$",
        misconceptionTag: "\u8CA0\u6578\u5927\u5C0F\u6DF7\u6DC6"
      },
      {
        optionId: "q22_o4",
        text: "$-4$",
        misconceptionTag: "\u672A\u9078\u6700\u5927"
      }
    ],
    correctOptionId: "q22_o2",
    explanation: "\u8CA0\u6574\u6578\u53EA\u80FD\u4F86\u81EA $x<-\\frac{7}{3}$\u3002\u56E0\u70BA $-3<-\\frac{7}{3}<-2$\uFF0C\u6700\u5927\u8CA0\u6574\u6578\u662F \u22123\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u8CA0\u6574\u6578\u689D\u4EF6",
      "\u672A\u9078\u6700\u5927",
      "\u8CA0\u6578\u5927\u5C0F\u6DF7\u6DC6"
    ],
    hint: "\u53EA\u8003\u616E\u8CA0\u6574\u6578\uFF0C\u5148\u628A \u22127/3 \u8207\u9644\u8FD1\u6574\u6578\u6BD4\u8F03\uFF1B\u4E0D\u8981\u628A\u8F03\u63A5\u8FD1 0 \u4F46\u4E0D\u5408\u689D\u4EF6\u7684\u6578\u9078\u9032\u53BB\u3002"
  },
  {
    questionId: "Q23",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u6700\u5C0F\u6B63\u6574\u6578",
      "\u5206\u6578\u754C\u9650"
    ],
    prompt: "\u6EFF\u8DB3 $x>\\frac{5}{2}$ \u53CA $x\\le6$ \u7684\u6700\u5C0F\u6B63\u6574\u6578\u662F\u751A\u9EBC\uFF1F",
    options: [
      {
        optionId: "q23_o1",
        text: "$4$",
        misconceptionTag: "\u672A\u9078\u6700\u5C0F"
      },
      {
        optionId: "q23_o2",
        text: "$6$",
        misconceptionTag: "\u6DF7\u6DC6\u6700\u5C0F\u8207\u6700\u5927"
      },
      {
        optionId: "q23_o3",
        text: "$3$",
        misconceptionTag: null
      },
      {
        optionId: "q23_o4",
        text: "$2$",
        misconceptionTag: "\u672A\u8D85\u904E\u5206\u6578\u754C\u9650"
      }
    ],
    correctOptionId: "q23_o3",
    explanation: "$\\frac{5}{2}=2.5$\uFF0C\u5927\u65BC 2.5 \u800C\u4E0D\u5927\u65BC 6 \u7684\u6574\u6578\u70BA 3\u30014\u30015\u30016\uFF0C\u6700\u5C0F\u662F 3\u3002",
    misconceptionTags: [
      "\u672A\u8D85\u904E\u5206\u6578\u754C\u9650",
      "\u672A\u9078\u6700\u5C0F",
      "\u6DF7\u6DC6\u6700\u5C0F\u8207\u6700\u5927"
    ],
    hint: "\u5148\u628A 5/2 \u5316\u6210\u5C0F\u6578\uFF0C\u5F9E\u5B83\u53F3\u5074\u7B2C\u4E00\u500B\u6B63\u6574\u6578\u958B\u59CB\u6AA2\u67E5\u3002"
  },
  {
    questionId: "Q24",
    difficulty: "\u6A19\u6E96",
    topicTags: [
      "\u53CA",
      "\u5206\u5F0F"
    ],
    prompt: "\u89E3 $\\frac{x-1}{2}\\ge-1$ \u53CA $\\frac{3-x}{2}>0$\u3002",
    options: [
      {
        optionId: "q24_o1",
        text: "$-1<x\\le3$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q24_o2",
        text: "$x>3$",
        misconceptionTag: "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
      },
      {
        optionId: "q24_o3",
        text: "$-1\\le x\\le3$",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q24_o4",
        text: "$-1\\le x<3$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q24_o4",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $x-1\\ge-2$\uFF0C\u5373 $x\\ge-1$\uFF1B\u7B2C\u4E8C\u5F0F\u5F97 $x<3$\uFF0C\u6240\u4EE5 $-1\\le x<3$\u3002",
    misconceptionTags: [
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6",
      "\u8AA4\u52A0\u7AEF\u9EDE",
      "\u8CA0\u6578\u9664\u6CD5\u672A\u53CD\u865F"
    ],
    hint: "\u5169\u5F0F\u5148\u4E58\u6B63\u6578 2\u3002\u7B2C\u4E8C\u5F0F\u6574\u7406\u6210 \u2212x \u5F8C\u8981\u53CD\u865F\uFF0C\u6700\u5F8C\u53D6\u5171\u540C\u7BC4\u570D\u3002"
  },
  {
    questionId: "Q25",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u61C9\u7528",
      "\u6574\u6578\u500B\u6578"
    ],
    prompt: "\u6D3B\u52D5\u6536\u8CBB\u70BA 12 \u5143\u52A0\u6BCF\u5F35\u5361 4 \u5143\u3002\u5B78\u751F\u8CFC\u8CB7 $n$ \u5F35\u5361\uFF0C\u7E3D\u8CBB\u7528\u8D85\u904E 28 \u5143\u4F46\u4E0D\u8D85\u904E 44 \u5143\u3002$n$ \u6709\u591A\u5C11\u500B\u53EF\u80FD\u7684\u6574\u6578\u503C\uFF1F",
    options: [
      {
        optionId: "q25_o1",
        text: "4 \u500B",
        misconceptionTag: null
      },
      {
        optionId: "q25_o2",
        text: "3 \u500B",
        misconceptionTag: "\u6F0F\u7B97\u7AEF\u9EDE"
      },
      {
        optionId: "q25_o3",
        text: "5 \u500B",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      },
      {
        optionId: "q25_o4",
        text: "8 \u500B",
        misconceptionTag: "\u628A\u4E0A\u9650\u7576\u500B\u6578"
      }
    ],
    correctOptionId: "q25_o1",
    explanation: "$28<12+4n\\le44$\uFF0C\u5F97 $4<n\\le8$\uFF0C\u6240\u4EE5 $n=5,6,7,8$\uFF0C\u5171 4 \u500B\u3002",
    misconceptionTags: [
      "\u628A\u4E0A\u9650\u7576\u500B\u6578",
      "\u6F0F\u7B97\u7AEF\u9EDE",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ],
    hint: "\u628A\u7E3D\u8CBB\u7528\u5BEB\u6210 12+4n\uFF0C\u6309\u300C\u8D85\u904E\uFF0F\u4E0D\u8D85\u904E\u300D\u5BEB\u51FA\u5169\u500B\u689D\u4EF6\uFF0C\u518D\u6578\u6574\u6578\u3002"
  },
  {
    questionId: "Q26",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u4E09\u89D2\u4E0D\u7B49\u5F0F"
    ],
    prompt: "\u4E09\u89D2\u5F62\u7684\u4E09\u908A\u9577\u70BA 5 cm\u30019 cm \u53CA $x$ cm\u3002\u6C42 $x$ \u7684\u7BC4\u570D\u3002",
    options: [
      {
        optionId: "q26_o1",
        text: "$x>4$",
        misconceptionTag: "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u548C"
      },
      {
        optionId: "q26_o2",
        text: "$4<x<14$",
        misconceptionTag: null
      },
      {
        optionId: "q26_o3",
        text: "$4\\le x\\le14$",
        misconceptionTag: "\u5FFD\u7565\u56B4\u683C\u4E09\u89D2\u4E0D\u7B49\u5F0F"
      },
      {
        optionId: "q26_o4",
        text: "$0<x<14$",
        misconceptionTag: "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u5DEE"
      }
    ],
    correctOptionId: "q26_o2",
    explanation: "\u7531\u4E09\u89D2\u4E0D\u7B49\u5F0F\uFF0C$9-5<x<9+5$\uFF0C\u6240\u4EE5 $4<x<14$\uFF1B\u5169\u7AEF\u5747\u4E0D\u80FD\u53D6\u7B49\u865F\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u56B4\u683C\u4E09\u89D2\u4E0D\u7B49\u5F0F",
      "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u548C",
      "\u6F0F\u6AA2\u67E5\u5169\u908A\u4E4B\u5DEE"
    ],
    hint: "\u7B2C\u4E09\u908A\u9808\u5927\u65BC\u53E6\u5916\u5169\u908A\u4E4B\u5DEE\u7684\u7D55\u5C0D\u503C\uFF0C\u4E26\u5C0F\u65BC\u5169\u908A\u4E4B\u548C\uFF1B\u4E0D\u80FD\u53D6\u7B49\u865F\u3002"
  },
  {
    questionId: "Q27",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u53CA",
      "\u5206\u5F0F",
      "\u5169\u908A\u542B\u672A\u77E5\u6578"
    ],
    prompt: "\u89E3 $\\frac{2x-1}{3}<x+1$ \u53CA $4-x\\le2x+7$\u3002",
    options: [
      {
        optionId: "q27_o1",
        text: "$-4<x\\le-1$",
        misconceptionTag: "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6"
      },
      {
        optionId: "q27_o2",
        text: "$x>-1$",
        misconceptionTag: "\u6F0F\u7AEF\u9EDE"
      },
      {
        optionId: "q27_o3",
        text: "$x\\ge-1$",
        misconceptionTag: null
      },
      {
        optionId: "q27_o4",
        text: "$x>-4$",
        misconceptionTag: "\u6F0F\u53D6\u8F03\u7A84\u7BC4\u570D"
      }
    ],
    correctOptionId: "q27_o3",
    explanation: "\u7B2C\u4E00\u5F0F\u5F97 $2x-1<3x+3$\uFF0C\u5373 $x>-4$\uFF1B\u7B2C\u4E8C\u5F0F\u5F97 $-3x\\le3$\uFF0C\u5373 $x\\ge-1$\u3002\u53D6\u4EA4\u96C6\u70BA $x\\ge-1$\u3002",
    misconceptionTags: [
      "\u540C\u5411\u7BC4\u570D\u6DF7\u6DC6",
      "\u6F0F\u53D6\u8F03\u7A84\u7BC4\u570D",
      "\u6F0F\u7AEF\u9EDE"
    ],
    hint: "\u7B2C\u4E00\u5F0F\u5148\u4E58\u6B63\u6578 3 \u53BB\u5206\u6BCD\uFF1B\u5169\u5F0F\u6574\u7406\u5F8C\u5404\u6709\u4E00\u500B\u4E0B\u9650\uFF0C\u300C\u53CA\u300D\u8981\u53D6\u8F03\u56B4\u683C\u7684\u4E0B\u9650\u3002"
  },
  {
    questionId: "Q28",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u53CA\u6216\u6DF7\u5408"
    ],
    prompt: "\u89E3\u300C$x>-3$ \u53CA $x\\le1$\u300D\uFF0C\u6216 $x\\ge4$\u3002",
    options: [
      {
        optionId: "q28_o1",
        text: "$-3<x\\le4$",
        misconceptionTag: "\u8AA4\u5408\u4F75\u5340\u9593\u7F3A\u53E3"
      },
      {
        optionId: "q28_o2",
        text: "$x>-3$",
        misconceptionTag: "\u5FFD\u7565\u4E2D\u9593\u7F3A\u53E3"
      },
      {
        optionId: "q28_o3",
        text: "\u7121\u89E3",
        misconceptionTag: "\u628A\u6240\u6709\u689D\u4EF6\u7576\u53CA"
      },
      {
        optionId: "q28_o4",
        text: "$-3<x\\le1$ \u6216 $x\\ge4$",
        misconceptionTag: null
      }
    ],
    correctOptionId: "q28_o4",
    explanation: "\u5148\u89E3\u5F15\u865F\u5167\u7684\u53CA\uFF0C\u5F97 $-3<x\\le1$\uFF0C\u518D\u8207 $x\\ge4$ \u5408\u4F75\u3002$1<x<4$ \u4ECD\u4E0D\u5728\u89E3\u4E2D\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u4E2D\u9593\u7F3A\u53E3",
      "\u628A\u6240\u6709\u689D\u4EF6\u7576\u53CA",
      "\u8AA4\u5408\u4F75\u5340\u9593\u7F3A\u53E3"
    ],
    hint: "\u5148\u8655\u7406\u5F15\u865F\u5167\u7684\u300C\u53CA\u300D\uFF0C\u518D\u7528\u300C\u6216\u300D\u52A0\u5165\u53E6\u4E00\u6BB5\uFF1B\u6CE8\u610F\u4E2D\u9593\u53EF\u80FD\u6709\u7A7A\u9699\u3002"
  },
  {
    questionId: "Q29",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u5E7E\u4F55\u61C9\u7528",
      "\u53CA"
    ],
    prompt: "\u9577\u65B9\u5F62\u9577\u70BA 6 cm\uFF0C\u95CA\u70BA $(x+1)$ cm\u3002\u9762\u7A4D\u5927\u65BC 24 cm\xB2 \u4F46\u4E0D\u8D85\u904E 42 cm\xB2\u3002\u6C42 $x$ \u7684\u7BC4\u570D\u3002",
    options: [
      {
        optionId: "q29_o1",
        text: "$3<x\\le6$",
        misconceptionTag: null
      },
      {
        optionId: "q29_o2",
        text: "$4<x\\le7$",
        misconceptionTag: "\u5FFD\u7565\u95CA\u7684\u5E38\u6578\u9805"
      },
      {
        optionId: "q29_o3",
        text: "$3\\le x<6$",
        misconceptionTag: "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
      },
      {
        optionId: "q29_o4",
        text: "$x>3$",
        misconceptionTag: "\u6F0F\u53D6\u4E0A\u754C"
      }
    ],
    correctOptionId: "q29_o1",
    explanation: "$24<6(x+1)\\le42$\uFF0C\u9664\u4EE5 6 \u5F97 $4<x+1\\le7$\uFF0C\u6240\u4EE5 $3<x\\le6$\u3002\u6B64\u7BC4\u570D\u4EA6\u4FDD\u8B49\u95CA\u70BA\u6B63\u6578\u3002",
    misconceptionTags: [
      "\u5FFD\u7565\u95CA\u7684\u5E38\u6578\u9805",
      "\u6F0F\u53D6\u4E0A\u754C",
      "\u7AEF\u9EDE\u5305\u542B\u6DF7\u6DC6"
    ],
    hint: "\u7528\u9577 \xD7 \u95CA\u5BEB\u9762\u7A4D\uFF0C\u518D\u6309\u300C\u5927\u65BC\uFF0F\u4E0D\u8D85\u904E\u300D\u5BEB\u9023\u9396\u4E0D\u7B49\u5F0F\uFF0C\u6700\u5F8C\u6AA2\u67E5\u95CA\u662F\u5426\u70BA\u6B63\u6578\u3002"
  },
  {
    questionId: "Q30",
    difficulty: "\u9032\u968E",
    topicTags: [
      "\u6216",
      "\u6574\u6578\u89E3",
      "\u6307\u5B9A\u7BC4\u570D"
    ],
    prompt: "\u5DF2\u77E5 $x$ \u70BA\u6574\u6578\u4E14 $-2\\le x\\le2$\u3002\u6709\u591A\u5C11\u500B $x$ \u6EFF\u8DB3 $4-3x\\le1$ \u6216 $2x+5<3$\uFF1F",
    options: [
      {
        optionId: "q30_o1",
        text: "5 \u500B",
        misconceptionTag: "\u628A\u6216\u8AA4\u5224\u6240\u6709\u5BE6\u6578"
      },
      {
        optionId: "q30_o2",
        text: "3 \u500B",
        misconceptionTag: null
      },
      {
        optionId: "q30_o3",
        text: "2 \u500B",
        misconceptionTag: "\u6F0F\u7B97\u4E00\u6BB5\u89E3"
      },
      {
        optionId: "q30_o4",
        text: "4 \u500B",
        misconceptionTag: "\u8AA4\u52A0\u7AEF\u9EDE"
      }
    ],
    correctOptionId: "q30_o2",
    explanation: "\u5169\u5F0F\u5206\u5225\u5F97 $x\\ge1$ \u6216 $x<-1$\u3002\u5728\u6307\u5B9A\u7BC4\u570D\u5167\u7B26\u5408\u7684\u6574\u6578\u662F \u22122\u30011\u30012\uFF0C\u5171 3 \u500B\u3002",
    misconceptionTags: [
      "\u628A\u6216\u8AA4\u5224\u6240\u6709\u5BE6\u6578",
      "\u6F0F\u7B97\u4E00\u6BB5\u89E3",
      "\u8AA4\u52A0\u7AEF\u9EDE"
    ],
    hint: "\u5148\u5217\u51FA\u6307\u5B9A\u7BC4\u570D\u5167\u7684\u4E94\u500B\u6574\u6578\uFF0C\u518D\u6AA2\u67E5\u5404\u6578\u662F\u5426\u81F3\u5C11\u7B26\u5408\u5169\u5F0F\u4E2D\u7684\u4E00\u5F0F\u3002"
  },
  {
    questionId: "Q31",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6578\u7DDA",
      "\u7AEF\u9EDE"
    ],
    misconceptionTags: [
      "\u5DE6\u7AEF\u9EDE\u932F\u8AA4",
      "\u53F3\u7AEF\u9EDE\u932F\u8AA4",
      "\u7AEF\u9EDE\u932F\u8AA4"
    ],
    prompt: "\u54EA\u4E00\u689D\u6578\u7DDA\u8868\u793A $1<x\\le5$\uFF1F",
    hint: "\u5148\u627E\u7AEF\u9EDE 1 \u548C 5\u3002\u5305\u62EC\u7AEF\u9EDE\u7528\u5BE6\u5FC3\u9EDE\u6216\u4E2D\u62EC\u865F\uFF1B\u4E0D\u5305\u62EC\u7528\u7A7A\u5FC3\u9EDE\u6216\u5713\u62EC\u865F\u3002",
    options: [
      {
        optionId: "Q31-A",
        text: "$1<x\\le5$",
        misconceptionTag: null
      },
      {
        optionId: "Q31-B",
        text: "$1\\le x\\le5$",
        misconceptionTag: "\u5DE6\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q31-C",
        text: "$1<x<5$",
        misconceptionTag: "\u53F3\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q31-D",
        text: "$1\\le x<5$",
        misconceptionTag: "\u7AEF\u9EDE\u932F\u8AA4"
      }
    ],
    correctOptionId: "Q31-A",
    explanation: "\u5DE6\u7AEF\u9EDE 1\u4E0D\u5305\u62EC\uFF0C\u53F3\u7AEF\u9EDE 5\u5305\u62EC\u3002",
    diagram: {
      type: "number-line-options",
      domain: [
        -1,
        7
      ],
      options: [
        {
          optionId: "Q31-A",
          lower: 1,
          upper: 5,
          lowerClosed: false,
          upperClosed: true
        },
        {
          optionId: "Q31-B",
          lower: 1,
          upper: 5,
          lowerClosed: true,
          upperClosed: true
        },
        {
          optionId: "Q31-C",
          lower: 1,
          upper: 5,
          lowerClosed: false,
          upperClosed: false
        },
        {
          optionId: "Q31-D",
          lower: 1,
          upper: 5,
          lowerClosed: true,
          upperClosed: false
        }
      ]
    }
  },
  {
    questionId: "Q32",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6578\u7DDA",
      "\u7AEF\u9EDE"
    ],
    misconceptionTags: [
      "\u5DE6\u7AEF\u9EDE\u932F\u8AA4",
      "\u53F3\u7AEF\u9EDE\u932F\u8AA4",
      "\u7AEF\u9EDE\u932F\u8AA4"
    ],
    prompt: "\u54EA\u4E00\u689D\u6578\u7DDA\u8868\u793A $-4\\le x\\le2$\uFF1F",
    hint: "\u5148\u627E\u7AEF\u9EDE -4 \u548C 2\u3002\u5305\u62EC\u7AEF\u9EDE\u7528\u5BE6\u5FC3\u9EDE\u6216\u4E2D\u62EC\u865F\uFF1B\u4E0D\u5305\u62EC\u7528\u7A7A\u5FC3\u9EDE\u6216\u5713\u62EC\u865F\u3002",
    options: [
      {
        optionId: "Q32-A",
        text: "$-4\\le x\\le2$",
        misconceptionTag: null
      },
      {
        optionId: "Q32-B",
        text: "$-4<x\\le2$",
        misconceptionTag: "\u5DE6\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q32-C",
        text: "$-4\\le x<2$",
        misconceptionTag: "\u53F3\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q32-D",
        text: "$-4<x<2$",
        misconceptionTag: "\u7AEF\u9EDE\u932F\u8AA4"
      }
    ],
    correctOptionId: "Q32-A",
    explanation: "\u5DE6\u7AEF\u9EDE -4\u5305\u62EC\uFF0C\u53F3\u7AEF\u9EDE 2\u5305\u62EC\u3002",
    diagram: {
      type: "number-line-options",
      domain: [
        -6,
        4
      ],
      options: [
        {
          optionId: "Q32-A",
          lower: -4,
          upper: 2,
          lowerClosed: true,
          upperClosed: true
        },
        {
          optionId: "Q32-B",
          lower: -4,
          upper: 2,
          lowerClosed: false,
          upperClosed: true
        },
        {
          optionId: "Q32-C",
          lower: -4,
          upper: 2,
          lowerClosed: true,
          upperClosed: false
        },
        {
          optionId: "Q32-D",
          lower: -4,
          upper: 2,
          lowerClosed: false,
          upperClosed: false
        }
      ]
    }
  },
  {
    questionId: "Q33",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6578\u7DDA",
      "\u7AEF\u9EDE"
    ],
    misconceptionTags: [
      "\u5DE6\u7AEF\u9EDE\u932F\u8AA4",
      "\u53F3\u7AEF\u9EDE\u932F\u8AA4",
      "\u7AEF\u9EDE\u932F\u8AA4"
    ],
    prompt: "\u54EA\u4E00\u689D\u6578\u7DDA\u8868\u793A $0<x<7$\uFF1F",
    hint: "\u5148\u627E\u7AEF\u9EDE 0 \u548C 7\u3002\u5305\u62EC\u7AEF\u9EDE\u7528\u5BE6\u5FC3\u9EDE\u6216\u4E2D\u62EC\u865F\uFF1B\u4E0D\u5305\u62EC\u7528\u7A7A\u5FC3\u9EDE\u6216\u5713\u62EC\u865F\u3002",
    options: [
      {
        optionId: "Q33-A",
        text: "$0<x<7$",
        misconceptionTag: null
      },
      {
        optionId: "Q33-B",
        text: "$0\\le x<7$",
        misconceptionTag: "\u5DE6\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q33-C",
        text: "$0<x\\le7$",
        misconceptionTag: "\u53F3\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q33-D",
        text: "$0\\le x\\le7$",
        misconceptionTag: "\u7AEF\u9EDE\u932F\u8AA4"
      }
    ],
    correctOptionId: "Q33-A",
    explanation: "\u5DE6\u7AEF\u9EDE 0\u4E0D\u5305\u62EC\uFF0C\u53F3\u7AEF\u9EDE 7\u4E0D\u5305\u62EC\u3002",
    diagram: {
      type: "number-line-options",
      domain: [
        -2,
        9
      ],
      options: [
        {
          optionId: "Q33-A",
          lower: 0,
          upper: 7,
          lowerClosed: false,
          upperClosed: false
        },
        {
          optionId: "Q33-B",
          lower: 0,
          upper: 7,
          lowerClosed: true,
          upperClosed: false
        },
        {
          optionId: "Q33-C",
          lower: 0,
          upper: 7,
          lowerClosed: false,
          upperClosed: true
        },
        {
          optionId: "Q33-D",
          lower: 0,
          upper: 7,
          lowerClosed: true,
          upperClosed: true
        }
      ]
    }
  },
  {
    questionId: "Q34",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u6578\u7DDA",
      "\u7AEF\u9EDE"
    ],
    misconceptionTags: [
      "\u5DE6\u7AEF\u9EDE\u932F\u8AA4",
      "\u53F3\u7AEF\u9EDE\u932F\u8AA4",
      "\u7AEF\u9EDE\u932F\u8AA4"
    ],
    prompt: "\u54EA\u4E00\u689D\u6578\u7DDA\u8868\u793A $-3\\le x<4$\uFF1F",
    hint: "\u5148\u627E\u7AEF\u9EDE -3 \u548C 4\u3002\u5305\u62EC\u7AEF\u9EDE\u7528\u5BE6\u5FC3\u9EDE\u6216\u4E2D\u62EC\u865F\uFF1B\u4E0D\u5305\u62EC\u7528\u7A7A\u5FC3\u9EDE\u6216\u5713\u62EC\u865F\u3002",
    options: [
      {
        optionId: "Q34-A",
        text: "$-3\\le x<4$",
        misconceptionTag: null
      },
      {
        optionId: "Q34-B",
        text: "$-3<x<4$",
        misconceptionTag: "\u5DE6\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q34-C",
        text: "$-3\\le x\\le4$",
        misconceptionTag: "\u53F3\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q34-D",
        text: "$-3<x\\le4$",
        misconceptionTag: "\u7AEF\u9EDE\u932F\u8AA4"
      }
    ],
    correctOptionId: "Q34-A",
    explanation: "\u5DE6\u7AEF\u9EDE -3\u5305\u62EC\uFF0C\u53F3\u7AEF\u9EDE 4\u4E0D\u5305\u62EC\u3002",
    diagram: {
      type: "number-line-options",
      domain: [
        -5,
        6
      ],
      options: [
        {
          optionId: "Q34-A",
          lower: -3,
          upper: 4,
          lowerClosed: true,
          upperClosed: false
        },
        {
          optionId: "Q34-B",
          lower: -3,
          upper: 4,
          lowerClosed: false,
          upperClosed: false
        },
        {
          optionId: "Q34-C",
          lower: -3,
          upper: 4,
          lowerClosed: true,
          upperClosed: true
        },
        {
          optionId: "Q34-D",
          lower: -3,
          upper: 4,
          lowerClosed: false,
          upperClosed: true
        }
      ]
    }
  },
  {
    questionId: "Q35",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u5340\u9593\u8A18\u6CD5",
      "\u7AEF\u9EDE"
    ],
    misconceptionTags: [
      "\u5DE6\u7AEF\u9EDE\u932F\u8AA4",
      "\u53F3\u7AEF\u9EDE\u932F\u8AA4",
      "\u7AEF\u9EDE\u932F\u8AA4"
    ],
    prompt: "\u4E0D\u7B49\u5F0F $2<x\\le6$ \u53EF\u7528\u54EA\u500B\u5340\u9593\u8868\u793A\uFF1F",
    hint: "\u5148\u627E\u7AEF\u9EDE 2 \u548C 6\u3002\u5305\u62EC\u7AEF\u9EDE\u7528\u5BE6\u5FC3\u9EDE\u6216\u4E2D\u62EC\u865F\uFF1B\u4E0D\u5305\u62EC\u7528\u7A7A\u5FC3\u9EDE\u6216\u5713\u62EC\u865F\u3002",
    options: [
      {
        optionId: "Q35-A",
        text: "$(2,6]$",
        misconceptionTag: null
      },
      {
        optionId: "Q35-B",
        text: "$[2,6]$",
        misconceptionTag: "\u5DE6\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q35-C",
        text: "$(2,6)$",
        misconceptionTag: "\u53F3\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q35-D",
        text: "$[2,6)$",
        misconceptionTag: "\u7AEF\u9EDE\u932F\u8AA4"
      }
    ],
    correctOptionId: "Q35-A",
    explanation: "\u5DE6\u7AEF\u9EDE 2\u4E0D\u5305\u62EC\uFF0C\u53F3\u7AEF\u9EDE 6\u5305\u62EC\u3002"
  },
  {
    questionId: "Q36",
    difficulty: "\u57FA\u790E",
    topicTags: [
      "\u5340\u9593\u8A18\u6CD5",
      "\u7AEF\u9EDE"
    ],
    misconceptionTags: [
      "\u5DE6\u7AEF\u9EDE\u932F\u8AA4",
      "\u53F3\u7AEF\u9EDE\u932F\u8AA4",
      "\u7AEF\u9EDE\u932F\u8AA4"
    ],
    prompt: "\u4E0D\u7B49\u5F0F $-5\\le x<-1$ \u53EF\u7528\u54EA\u500B\u5340\u9593\u8868\u793A\uFF1F",
    hint: "\u5148\u627E\u7AEF\u9EDE -5 \u548C -1\u3002\u5305\u62EC\u7AEF\u9EDE\u7528\u5BE6\u5FC3\u9EDE\u6216\u4E2D\u62EC\u865F\uFF1B\u4E0D\u5305\u62EC\u7528\u7A7A\u5FC3\u9EDE\u6216\u5713\u62EC\u865F\u3002",
    options: [
      {
        optionId: "Q36-A",
        text: "$[-5,-1)$",
        misconceptionTag: null
      },
      {
        optionId: "Q36-B",
        text: "$(-5,-1)$",
        misconceptionTag: "\u5DE6\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q36-C",
        text: "$[-5,-1]$",
        misconceptionTag: "\u53F3\u7AEF\u9EDE\u932F\u8AA4"
      },
      {
        optionId: "Q36-D",
        text: "$(-5,-1]$",
        misconceptionTag: "\u7AEF\u9EDE\u932F\u8AA4"
      }
    ],
    correctOptionId: "Q36-A",
    explanation: "\u5DE6\u7AEF\u9EDE -5\u5305\u62EC\uFF0C\u53F3\u7AEF\u9EDE -1\u4E0D\u5305\u62EC\u3002"
  }
];

// src/generator.ts
var interval = (l, u, lc = false, uc = false) => ({ lower: l, upper: u, lowerClosed: lc, upperClosed: uc });
var sign = (n) => n < 0 ? `-${Math.abs(n)}` : `+${n}`;
var linear = (a, b) => `${a === 1 ? "" : a === -1 ? "-" : a}x${b ? sign(b) : ""}`;
function intervalText(s) {
  if (s.lower === null) return `$x${s.upperClosed ? "\\le" : "<"}${s.upper}$`;
  if (s.upper === null) return `$x${s.lowerClosed ? "\\ge" : ">"}${s.lower}$`;
  return `$${s.lower}${s.lowerClosed ? "\\le " : "<"}x${s.upperClosed ? "\\le" : "<"}${s.upper}$`;
}
var setText = (segments) => segments.length ? segments.map(intervalText).join(" \u6216 ") : "\u7121\u89E3";
var notation = (s) => `$${s.lowerClosed ? "[" : "("}${s.lower},${s.upper}${s.upperClosed ? "]" : ")"}$`;
function choices(id, sets, tags, texts) {
  return sets.map((solution, i) => ({ optionId: `${id}-${"ABCD"[i]}`, text: texts?.[i] ?? setText(solution), misconceptionTag: i ? tags[i - 1] : null, solution }));
}
function make(id, difficulty, tags, prompt, hint, options, explanation, conditions, logic = "and") {
  return { questionId: id, difficulty, topicTags: tags, misconceptionTags: [...new Set(options.flatMap((o) => o.misconceptionTag ? [o.misconceptionTag] : []))], prompt, hint, options, correctOptionId: options[0].optionId, explanation, check: { conditions, logic } };
}
function generateQuestionBank() {
  const out = [];
  for (let l = -4; l <= 4; l++) for (let span = 2; span <= 6; span++) {
    const u = l + span;
    for (let mask = 0; mask < 4; mask++) {
      const lc = !!(mask & 1), uc = !!(mask & 2), s = interval(l, u, lc, uc), id = `G-I-${l}-${u}-${mask}`;
      const sets = [[s], [interval(l, u, !lc, !uc)], [interval(l - 1, u, lc, uc)], [interval(l, u + 1, lc, uc)]];
      const cs = [{ a: 1, b: 0, sign: lc ? ">=" : ">", c: l }, { a: 1, b: 0, sign: uc ? "<=" : "<", c: u }];
      const q = make(id, "\u57FA\u790E", ["\u5340\u9593\u8A18\u6CD5", "\u7AEF\u9EDE"], `\u4E0D\u7B49\u5F0F ${intervalText(s)} \u53EF\u7528\u54EA\u500B\u5340\u9593\u8868\u793A\uFF1F`, `\u5148\u770B\u5DE6\u53F3\u5169\u500B\u7AEF\u9EDE\uFF1A${lc ? "\u5305\u62EC" : "\u4E0D\u5305\u62EC"}\u5DE6\u7AEF\u9EDE\u3001${uc ? "\u5305\u62EC" : "\u4E0D\u5305\u62EC"}\u53F3\u7AEF\u9EDE\u3002\u4E2D\u62EC\u865F\u8868\u793A\u5305\u62EC\uFF0C\u5713\u62EC\u865F\u8868\u793A\u4E0D\u5305\u62EC\u3002`, choices(id, [[s], [interval(l, u, !lc, uc)], [interval(l, u, lc, !uc)], [interval(l, u, !lc, !uc)]], ["\u5DE6\u7AEF\u9EDE\u932F\u8AA4", "\u53F3\u7AEF\u9EDE\u932F\u8AA4", "\u7AEF\u9EDE\u932F\u8AA4"], [notation(s), notation(interval(l, u, !lc, uc)), notation(interval(l, u, lc, !uc)), notation(interval(l, u, !lc, !uc))]), `${intervalText(s)} \u7684\u5DE6\u7AEF\u9EDE${lc ? "\u5305\u62EC" : "\u4E0D\u5305\u62EC"}\uFF0C\u53F3\u7AEF\u9EDE${uc ? "\u5305\u62EC" : "\u4E0D\u5305\u62EC"}\uFF0C\u6240\u4EE5\u662F ${notation(s)}\u3002`, cs);
      out.push(q);
      const did = `G-D-${l}-${u}-${mask}`, d = make(did, "\u57FA\u790E", ["\u6578\u7DDA", "\u7AEF\u9EDE"], `\u54EA\u4E00\u689D\u6578\u7DDA\u8868\u793A ${intervalText(s)}\uFF1F`, `\u5148\u627E\u6578\u7DDA\u4E0A\u7684 ${l} \u548C ${u}\uFF0C\u518D\u7528\u5BE6\u5FC3\u9EDE\u8868\u793A\u5305\u62EC\u7AEF\u9EDE\u3001\u7A7A\u5FC3\u9EDE\u8868\u793A\u4E0D\u5305\u62EC\u7AEF\u9EDE\u3002`, choices(did, sets, ["\u7AEF\u9EDE\u932F\u8AA4", "\u4E0B\u9650\u932F\u8AA4", "\u4E0A\u9650\u932F\u8AA4"]), `\u7BC4\u570D\u7531 ${l} \u81F3 ${u}\uFF1B\u5DE6\u7AEF\u9EDE${lc ? "\u7528\u5BE6\u5FC3\u9EDE" : "\u7528\u7A7A\u5FC3\u9EDE"}\uFF0C\u53F3\u7AEF\u9EDE${uc ? "\u7528\u5BE6\u5FC3\u9EDE" : "\u7528\u7A7A\u5FC3\u9EDE"}\u3002`, cs);
      d.diagram = { type: "number-line-options", domain: [l - 2, u + 2], options: d.options.map((o, i) => ({ optionId: o.optionId, segments: sets[i] })) };
      out.push(d);
    }
    for (let k = 2; k <= 4; k++) {
      const b = 3 + k, id = `G-N-${l}-${u}-${k}`, s = interval(l, u, false, true), conditions = [{ a: -k, b, sign: ">=", c: b - k * u }, { a: 1, b: 2, sign: ">", c: l + 2 }];
      const options = choices(id, [[s], [interval(u, null, true, false)], [interval(l, u, true, false)], [interval(null, u, false, true), interval(l, null, false, false)]], ["\u5FD8\u8A18\u53CD\u8F49\u4E0D\u7B49\u865F", "\u7AEF\u9EDE\u932F\u8AA4", "\u53CA\u6216\u8ABF\u8F49"]);
      out.push(make(id, "\u6A19\u6E96", ["\u53CA", "\u9664\u4EE5\u8CA0\u6578"], `\u89E3 $${linear(-k, b)}\\ge${b - k * u}$ \u53CA $x+2>${l + 2}$\u3002`, `\u7B2C\u4E00\u5F0F\u5148\u6E1B\u53BB ${b}\uFF0C\u518D\u9664\u4EE5 $-${k}$\uFF1B\u9019\u4E00\u6B65\u8981\u53CD\u8F49\u4E0D\u7B49\u865F\u3002\u7B2C\u4E8C\u5F0F\u5169\u908A\u6E1B 2\uFF0C\u6700\u5F8C\u53D6\u5171\u540C\u7BC4\u570D\u3002`, options, `\u7B2C\u4E00\u5F0F\u5F97 $x\\le${u}$\uFF1B\u7B2C\u4E8C\u5F0F\u5F97 $x>${l}$\u3002\u300C\u53CA\u300D\u53D6\u4EA4\u96C6\uFF0C\u6240\u4EE5 ${intervalText(s)}\u3002`, conditions));
      const aid = `G-A-${l}-${u}-${k}`, offset = k + 1, s2 = interval(l, u, true, false), cs = [{ a: -k, b: offset, sign: "<=", c: offset - k * l }, { a: k, b: -offset, sign: "<", c: k * u - offset }];
      out.push(make(aid, "\u9032\u968E", ["\u53CA", "\u5206\u5F0F", "\u9664\u4EE5\u8CA0\u6578"], `\u89E3 $\\frac{${linear(-k, offset)}}{${k}}\\le\\frac{${offset - k * l}}{${k}}$ \u53CA $\\frac{${linear(k, -offset)}}{${k}}<\\frac{${k * u - offset}}{${k}}$\u3002`, `\u5169\u5F0F\u5148\u4E58\u6B63\u6578 ${k} \u53BB\u5206\u6BCD\uFF0C\u65B9\u5411\u4E0D\u8B8A\u3002\u7B2C\u4E00\u5F0F\u518D\u9664\u4EE5\u8CA0\u6578 $-${k}$ \u6642\u624D\u53CD\u865F\uFF0C\u6700\u5F8C\u53D6\u4EA4\u96C6\u3002`, choices(aid, [[s2], [interval(null, l, false, true)], [interval(l, u, false, true)], [interval(null, u, false, false), interval(l, null, true, false)]], ["\u5FD8\u8A18\u53CD\u8F49\u4E0D\u7B49\u865F", "\u7AEF\u9EDE\u932F\u8AA4", "\u53CA\u6216\u8ABF\u8F49"]), `\u53BB\u5206\u6BCD\u5F8C\uFF0C\u7B2C\u4E00\u5F0F\u5F97 $x\\ge${l}$\uFF1B\u7B2C\u4E8C\u5F0F\u5F97 $x<${u}$\u3002\u5171\u540C\u7BC4\u570D\u70BA ${intervalText(s2)}\u3002`, cs));
    }
    for (let mask = 0; mask < 2; mask++) {
      const lc = !!mask, uc = !mask, id = `G-O-${l}-${u}-${mask}`, solution = [interval(null, l, false, lc), interval(u, null, uc, false)], cs = [{ a: 2, b: 1, sign: lc ? "<=" : "<", c: 2 * l + 1 }, { a: 3, b: -2, sign: uc ? ">=" : ">", c: 3 * u - 2 }];
      out.push(make(id, "\u6A19\u6E96", ["\u6216", "\u5206\u96E2\u5340\u9593"], `\u89E3 $2x+1${lc ? "\\le" : "<"}${2 * l + 1}$ \u6216 $3x-2${uc ? "\\ge" : ">"}${3 * u - 2}$\u3002`, "\u5148\u5206\u5225\u6574\u7406\u5169\u5F0F\uFF0C\u7559\u610F\u6BCF\u5F0F\u662F\u5426\u5305\u542B\u7B49\u865F\u3002\u300C\u6216\u300D\u8868\u793A\u81F3\u5C11\u7B26\u5408\u4E00\u5F0F\uFF0C\u5408\u4F75\u5DE6\u53F3\u5169\u6BB5\u7BC4\u570D\u3002", choices(id, [solution, [], [interval(l, u, lc, uc)], [interval(null, l, false, !lc), interval(u, null, !uc, false)]], ["\u53CA\u6216\u8ABF\u8F49", "\u932F\u53D6\u4E2D\u9593\u7BC4\u570D", "\u7AEF\u9EDE\u932F\u8AA4"]), `\u7B2C\u4E00\u5F0F\u5F97 ${intervalText(solution[0])}\uFF1B\u7B2C\u4E8C\u5F0F\u5F97 ${intervalText(solution[1])}\u3002\u7528\u300C\u6216\u300D\u5408\u4F75\u5169\u6BB5\uFF0C\u4E0D\u80FD\u53D6\u4E2D\u9593\u7BC4\u570D\u3002`, cs, "or"));
    }
  }
  for (let lower = 1; lower <= 5; lower++) for (let span = 3; span <= 6; span++) for (let price = 2; price <= 4; price++) {
    const upper = lower + span, fixed = 5 + price, id = `G-W-${lower}-${upper}-${price}`, n = span;
    const options = [n, n - 1, n + 1, n + 2].map((v, i) => ({ optionId: `${id}-${"ABCD"[i]}`, text: `${v} \u500B`, numericValue: v, misconceptionTag: i ? ["\u6F0F\u7B97\u6574\u6578", "\u7AEF\u9EDE\u932F\u8AA4", "\u672A\u8655\u7406\u56FA\u5B9A\u8CBB\u7528"][i - 1] : null }));
    const q = make(id, "\u9032\u968E", ["\u61C9\u7528", "\u6574\u6578\u500B\u6578"], `\u6D3B\u52D5\u6536\u56FA\u5B9A\u8CBB ${fixed} \u5143\uFF0C\u53E6\u6BCF\u5F35\u5361 ${price} \u5143\u3002\u7E3D\u8CBB\u7528\u8D85\u904E ${fixed + price * lower} \u5143\u4F46\u4E0D\u8D85\u904E ${fixed + price * upper} \u5143\u3002\u8CFC\u8CB7\u5361\u7684\u5F35\u6578 $n$ \u6709\u591A\u5C11\u500B\u53EF\u80FD\u7684\u6574\u6578\u503C\uFF1F`, `\u5148\u7528\u300C${fixed}+${price}n\u300D\u8868\u793A\u7E3D\u8CBB\u7528\u3002\u300C\u8D85\u904E\u300D\u4E0D\u5305\u62EC\u7B49\u865F\uFF0C\u300C\u4E0D\u8D85\u904E\u300D\u5305\u62EC\u7B49\u865F\u3002\u89E3\u51FA\u7BC4\u570D\u5F8C\u9010\u4E00\u6578\u6B63\u6574\u6578\u3002`, options, `\u7531 $${fixed + price * lower}<${fixed}+${price}n\\le${fixed + price * upper}$ \u5F97 $${lower}<n\\le${upper}$\u3002\u6574\u6578\u7531 ${lower + 1} \u81F3 ${upper}\uFF0C\u5171\u6709 ${n} \u500B\u3002`, [{ a: price, b: fixed, sign: ">", c: fixed + price * lower }, { a: price, b: fixed, sign: "<=", c: fixed + price * upper }]);
    q.check.integerOnly = true;
    out.push(q);
  }
  return out;
}

// src/diagrams.ts
var escape = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
function numberLineSVG(q, optionId) {
  const d = q.diagram?.options.find((o) => o.optionId === optionId);
  if (!d || !q.diagram) return "";
  const segments = d.segments ?? [{ lower: d.lower ?? null, upper: d.upper ?? null, lowerClosed: !!d.lowerClosed, upperClosed: !!d.upperClosed }];
  let [min, max] = q.diagram.domain;
  if (!Number.isFinite(min) || !Number.isFinite(max) || min >= max) {
    const bounds = segments.flatMap((s) => [s.lower, s.upper].filter((x2) => x2 !== null && Number.isFinite(x2)));
    min = Math.min(-1, ...bounds) - 2;
    max = Math.max(1, ...bounds) + 2;
  }
  const left = 20, right = 300, y = 30, x = (n) => left + (n - min) / (max - min) * (right - left), labels = /* @__PURE__ */ new Map();
  const lines = segments.map((s) => {
    const a = s.lower === null ? left : x(s.lower), b = s.upper === null ? right : x(s.upper);
    let svg = `<path class="interval" d="M${a} ${y}H${b}"/>`;
    for (const [v, closed, edge] of [[s.lower, s.lowerClosed, "left"], [s.upper, s.upperClosed, "right"]]) {
      if (v === null) {
        const px = edge === "left" ? left : right, dx = edge === "left" ? 6 : -6;
        svg += `<path class="interval-arrow" d="M${px + dx} ${y - 5}L${px} ${y}L${px + dx} ${y + 5}"/>`;
      } else {
        labels.set(v, x(v));
        svg += `<circle class="endpoint ${closed ? "closed" : ""}" data-value="${v}" cx="${x(v)}" cy="${y}" r="5"/>`;
      }
    }
    return svg;
  }).join("");
  return `<svg class="number-line" viewBox="0 0 320 72" role="img" aria-label="${escape(q.options.find((o) => o.optionId === optionId)?.text ?? "\u6578\u7DDA")}"><path class="axis" d="M12 ${y}H308m-6-5 6 5-6 5M18 ${y - 5}l-6 5 6 5"/>${lines}${[...labels].map(([v, px]) => `<text x="${px}" y="61">${String(v).replace("-", "\u2212")}</text>`).join("")}</svg>`;
}

// src/export.ts
var safeText = (value) => {
  const s = String(value ?? "");
  return /^[=+@-]/.test(s) ? "'" + s : s;
};
var cell = (value) => `"${safeText(value).replaceAll('"', '""')}"`;
function matchCSV(game) {
  const rows = [["\u5834\u6B21", "\u958B\u59CB\u6642\u9593", "\u6A21\u5F0F", "\u73A9\u5BB6", "\u9640\u87BA", "\u985E\u578B", "\u65CB\u5411", "\u984C\u5E8F", "\u984C\u865F", "\u984C\u76EE", "\u96E3\u5EA6", "\u9078\u64C7\u7B54\u6848", "\u6B63\u78BA\u7B54\u6848", "\u7D50\u679C", "\u7528\u6642\uFF08\u79D2\uFF09", "\u5DF2\u7528\u63D0\u793A", "\u932F\u8AA4\u985E\u578B"]];
  for (const [i, r] of game.records.entries()) if (r.rewardsApplied) {
    const q = r.question;
    for (const [id, a] of r.answers.entries()) {
      const selected = q.options.find((o) => o.optionId === a.optionId), correct = q.options.find((o) => o.optionId === q.correctOptionId), p = game.players[id], top = TOPS[p.skin];
      rows.push([game.matchId, game.startedAtISO, game.mode === "solo" ? "\u55AE\u4EBA NPC" : "\u96D9\u4EBA\u540C\u6A5F", game.isNpc(id) ? "NPC" : `P${id + 1}`, top.name, TOP_TYPES[top.type].name, p.direction === "left" ? "\u5DE6\u65CB" : "\u53F3\u65CB", i + 1, q.questionId, q.prompt, q.difficulty, selected?.text ?? "", correct.text, { correct: "\u7B54\u5C0D", wrong: "\u7B54\u932F", unanswered: "\u672A\u4F5C\u7B54" }[a.result], a.seconds === null ? "" : a.seconds.toFixed(2), a.hints.map((h) => HINTS[h]).join("\uFF0F"), a.result === "unanswered" ? "\u672A\u9396\u5B9A\u7B54\u6848" : selected?.misconceptionTag ?? ""]);
    }
  }
  return "\uFEFF" + rows.map((row) => row.map(cell).join(",")).join("\r\n") + "\r\n";
}

// src/core.ts
var QUESTIONS = questions_default;
var GENERATED_QUESTIONS = generateQuestionBank();
var ALL_QUESTIONS = [...QUESTIONS, ...GENERATED_QUESTIONS];
function seededRandom(seed) {
  let a = seed >>> 0;
  return () => {
    a += 1831565813;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function shuffle(list, rng) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function drawQuestions(s, rng, recentIds = []) {
  const recent = new Set(recentIds);
  const take = (difficulty, n) => {
    const pool = ALL_QUESTIONS.filter((q) => q.difficulty === difficulty), fresh = pool.filter((q) => !recent.has(q.questionId));
    const candidates = shuffle(fresh.length >= n ? fresh : pool, rng), chosen = [], used = /* @__PURE__ */ new Set();
    const family = (q) => q.topicTags.includes("\u6578\u7DDA") ? "diagram" : q.topicTags.includes("\u5340\u9593\u8A18\u6CD5") ? "notation" : q.topicTags.includes("\u4E09\u89D2\u4E0D\u7B49\u5F0F") ? "triangle" : q.topicTags.some((t) => t.includes("\u61C9\u7528")) ? "application" : q.topicTags.some((t) => t.includes("\u6574\u6578")) ? "integer" : q.topicTags.includes("\u53CA\u6216\u6DF7\u5408") ? "mixed" : q.topicTags.includes("\u6216") ? "union" : q.topicTags.includes("\u9023\u9396\u4E0D\u7B49\u5F0F") ? "chain" : "intersection";
    while (chosen.length < n && candidates.length) {
      let index = candidates.findIndex((q2) => !used.has(family(q2)));
      if (index < 0) {
        used.clear();
        index = 0;
      }
      const [q] = candidates.splice(index, 1);
      chosen.push(q);
      used.add(family(q));
    }
    return chosen;
  };
  if (s.difficulty !== "mixed") return take({ basic: "\u57FA\u790E", standard: "\u6A19\u6E96", advanced: "\u9032\u968E" }[s.difficulty], s.questionCount);
  const split = s.questionCount === 4 ? [1, 2, 1] : s.questionCount === 8 ? [3, 4, 1] : [2, 3, 1];
  return [...take("\u57FA\u790E", split[0]), ...take("\u6A19\u6E96", split[1]), ...take("\u9032\u968E", split[2])];
}
function freshPlayer(id, skin = id) {
  return { direction: id === 0 ? "right" : "left", hintsUsed: [], eliminated: [], clueVisible: false, extraSeconds: 0, playerId: id, hp: BALANCE.maxHP, spin: BALANCE.maxSpin, energy: 0, shield: 0, attackBonus: 0, firstHitBonus: 0, pendingSkill: false, skillUsed: false, selectedOptionId: null, lockedOptionId: null, lockedAt: null, ready: false, skin };
}
function normalDamage(p) {
  return Math.max(1, TOP_TYPES[TOPS[p.skin].type].damage + p.attackBonus + p.firstHitBonus - (p.spin === 0 ? 2 : p.spin < 30 ? 1 : 0));
}
function stats(records, id) {
  const answers = records.filter((r) => r.rewardsApplied).map((r) => r.answers[id]);
  const correct = answers.filter((a) => a.result === "correct");
  return { correct: correct.length, wrong: answers.filter((a) => a.result === "wrong").length, unanswered: answers.filter((a) => a.result === "unanswered").length, average: correct.length ? correct.reduce((n, a) => n + a.seconds, 0) / correct.length : null };
}
var MatchController = class {
  mode = "duo";
  npcLevel = "normal";
  npcRng = seededRandom(2);
  hintRng = seededRandom(3);
  npcPlan = null;
  phase = "TITLE";
  phaseTime = 0;
  clock = 0;
  players = [freshPlayer(0), freshPlayer(1)];
  matchId = "";
  startedAtISO = "";
  recentQuestionIds = [];
  revealReady = [false, false];
  seed = 1;
  settings = { ...DEFAULT_SETTINGS };
  sequence = [];
  records = [];
  battleIndex = 0;
  clashIndex = 0;
  skillFreeze = 0;
  paused = false;
  pauseReason = "";
  resumeReady = [false, false];
  outcome = null;
  events = [];
  rng = seededRandom(1);
  handled = /* @__PURE__ */ new Set();
  get question() {
    return this.sequence[this.records.length - 1];
  }
  get record() {
    return this.records.at(-1);
  }
  questionById(id) {
    return this.records.find((r) => r.questionId === id)?.question ?? this.sequence.find((q) => q.questionId === id) ?? ALL_QUESTIONS.find((q) => q.questionId === id);
  }
  get live() {
    return ["COUNTDOWN", "BATTLE", "QUESTION_LOADING", "QUESTION_ACTIVE", "REVEAL"].includes(this.phase);
  }
  emit(type, data = {}) {
    this.events.push({ type, ...data });
  }
  drainEvents() {
    return this.events.splice(0);
  }
  transition(phase) {
    this.phase = phase;
    this.phaseTime = 0;
    this.emit("PHASE", { phase });
  }
  lobby(seed = Date.now() >>> 0, fixedIds) {
    const choices2 = this.players.map((p) => ({ skin: p.skin, direction: p.direction }));
    this.seed = seed;
    this.rng = seededRandom(seed);
    this.npcRng = seededRandom(seed ^ 439041101);
    this.hintRng = seededRandom(seed ^ 1584337460);
    this.npcPlan = null;
    this.startedAtISO = (/* @__PURE__ */ new Date()).toISOString();
    this.revealReady = [false, this.mode === "solo"];
    this.matchId = `match-${seed}-${Math.random().toString(36).slice(2, 9)}`;
    this.players = choices2.map((p, id) => ({ ...freshPlayer(id, p.skin), direction: p.direction }));
    if (this.mode === "solo") this.players[1].ready = true;
    this.clock = 0;
    this.battleIndex = 0;
    this.clashIndex = 0;
    this.skillFreeze = 0;
    this.paused = false;
    this.pauseReason = "";
    this.resumeReady = [false, false];
    this.outcome = null;
    this.records = [];
    this.handled.clear();
    this.events = [];
    this.sequence = fixedIds ? fixedIds.map((id) => {
      const q = ALL_QUESTIONS.find((q2) => q2.questionId === id);
      if (!q) throw Error(`Unknown question ${id}`);
      return q;
    }) : drawQuestions(this.settings, this.rng, this.recentQuestionIds);
    this.transition("LOBBY");
  }
  home() {
    this.lobby();
    this.transition("TITLE");
  }
  ready(id) {
    if (this.phase !== "LOBBY" || this.paused || this.isNpc(id) || !this.players[id]) return;
    this.players[id].ready = !this.players[id].ready;
    this.emit("READY", { id });
    if (this.players.every((p) => p.ready)) this.transition("COUNTDOWN");
  }
  isNpc(id) {
    return this.mode === "solo" && id === 1;
  }
  canConfigure(id) {
    return !!this.players[id] && this.phase === "LOBBY" && (this.isNpc(id) ? !this.players[0].ready : !this.players[id].ready);
  }
  setMode(mode) {
    if (!["TITLE", "LOBBY"].includes(this.phase) || !["duo", "solo"].includes(mode)) return;
    this.mode = mode;
    if (this.phase === "LOBBY") this.lobby(this.seed);
  }
  setNpcLevel(level) {
    if (["TITLE", "LOBBY"].includes(this.phase) && level in NPC_LEVELS) {
      this.npcLevel = level;
      this.emit("CONFIG");
    }
  }
  setTop(id, index) {
    if (this.canConfigure(id) && Number.isInteger(index) && TOPS[index]) {
      this.players[id].skin = index;
      this.emit("SKIN", { id });
    }
  }
  skin(id) {
    if (this.players[id]) this.setTop(id, (this.players[id].skin + 1) % TOPS.length);
  }
  setDirection(id, direction) {
    if (this.canConfigure(id) && (direction === "left" || direction === "right")) {
      this.players[id].direction = direction;
      this.emit("SKIN", { id });
    }
  }
  get baseDeadline() {
    return this.settings.questionSeconds + (this.settings.advancedExtraTime && this.question?.difficulty === "\u9032\u968E" ? 5 : 0);
  }
  deadline(id) {
    return this.baseDeadline + this.players[id].extraSeconds;
  }
  remaining(id) {
    return Math.max(0, this.deadline(id) - this.phaseTime);
  }
  get questionRemaining() {
    return Math.max(0, ...this.players.map((p) => p.lockedOptionId ? 0 : this.remaining(p.playerId)));
  }
  useHint(id, kind, matchId = this.matchId, questionId = this.question?.questionId) {
    const p = this.players[id];
    if (!p || this.isNpc(id) || this.paused || this.phase !== "QUESTION_ACTIVE" || this.remaining(id) <= 1e-7 || p.lockedOptionId || !(kind in HINTS) || p.hintsUsed.includes(kind) || matchId !== this.matchId || questionId !== this.question.questionId) return false;
    p.hintsUsed.push(kind);
    if (kind === "fifty") {
      p.eliminated = shuffle(this.record.orders[id].filter((o) => o !== this.question.correctOptionId), this.hintRng).slice(0, 2);
      if (p.selectedOptionId && p.eliminated.includes(p.selectedOptionId)) p.selectedOptionId = null;
    } else if (kind === "clue") p.clueVisible = true;
    else p.extraSeconds = 5;
    this.emit("HINT", { id, kind });
    return true;
  }
  npcQuestion() {
    if (!this.npcPlan || this.players[1].lockedOptionId || this.phaseTime < this.npcPlan.at) return;
    const optionId = this.npcPlan.optionId;
    this.npcPlan = null;
    this.selectFor(this.context(1, optionId), true);
    this.lockFor(this.context(1, optionId), true);
  }
  continueReveal(id) {
    if (this.phase !== "REVEAL" || this.paused || this.isNpc(id) || !this.players[id]) return false;
    this.revealReady[id] = true;
    this.emit("REVEAL_READY", { id });
    if (this.revealReady.every(Boolean)) this.endReveal();
    return true;
  }
  endReveal() {
    this.battleIndex++;
    this.beginBattle();
  }
  allFinished() {
    return this.players.every((p) => p.lockedOptionId !== null || this.remaining(p.playerId) <= 1e-7);
  }
  pause(reason = "\u8CFD\u5C40\u5DF2\u66AB\u505C") {
    if (!this.live || this.paused) return;
    this.paused = true;
    this.pauseReason = reason;
    this.resumeReady = [false, this.mode === "solo"];
    this.emit("PAUSE");
  }
  confirmResume(id) {
    if (!this.paused) return false;
    this.resumeReady[id] = true;
    return this.resumeReady.every(Boolean);
  }
  resume() {
    if (!this.paused || !this.resumeReady.every(Boolean)) return;
    this.paused = false;
    this.resumeReady = [false, false];
    this.emit("RESUME");
  }
  activateQuestion() {
    if (this.phase !== "QUESTION_LOADING" || this.paused) return;
    this.transition("QUESTION_ACTIVE");
    this.record.startedAt = this.clock;
    if (this.mode === "solo") {
      const level = NPC_LEVELS[this.npcLevel], q = this.question;
      const chance = level.accuracy - (q.difficulty === "\u9032\u968E" ? 0.12 : q.difficulty === "\u6A19\u6E96" ? 0.04 : 0);
      const correct = this.npcRng() < chance;
      const wrong = q.options.filter((o) => o.optionId !== q.correctOptionId);
      this.npcPlan = { at: (level.minDelay + this.npcRng() * (level.maxDelay - level.minDelay)) * this.baseDeadline, optionId: correct ? q.correctOptionId : wrong[Math.floor(this.npcRng() * wrong.length)].optionId };
    }
  }
  context(id, optionId) {
    return { matchId: this.matchId, questionId: this.question?.questionId ?? "", playerId: id, optionId };
  }
  valid(input, npc = false) {
    return (npc || !this.isNpc(input.playerId)) && !this.paused && this.phase === "QUESTION_ACTIVE" && (input.playerId === 0 || input.playerId === 1) && this.remaining(input.playerId) > 1e-7 && input.matchId === this.matchId && input.questionId === this.question.questionId && (input.playerId === 0 || input.playerId === 1) && this.record.orders[input.playerId].includes(input.optionId) && !this.players[input.playerId].eliminated.includes(input.optionId) && this.players[input.playerId].lockedOptionId === null;
  }
  select(input) {
    return this.selectFor(input, false);
  }
  selectFor(input, npc) {
    if (!this.valid(input, npc)) return false;
    this.players[input.playerId].selectedOptionId = input.optionId;
    this.emit("SELECT", { id: input.playerId });
    return true;
  }
  lock(input) {
    return this.lockFor(input, false);
  }
  lockFor(input, npc) {
    if (!this.valid(input, npc) || this.players[input.playerId].selectedOptionId !== input.optionId) return false;
    const p = this.players[input.playerId];
    p.lockedOptionId = input.optionId;
    p.lockedAt = this.phaseTime;
    this.emit("LOCK", { id: input.playerId });
    if (this.allFinished()) this.resolveQuestion();
    return true;
  }
  skill(id, matchId = this.matchId, battleIndex = this.battleIndex, npc = false) {
    if (this.isNpc(id) && !npc) return false;
    const p = this.players[id];
    if (!p || this.paused || this.phase !== "BATTLE" || this.skillFreeze > 0 || this.phaseTime >= BALANCE.battleSeconds || this.clashIndex >= BALANCE.clashSeconds.length || matchId !== this.matchId || battleIndex !== this.battleIndex || p.energy < BALANCE.maxEnergy || p.skillUsed) return false;
    p.energy -= BALANCE.maxEnergy;
    p.pendingSkill = true;
    p.skillUsed = true;
    this.emit("SKILL_QUEUED", { id });
    return true;
  }
  advance(seconds) {
    if (this.paused || !this.live || seconds <= 0) return;
    let left = seconds;
    while (left > 1e-8 && !this.paused && this.live) {
      const dt = Math.min(left, BALANCE.fixedStep);
      this.step(dt);
      left -= dt;
    }
  }
  step(dt) {
    if (this.phase === "QUESTION_LOADING") return;
    this.clock += dt;
    if (this.phase === "BATTLE" && this.skillFreeze > 0) {
      this.skillFreeze = Math.max(0, this.skillFreeze - dt);
      if (this.skillFreeze === 0 && this.phaseTime >= BALANCE.battleSeconds - 1e-7) this.endBattle();
      return;
    }
    this.phaseTime += dt;
    if (this.phase === "COUNTDOWN" && this.phaseTime >= BALANCE.countdownSeconds - 1e-7) {
      this.beginBattle();
      return;
    }
    if (this.phase === "BATTLE") {
      if (this.mode === "solo" && this.phaseTime >= 1) this.skill(1, this.matchId, this.battleIndex, true);
      const over = Math.max(0, this.phaseTime - BALANCE.battleSeconds);
      const drain = Math.max(0, dt - over) * BALANCE.spinDrain;
      for (const p of this.players) {
        p.spin = Math.max(0, p.spin - drain * TOP_TYPES[TOPS[p.skin].type].drain / BALANCE.spinDrain);
        if (p.spin < 1e-8) p.spin = 0;
      }
      while (this.clashIndex < BALANCE.clashSeconds.length && this.phaseTime >= BALANCE.clashSeconds[this.clashIndex] - 1e-7) {
        this.clash();
        if (this.phase !== "BATTLE") return;
      }
      if (this.phaseTime >= BALANCE.battleSeconds - 1e-7 && this.skillFreeze === 0) this.endBattle();
    } else if (this.phase === "QUESTION_ACTIVE") {
      this.npcQuestion();
      if (this.phase === "QUESTION_ACTIVE" && this.allFinished()) this.resolveQuestion();
    } else if (this.phase === "REVEAL" && this.settings.revealSeconds > 0 && this.phaseTime >= this.settings.revealSeconds - 1e-7) this.endReveal();
  }
  beginBattle() {
    this.clashIndex = 0;
    this.skillFreeze = 0;
    for (const p of this.players) {
      p.skillUsed = false;
      p.pendingSkill = false;
    }
    this.transition("BATTLE");
  }
  /** Both attack packets are calculated from the same snapshot, then applied together. */
  clash() {
    const key = `${this.matchId}:clash:${this.battleIndex}:${this.clashIndex}`;
    this.clashIndex++;
    if (this.handled.has(key)) return;
    this.handled.add(key);
    const snapshot = this.players.map((p) => ({ ...p }));
    const outgoing = snapshot.map((p) => normalDamage(p) + (p.pendingSkill ? BALANCE.skillDamage : 0));
    const sameSpin = snapshot[0].direction === snapshot[1].direction;
    const packets = snapshot.map((p, id) => Math.max(1, outgoing[1 - id] + (sameSpin ? 1 : 0) - TOP_TYPES[TOPS[p.skin].type].armor));
    const damage = snapshot.map((p, id) => Math.max(0, packets[id] - p.shield));
    if (!sameSpin) {
      const difference = snapshot[0].spin - snapshot[1].spin, transfer = Math.min(1, Math.abs(difference) / 2);
      this.players[0].spin -= Math.sign(difference) * transfer;
      this.players[1].spin += Math.sign(difference) * transfer;
    }
    this.players.forEach((p, id) => {
      p.hp = Math.max(0, snapshot[id].hp - damage[id]);
      p.shield = Math.max(0, snapshot[id].shield - packets[id]);
      p.firstHitBonus = 0;
      p.pendingSkill = false;
    });
    const skills = snapshot.map((p) => p.pendingSkill);
    this.emit("CLASH", { damage, skills, node: this.clashIndex, battleIndex: this.battleIndex });
    if (!this.settings.completeAllQuestions && this.players.some((p) => p.hp === 0)) {
      this.finish();
      return;
    }
    if (skills.some(Boolean)) this.skillFreeze = BALANCE.skillFreezeSeconds;
  }
  endBattle() {
    for (const p of this.players) {
      p.shield = 0;
      p.attackBonus = 0;
      p.firstHitBonus = 0;
      p.pendingSkill = false;
    }
    if (this.records.length >= this.sequence.length) {
      this.finish();
      return;
    }
    const q = this.sequence[this.records.length];
    this.records.push({ question: q, questionId: q.questionId, orders: [shuffle(q.options.map((o) => o.optionId), this.rng), shuffle(q.options.map((o) => o.optionId), this.rng)], startedAt: null, answers: [], rewardsApplied: false });
    for (const p of this.players) {
      p.selectedOptionId = null;
      p.lockedOptionId = null;
      p.lockedAt = null;
      p.eliminated = [];
      p.clueVisible = false;
      p.extraSeconds = 0;
    }
    this.transition("QUESTION_LOADING");
  }
  resolveQuestion() {
    const r = this.record;
    if (r.rewardsApplied) return;
    const key = `${this.matchId}:question:${r.questionId}`;
    if (this.handled.has(key)) return;
    this.handled.add(key);
    r.answers = this.players.map((p) => ({ optionId: p.lockedOptionId, result: p.lockedOptionId === null ? "unanswered" : p.lockedOptionId === this.question.correctOptionId ? "correct" : "wrong", seconds: p.lockedAt, speed: false, hints: [...p.hintsUsed].filter((h) => h === "fifty" ? p.eliminated.length > 0 : h === "clue" ? p.clueVisible : p.extraSeconds > 0) }));
    if (r.answers.every((a) => a.result === "correct" && a.hints.length === 0)) {
      const diff = r.answers[0].seconds - r.answers[1].seconds;
      if (Math.abs(diff) > BALANCE.speedTieSeconds + 1e-8) r.answers[diff < 0 ? 0 : 1].speed = true;
    }
    r.answers.forEach((a, id) => {
      if (a.result !== "correct") return;
      const p = this.players[id];
      p.hp = Math.min(BALANCE.maxHP, p.hp + BALANCE.heal);
      p.spin = Math.min(BALANCE.maxSpin, p.spin + BALANCE.spinReward);
      p.shield = BALANCE.maxShield;
      p.attackBonus = BALANCE.correctAttack;
      p.firstHitBonus = a.speed ? BALANCE.speedAttack : 0;
      p.energy = Math.min(BALANCE.maxEnergy, p.energy + 1);
    });
    r.rewardsApplied = true;
    this.revealReady = [false, this.mode === "solo"];
    this.transition("REVEAL");
    this.emit("QUESTION_RESOLVED", { answers: r.answers });
  }
  finish() {
    const [a, b] = this.players;
    const sa = stats(this.records, 0), sb = stats(this.records, 1);
    let winner = null, reason = "\u96D9\u65B9\u8868\u73FE\u76F8\u540C\uFF0C\u4ECA\u5834\u5E73\u624B";
    if (this.settings.completeAllQuestions && sa.correct !== sb.correct) {
      winner = sa.correct > sb.correct ? 0 : 1;
      reason = "\u5DF2\u5B8C\u6210\u6240\u6709\u984C\u76EE\uFF0C\u4EE5\u7B54\u5C0D\u984C\u6578\u8F03\u591A\u8005\u52DD\u51FA";
    } else if (!this.settings.completeAllQuestions && a.hp === 0 && b.hp === 0) reason = "\u96D9\u65B9\u5728\u540C\u4E00\u78B0\u649E\u7BC0\u9EDE\u8017\u76E1 HP";
    else if (a.hp !== b.hp) {
      winner = a.hp > b.hp ? 0 : 1;
      reason = this.settings.completeAllQuestions ? "\u7B54\u5C0D\u984C\u6578\u76F8\u540C\uFF0C\u5269\u9918 HP \u8F03\u9AD8" : "\u5269\u9918 HP \u8F03\u9AD8";
    } else if (sa.correct !== sb.correct) {
      winner = sa.correct > sb.correct ? 0 : 1;
      reason = "HP \u76F8\u540C\uFF0C\u7B54\u5C0D\u984C\u6578\u8F03\u591A";
    } else if (sa.average !== null && sb.average !== null && Math.abs(sa.average - sb.average) > BALANCE.speedTieSeconds + 1e-8) {
      winner = sa.average < sb.average ? 0 : 1;
      reason = "\u7B54\u5C0D\u984C\u6578\u53CA HP \u76F8\u540C\uFF0C\u6B63\u78BA\u7B54\u6848\u5E73\u5747\u7528\u6642\u8F03\u77ED";
    }
    this.outcome = { winner, reason };
    this.transition("RESULTS");
  }
};
var GameClock = class {
  previous = null;
  sample(now) {
    if (this.previous === null) {
      this.previous = now;
      return { delta: 0, interrupted: false };
    }
    const delta = Math.max(0, (now - this.previous) / 1e3);
    this.previous = now;
    return { delta, interrupted: delta > BALANCE.interruptionSeconds };
  }
  reset(now) {
    this.previous = now;
  }
};
export {
  ALL_QUESTIONS,
  BALANCE,
  DEFAULT_SETTINGS,
  GENERATED_QUESTIONS,
  GameClock,
  MatchController,
  QUESTIONS,
  TOPS,
  TOP_TYPES,
  drawQuestions,
  generateQuestionBank,
  matchCSV,
  normalDamage,
  numberLineSVG,
  seededRandom,
  shuffle,
  stats
};
