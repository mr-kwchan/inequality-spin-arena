"""Export source + built static game, without host identity or dependencies."""
from pathlib import Path
import sys
import zipfile

root = Path(__file__).resolve().parent.parent
target = Path(sys.argv[1]).resolve()
target.parent.mkdir(parents=True, exist_ok=True)
prefix = '不等式旋鬥場_v1.0/'
allowed = ['src', 'dist', 'scripts', 'tests', 'README.md', 'ACCEPTANCE.md',
           'test-output.txt', 'package.json', 'package-lock.json', 'tsconfig.json',
           'SOURCE_SPEC.txt', '操作說明.html']
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    archive.write(root / 'dist/PLAY.html', prefix + 'PLAY.html')
    for name in allowed:
        item = root / name
        paths = sorted(item.rglob('*')) if item.is_dir() else [item]
        for file in paths:
            if not file.is_file() or file == root / 'dist/PLAY.html' or '__pycache__' in file.parts:
                continue
            archive.write(file, prefix + file.relative_to(root).as_posix())
print(target)
print(f'{target.stat().st_size:,} bytes')
