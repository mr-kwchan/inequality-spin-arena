import * as THREE from 'three';
import {MatchController,type GameEvent} from './core';
import type {Settings} from './settings';
const COLORS=[0x50e9ef,0xffa16b];
export class ArenaRenderer {
  renderer:THREE.WebGLRenderer;scene=new THREE.Scene();camera:THREE.PerspectiveCamera;
  tops:{root:THREE.Group;tilt:THREE.Group;rotor:THREE.Group;trail:THREE.Line;label:THREE.Sprite;aura:THREE.Mesh}[]=[];
  private t=0;private fxAge=10;private clashAngle=0;private skillFx=false;private rings:THREE.Mesh[]=[];
  private particles:THREE.Points;private pos=new Float32Array(96*3);private velocity=new Float32Array(96*3);
  private starRing:THREE.Group;private size={w:0,h:0};private losses=[false,false];private lastSkins=[-1,-1];
  constructor(private host:HTMLElement,onLost:()=>void,onRestored:()=>void){
    const canvas=document.createElement('canvas');canvas.setAttribute('aria-label','3D 旋鬥競技場：P1 藍青色陀螺，P2 橙紅色陀螺');
    const context=canvas.getContext('webgl2',{antialias:true,alpha:true,powerPreference:'high-performance'});
    if(!context)throw Error('這部裝置未能啟用 WebGL 2。請使用支援 WebGL 2 的 Safari 或 Chrome，並啟用硬件加速。');
    this.renderer=new THREE.WebGLRenderer({canvas,context,antialias:true,alpha:true});this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));this.renderer.setClearColor(0,0);this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.25;
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();onLost();});canvas.addEventListener('webglcontextrestored',onRestored);host.append(canvas);
    this.camera=new THREE.PerspectiveCamera(39,1,0.1,100);this.camera.position.set(9,13,17);
    this.scene.add(new THREE.HemisphereLight(0xd9edff,0x0b1320,3));
    const key=new THREE.DirectionalLight(0xe0efff,4.5);key.position.set(-3,10,3);this.scene.add(key);
    const fill=new THREE.DirectionalLight(0x32dbe9,2.5);fill.position.set(-7,3,-5);this.scene.add(fill);
    const warm=new THREE.DirectionalLight(0xff9159,3);warm.position.set(7,5,0);this.scene.add(warm);
    const stage=new THREE.Group();this.scene.add(stage);
    const metal=(color:number,roughness=.3)=>new THREE.MeshStandardMaterial({color,metalness:.7,roughness});
    const glow=(color:number,intensity=2)=>new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:intensity,metalness:.35,roughness:.4});
    const mesh=(geo:THREE.BufferGeometry,mat:THREE.Material,y=0,parent:THREE.Object3D=stage)=>{const m=new THREE.Mesh(geo,mat);m.position.y=y;parent.add(m);return m;};
    mesh(new THREE.CylinderGeometry(5.6,5.85,.42,96),metal(0x101c28),-.46);
    mesh(new THREE.CylinderGeometry(5.12,5.55,.48,96),metal(0x233442),-.26);
    // A shallow lathed bowl, with actual curvature and a raised outer lip.
    const profile=[];for(let i=0;i<=32;i++){const r=i/32*5.12;profile.push(new THREE.Vector2(r,.015+Math.pow(r/5.12,3)*.52));}
    mesh(new THREE.LatheGeometry(profile,96),new THREE.MeshStandardMaterial({color:0x132737,metalness:.55,roughness:.45,side:THREE.DoubleSide}));
    for(const r of [1.15,2.6,4.05,5.15,5.53]){
      const y=r>5?.58:.035+Math.pow(r/5.12,3)*.52;
      const m=mesh(new THREE.TorusGeometry(r,r>5?.025:.011,8,96),r===5.53?glow(0x76ecec,1):metal(0x3d7887),y);m.rotation.x=Math.PI/2;
    }
    for(let i=0;i<60;i++){
      const a=i/60*Math.PI*2;const r=4.73;
      const m=mesh(new THREE.BoxGeometry(.026,.017,i%5===0?.23:.09),i%5===0?glow(0x8fbbc5,.4):metal(0x32505d),.46);
      m.position.x=Math.sin(a)*r;m.position.z=Math.cos(a)*r;m.rotation.y=a;
    }
    // Radial carbon panels identify a physical arena, not a flat image.
    for(let i=0;i<16;i++){
      const a=i/16*Math.PI*2;
      const m=mesh(new THREE.BoxGeometry(.65,.16,.38),metal(0x192b37),-.31);m.position.x=Math.sin(a)*5.65;m.position.z=Math.cos(a)*5.65;m.rotation.y=a;
      const l=mesh(new THREE.BoxGeometry(.28,.02,.04),glow(i<8?COLORS[0]:COLORS[1],1.4),-.21);l.position.x=Math.sin(a)*5.8;l.position.z=Math.cos(a)*5.8;l.rotation.y=a;
    }
    const center=mesh(new THREE.TorusGeometry(.44,.018,6,6),glow(0x7bc8d1,.5),.055);center.rotation.x=Math.PI/2;
    for(let i=0;i<6;i++){const a=i*Math.PI/3;const l=mesh(new THREE.BoxGeometry(.025,.01,1.35),metal(0x32505d),.05);l.position.x=Math.sin(a)*.95;l.position.z=Math.cos(a)*.95;l.rotation.y=a;}
    const floor=mesh(new THREE.RingGeometry(6.2,11,96),new THREE.MeshBasicMaterial({color:0x153343,transparent:true,opacity:.12,side:THREE.DoubleSide}),-.75);floor.rotation.x=-Math.PI/2;
    this.starRing=new THREE.Group();this.scene.add(this.starRing);
    const coords=[];for(let i=0;i<100;i++){const a=i*2.39996,r=7+(i%11)*.53;coords.push(Math.cos(a)*r,((i*7)%23)/8-1,Math.sin(a)*r);}
    const starGeo=new THREE.BufferGeometry();starGeo.setAttribute('position',new THREE.Float32BufferAttribute(coords,3));this.starRing.add(new THREE.Points(starGeo,new THREE.PointsMaterial({color:0x64bbc9,size:.035,transparent:true,opacity:.55})));
    this.tops=[this.createTop(0),this.createTop(1)];
    for(let i=0;i<4;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(1,.028,8,64),new THREE.MeshBasicMaterial({color:i%2?COLORS[1]:COLORS[0],transparent:true,opacity:0,depthWrite:false}));ring.rotation.x=Math.PI/2;this.scene.add(ring);this.rings.push(ring);}
    const pg=new THREE.BufferGeometry();pg.setAttribute('position',new THREE.BufferAttribute(this.pos,3));this.particles=new THREE.Points(pg,new THREE.PointsMaterial({color:0xffdcb2,size:.065,transparent:true,opacity:0,depthWrite:false}));this.particles.frustumCulled=false;this.scene.add(this.particles);
    new ResizeObserver(()=>this.resize()).observe(host);this.resize();
  }
  private createTop(id:number){
    const root=new THREE.Group(),tilt=new THREE.Group(),rotor=new THREE.Group();root.add(tilt);tilt.add(rotor);this.scene.add(root);
    const c=COLORS[id],dark=new THREE.MeshStandardMaterial({color:0x142333,metalness:.85,roughness:.28}),silver=new THREE.MeshStandardMaterial({color:0xa4c2cf,metalness:.8,roughness:.24}),paint=new THREE.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:.25,metalness:.65,roughness:.28}),light=new THREE.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:2,metalness:.4,roughness:.25});
    const add=(g:THREE.BufferGeometry,m:THREE.Material,y:number)=>{const o=new THREE.Mesh(g,m);o.position.y=y;rotor.add(o);return o;};
    add(new THREE.ConeGeometry(.12,.37,16),silver,.19).rotation.z=Math.PI;
    add(new THREE.CylinderGeometry(.3,.15,.24,16),dark,.45);
    add(new THREE.CylinderGeometry(.77,.42,.26,id===0?8:12),silver,.67);
    add(new THREE.CylinderGeometry(.83,.81,.12,id===0?8:12),dark,.82);
    const ring=add(new THREE.TorusGeometry(.73,.045,10,48),light,.9);ring.rotation.x=Math.PI/2;
    add(new THREE.CylinderGeometry(.54,.72,.2,8),paint,.98);
    const n=id===0?4:6;
    for(let i=0;i<n;i++){
      const a=i/n*Math.PI*2;const fin=add(new THREE.BoxGeometry(.34,.17,.52),paint,.94);fin.position.x=Math.sin(a)*.63;fin.position.z=Math.cos(a)*.63;fin.rotation.y=a+(id===0?.4:-.4);
      const cut=add(new THREE.BoxGeometry(.06,.022,.35),silver,1.037);cut.position.x=Math.sin(a)*.56;cut.position.z=Math.cos(a)*.56;cut.rotation.y=a;
    }
    add(new THREE.CylinderGeometry(.29,.4,.1,8),dark,1.12);
    add(new THREE.CylinderGeometry(.2,.25,.06,id===0?3:6),light,1.2);
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(48*3),3));const trail=new THREE.Line(g,new THREE.LineBasicMaterial({color:c,transparent:true,opacity:.42,depthWrite:false}));trail.frustumCulled=false;this.scene.add(trail);
    const cv=document.createElement('canvas');cv.width=192;cv.height=96;const ctx=cv.getContext('2d')!;ctx.fillStyle=id===0?'#50e9ef':'#ffa16b';ctx.font='bold 48px system-ui';ctx.textAlign='center';ctx.fillText(`P${id+1}`,96,64);
    const label=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(cv),transparent:true,depthTest:false}));label.scale.set(.9,.45,1);root.add(label);label.position.set(0,1.8,0);
    const aura=new THREE.Mesh(new THREE.TorusGeometry(1.03,.025,8,64),new THREE.MeshBasicMaterial({color:c,transparent:true,opacity:.45}));aura.rotation.x=Math.PI/2;aura.position.y=.07;root.add(aura);
    return {root,tilt,rotor,trail,label,aura};
  }
  private resize(){const {width:w,height:h}=this.host.getBoundingClientRect();if(!w||!h)return;this.size={w,h};this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();}
  event(e:GameEvent){if(e.type==='CLASH'){this.fxAge=0;this.clashAngle=(e.node as number||1)*2*.66+Math.PI*.88;this.skillFx=(e.skills as boolean[]).some(Boolean);for(let i=0;i<96;i++){const a=Math.random()*Math.PI*2,r=1+Math.random()*5;this.pos[i*3]=0;this.pos[i*3+1]=.85;this.pos[i*3+2]=0;this.velocity[i*3]=Math.cos(a)*r;this.velocity[i*3+1]=Math.random()*4;this.velocity[i*3+2]=Math.sin(a)*r;}}}
  render(dt:number,game:MatchController,settings:Settings){
    const activeDt=game.paused?0:Math.min(dt,.05);this.t+=activeDt;this.fxAge+=activeDt;const title=game.phase==='TITLE';const quiz=['QUESTION_LOADING','QUESTION_ACTIVE','REVEAL'].includes(game.phase);
    const small=this.size.w<1100;const cameraDist=small?1.08:1;
    this.camera.position.set(8.6*cameraDist,12.8*cameraDist,15.4*cameraDist);
    // Keep the arena above the question sheets while the tops keep visibly spinning.
    this.camera.lookAt(title?new THREE.Vector3(-2.6,0,0):quiz?new THREE.Vector3(0,-3.4,0):new THREE.Vector3(0,.25,0));
    if(title){this.camera.position.multiplyScalar(1.07);this.camera.lookAt(0,0,0);this.camera.setViewOffset(this.size.w,this.size.h,-this.size.w*.23,0,this.size.w,this.size.h);}else this.camera.clearViewOffset();
    if(this.fxAge<.25&&settings.cameraShake&&!settings.reducedEffects&&!quiz){const s=(.25-this.fxAge)*(this.skillFx?.35:.13);this.camera.position.x+=Math.sin(this.fxAge*130)*s;this.camera.position.y+=Math.cos(this.fxAge*155)*s;}
    this.starRing.rotation.y=this.t*.025;
    this.tops.forEach((top,id)=>{
      const p=game.players[id],sign=id===0?-1:1;let a=this.t*.32+id*Math.PI,r=2.7;
      if(game.phase==='BATTLE'){
        a=game.phaseTime*.66+id*Math.PI+Math.PI*.88;const cycle=game.phaseTime%2;
        r=cycle<.5&&game.clashIndex>0?.79+(2.65-.79)*Math.sin(cycle/.5*Math.PI/2):cycle>1.5?.79+(2.65-.79)*Math.cos((cycle-1.5)/.5*Math.PI/2):2.65;
      }else if(['TITLE','LOBBY','COUNTDOWN'].includes(game.phase)){a=id===0?Math.PI*.88:-Math.PI*.12;r=2.05;if(game.phase==='COUNTDOWN')r=5.8-(5.8-2.65)*Math.min(1,Math.max(0,(game.phaseTime-2.55)/.45));}
      else if(quiz){r=2.25;a=this.t*.19+id*Math.PI;}
      // Keep the fifth clash visible even when the logic has just entered the next question.
      if(this.fxAge<.11&&!['TITLE','LOBBY','COUNTDOWN'].includes(game.phase)){r=.79;a=this.clashAngle+id*Math.PI;}
      top.root.position.set(Math.cos(a)*r,.05+Math.pow(r/5.12,3)*.52,Math.sin(a)*r);
      if(game.phase==='TITLE')top.root.position.x+=.8;
      const lost=(game.phase==='RESULTS'||game.phase==='REVIEW')&&p.hp===0;
      top.rotor.rotation.y+=activeDt*(lost?Math.max(0,3-this.fxAge):Math.PI*2*(4+p.spin*.2))*(id===0?1:-1);
      const wobble=lost?.65:(1-p.spin/100)*.25;
      top.tilt.rotation.x=Math.sin(this.t*7+id)*wobble;top.tilt.rotation.z=Math.cos(this.t*6+id)*wobble;
      if(this.lastSkins[id]!==p.skin){top.rotor.scale.set(p.skin?1.05:1,p.skin?.88:1,p.skin?1.05:1);this.lastSkins[id]=p.skin;}
      top.aura.visible=p.shield>0||p.pendingSkill||game.phase==='LOBBY';top.aura.scale.setScalar(p.pendingSkill?1.2+Math.sin(this.t*12)*.1:1);(top.aura.material as THREE.MeshBasicMaterial).opacity=p.pendingSkill?.85:.4;
      const trail=top.trail.geometry.attributes.position as THREE.BufferAttribute;
      for(let i=0;i<48;i++){const t=i/47,ta=a-t*.6*(id?1:-1);trail.setXYZ(i,Math.cos(ta)*r+(title?.8:0),top.root.position.y+.14,Math.sin(ta)*r);}
      trail.needsUpdate=true;top.trail.visible=!settings.reducedEffects&&!lost;top.label.visible=!title;
    });
    const life=this.skillFx?1.2:.55,fade=Math.max(0,1-this.fxAge/life);
    for(let i=0;i<4;i++){const m=this.rings[i],s=.5+this.fxAge*(this.skillFx?5:7)+i*.25;m.scale.setScalar(s);m.position.y=.14+(this.skillFx?i*.35:0);(m.material as THREE.MeshBasicMaterial).opacity=fade*(this.skillFx?.7:.35);m.visible=!settings.reducedEffects&&(this.skillFx||i===0);}
    if(fade>0){for(let i=0;i<96;i++){this.pos[i*3]+=this.velocity[i*3]*activeDt;this.pos[i*3+1]+=this.velocity[i*3+1]*activeDt;this.pos[i*3+2]+=this.velocity[i*3+2]*activeDt;this.velocity[i*3+1]-=activeDt*5;}this.particles.geometry.attributes.position.needsUpdate=true;}
    (this.particles.material as THREE.PointsMaterial).opacity=fade;this.particles.visible=!settings.reducedEffects;
    this.renderer.render(this.scene,this.camera);
  }
  diagnostics(){return {threeRevision:THREE.REVISION,geometries:this.renderer.info.memory.geometries,textures:this.renderer.info.memory.textures,calls:this.renderer.info.render.calls};}
}
